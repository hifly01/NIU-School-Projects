﻿namespace TheresaLiCharlesAlms_Assign6
{
    partial class mainPortal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.selectGraph = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pyramidGraph_button = new System.Windows.Forms.Button();
            this.pieChart_button = new System.Windows.Forms.Button();
            this.lineGraph_button = new System.Windows.Forms.Button();
            this.bargraph_button = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.selectGraph.SuspendLayout();
            this.SuspendLayout();
            // 
            // selectGraph
            // 
            this.selectGraph.Controls.Add(this.label5);
            this.selectGraph.Controls.Add(this.label4);
            this.selectGraph.Controls.Add(this.label3);
            this.selectGraph.Controls.Add(this.label2);
            this.selectGraph.Controls.Add(this.label1);
            this.selectGraph.Controls.Add(this.pyramidGraph_button);
            this.selectGraph.Controls.Add(this.pieChart_button);
            this.selectGraph.Controls.Add(this.lineGraph_button);
            this.selectGraph.Controls.Add(this.bargraph_button);
            this.selectGraph.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectGraph.Location = new System.Drawing.Point(12, 12);
            this.selectGraph.Name = "selectGraph";
            this.selectGraph.Size = new System.Drawing.Size(459, 551);
            this.selectGraph.TabIndex = 0;
            this.selectGraph.TabStop = false;
            this.selectGraph.Text = "Select a Graph";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(37, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(416, 36);
            this.label3.TabIndex = 6;
            this.label3.Text = "when they see their Owners after a Period of Time";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Javanese Text", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(118, 149);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(227, 36);
            this.label2.TabIndex = 5;
            this.label2.Text = "Level of Happiness in Pets";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Impact", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(62, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(348, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Google Search Popularity of the Coronavirus in 2020";
            // 
            // pyramidGraph_button
            // 
            this.pyramidGraph_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pyramidGraph_button.Location = new System.Drawing.Point(157, 470);
            this.pyramidGraph_button.Name = "pyramidGraph_button";
            this.pyramidGraph_button.Size = new System.Drawing.Size(154, 54);
            this.pyramidGraph_button.TabIndex = 3;
            this.pyramidGraph_button.Text = "Pyramid Graph";
            this.pyramidGraph_button.UseVisualStyleBackColor = true;
            this.pyramidGraph_button.Click += new System.EventHandler(this.pyramidGraph_button_Click);
            // 
            // pieChart_button
            // 
            this.pieChart_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pieChart_button.Location = new System.Drawing.Point(157, 338);
            this.pieChart_button.Name = "pieChart_button";
            this.pieChart_button.Size = new System.Drawing.Size(154, 54);
            this.pieChart_button.TabIndex = 2;
            this.pieChart_button.Text = "Pie Chart";
            this.pieChart_button.UseVisualStyleBackColor = true;
            this.pieChart_button.Click += new System.EventHandler(this.pieChart_button_Click);
            // 
            // lineGraph_button
            // 
            this.lineGraph_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lineGraph_button.Location = new System.Drawing.Point(157, 214);
            this.lineGraph_button.Name = "lineGraph_button";
            this.lineGraph_button.Size = new System.Drawing.Size(154, 54);
            this.lineGraph_button.TabIndex = 1;
            this.lineGraph_button.Text = "Line Graph";
            this.lineGraph_button.UseVisualStyleBackColor = true;
            this.lineGraph_button.Click += new System.EventHandler(this.lineGraph_button_Click);
            // 
            // bargraph_button
            // 
            this.bargraph_button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bargraph_button.Location = new System.Drawing.Point(157, 66);
            this.bargraph_button.Name = "bargraph_button";
            this.bargraph_button.Size = new System.Drawing.Size(154, 54);
            this.bargraph_button.TabIndex = 0;
            this.bargraph_button.Text = "Bar Graph";
            this.bargraph_button.UseVisualStyleBackColor = true;
            this.bargraph_button.Click += new System.EventHandler(this.bargraph_button_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(62, 312);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(334, 23);
            this.label4.TabIndex = 7;
            this.label4.Text = "How a College Student Spends their Time";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(88, 436);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(288, 19);
            this.label5.TabIndex = 8;
            this.label5.Text = "Programming Assignment Progress";
            // 
            // mainPortal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(483, 573);
            this.Controls.Add(this.selectGraph);
            this.Name = "mainPortal";
            this.Text = "Main Portal";
            this.selectGraph.ResumeLayout(false);
            this.selectGraph.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox selectGraph;
        private System.Windows.Forms.Button pyramidGraph_button;
        private System.Windows.Forms.Button pieChart_button;
        private System.Windows.Forms.Button lineGraph_button;
        private System.Windows.Forms.Button bargraph_button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}

