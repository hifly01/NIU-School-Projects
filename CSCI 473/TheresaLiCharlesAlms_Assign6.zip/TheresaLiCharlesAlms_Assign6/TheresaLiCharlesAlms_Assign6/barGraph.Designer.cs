﻿namespace TheresaLiCharlesAlms_Assign6
{
    partial class barGraph
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel11 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel12 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel13 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel14 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel15 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel16 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel17 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel18 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel19 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.CustomLabel customLabel20 = new System.Windows.Forms.DataVisualization.Charting.CustomLabel();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint11 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 1D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint12 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 17D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint13 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 7D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint14 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 29D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint15 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 36D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint16 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 75D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint17 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 100D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint18 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 84D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint19 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 70D);
            System.Windows.Forms.DataVisualization.Charting.DataPoint dataPoint20 = new System.Windows.Forms.DataVisualization.Charting.DataPoint(0D, 58D);
            System.Windows.Forms.DataVisualization.Charting.Title title2 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.backButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.SuspendLayout();
            // 
            // chart1
            // 
            customLabel11.ForeColor = System.Drawing.Color.Black;
            customLabel11.FromPosition = 2D;
            customLabel11.GridTicks = System.Windows.Forms.DataVisualization.Charting.GridTickTypes.TickMark;
            customLabel11.Text = "Jan.\n12-18";
            customLabel12.ForeColor = System.Drawing.Color.Black;
            customLabel12.FromPosition = 4D;
            customLabel12.GridTicks = System.Windows.Forms.DataVisualization.Charting.GridTickTypes.TickMark;
            customLabel12.Text = "Jan.\n26-Feb. 1";
            customLabel13.ForeColor = System.Drawing.Color.Black;
            customLabel13.FromPosition = 6D;
            customLabel13.GridTicks = System.Windows.Forms.DataVisualization.Charting.GridTickTypes.TickMark;
            customLabel13.Text = "Feb.\n16-22";
            customLabel14.ForeColor = System.Drawing.Color.Black;
            customLabel14.FromPosition = 8D;
            customLabel14.GridTicks = System.Windows.Forms.DataVisualization.Charting.GridTickTypes.TickMark;
            customLabel14.Text = "Feb.\n23-29";
            customLabel15.ForeColor = System.Drawing.Color.Black;
            customLabel15.FromPosition = 10D;
            customLabel15.GridTicks = System.Windows.Forms.DataVisualization.Charting.GridTickTypes.TickMark;
            customLabel15.Text = "Mar. 1-7";
            customLabel16.ForeColor = System.Drawing.Color.Black;
            customLabel16.FromPosition = 12D;
            customLabel16.GridTicks = System.Windows.Forms.DataVisualization.Charting.GridTickTypes.TickMark;
            customLabel16.Text = "Mar. 8-14";
            customLabel17.ForeColor = System.Drawing.Color.Black;
            customLabel17.FromPosition = 14D;
            customLabel17.GridTicks = System.Windows.Forms.DataVisualization.Charting.GridTickTypes.TickMark;
            customLabel17.Text = "Mar.\n15-21";
            customLabel18.ForeColor = System.Drawing.Color.Black;
            customLabel18.FromPosition = 16D;
            customLabel18.Text = "Mar.\n22-28";
            customLabel19.ForeColor = System.Drawing.Color.Black;
            customLabel19.FromPosition = 18D;
            customLabel19.GridTicks = System.Windows.Forms.DataVisualization.Charting.GridTickTypes.TickMark;
            customLabel19.Text = "Mar.\n29-Apr. 4";
            customLabel20.ForeColor = System.Drawing.Color.Black;
            customLabel20.FromPosition = 20D;
            customLabel20.GridTicks = System.Windows.Forms.DataVisualization.Charting.GridTickTypes.TickMark;
            customLabel20.Text = "Apr. 12-18";
            chartArea2.AxisX.CustomLabels.Add(customLabel11);
            chartArea2.AxisX.CustomLabels.Add(customLabel12);
            chartArea2.AxisX.CustomLabels.Add(customLabel13);
            chartArea2.AxisX.CustomLabels.Add(customLabel14);
            chartArea2.AxisX.CustomLabels.Add(customLabel15);
            chartArea2.AxisX.CustomLabels.Add(customLabel16);
            chartArea2.AxisX.CustomLabels.Add(customLabel17);
            chartArea2.AxisX.CustomLabels.Add(customLabel18);
            chartArea2.AxisX.CustomLabels.Add(customLabel19);
            chartArea2.AxisX.CustomLabels.Add(customLabel20);
            chartArea2.AxisX.IsMarksNextToAxis = false;
            chartArea2.AxisX.LabelAutoFitMaxFontSize = 8;
            chartArea2.AxisX.MajorGrid.Interval = 1D;
            chartArea2.AxisX.MajorGrid.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Auto;
            chartArea2.AxisX.MajorTickMark.Interval = 1D;
            chartArea2.AxisX.Title = "Dates";
            chartArea2.AxisX.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea2.AxisY.IntervalAutoMode = System.Windows.Forms.DataVisualization.Charting.IntervalAutoMode.VariableCount;
            chartArea2.AxisY.IntervalType = System.Windows.Forms.DataVisualization.Charting.DateTimeIntervalType.Number;
            chartArea2.AxisY.Maximum = 100D;
            chartArea2.AxisY.Title = "Search Popularity (%)";
            chartArea2.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            this.chart1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.chart1.Location = new System.Drawing.Point(12, 12);
            this.chart1.Name = "chart1";
            series2.ChartArea = "ChartArea1";
            series2.Name = "Series1";
            dataPoint11.Color = System.Drawing.Color.Red;
            dataPoint11.IsValueShownAsLabel = false;
            dataPoint11.Label = "1";
            dataPoint11.LabelBackColor = System.Drawing.Color.DarkRed;
            dataPoint11.LabelForeColor = System.Drawing.Color.White;
            dataPoint12.Color = System.Drawing.Color.Red;
            dataPoint12.Label = "17";
            dataPoint12.LabelBackColor = System.Drawing.Color.DarkRed;
            dataPoint12.LabelForeColor = System.Drawing.Color.White;
            dataPoint13.Color = System.Drawing.Color.Red;
            dataPoint13.Label = "7";
            dataPoint13.LabelBackColor = System.Drawing.Color.DarkRed;
            dataPoint13.LabelForeColor = System.Drawing.Color.White;
            dataPoint14.Color = System.Drawing.Color.Red;
            dataPoint14.Label = "29";
            dataPoint14.LabelBackColor = System.Drawing.Color.DarkRed;
            dataPoint14.LabelForeColor = System.Drawing.Color.White;
            dataPoint15.Color = System.Drawing.Color.Red;
            dataPoint15.Label = "36";
            dataPoint15.LabelBackColor = System.Drawing.Color.DarkRed;
            dataPoint15.LabelForeColor = System.Drawing.Color.White;
            dataPoint16.Color = System.Drawing.Color.Red;
            dataPoint16.Label = "75";
            dataPoint16.LabelBackColor = System.Drawing.Color.DarkRed;
            dataPoint16.LabelBorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.NotSet;
            dataPoint16.LabelForeColor = System.Drawing.Color.White;
            dataPoint17.Color = System.Drawing.Color.Red;
            dataPoint17.Label = "100";
            dataPoint17.LabelBackColor = System.Drawing.Color.DarkRed;
            dataPoint17.LabelForeColor = System.Drawing.Color.White;
            dataPoint18.Color = System.Drawing.Color.Red;
            dataPoint18.Label = "84";
            dataPoint18.LabelBackColor = System.Drawing.Color.DarkRed;
            dataPoint18.LabelForeColor = System.Drawing.Color.White;
            dataPoint19.Color = System.Drawing.Color.Red;
            dataPoint19.Label = "70";
            dataPoint19.LabelBackColor = System.Drawing.Color.DarkRed;
            dataPoint19.LabelForeColor = System.Drawing.Color.White;
            dataPoint20.Color = System.Drawing.Color.Red;
            dataPoint20.Label = "58";
            dataPoint20.LabelBackColor = System.Drawing.Color.DarkRed;
            dataPoint20.LabelForeColor = System.Drawing.Color.White;
            series2.Points.Add(dataPoint11);
            series2.Points.Add(dataPoint12);
            series2.Points.Add(dataPoint13);
            series2.Points.Add(dataPoint14);
            series2.Points.Add(dataPoint15);
            series2.Points.Add(dataPoint16);
            series2.Points.Add(dataPoint17);
            series2.Points.Add(dataPoint18);
            series2.Points.Add(dataPoint19);
            series2.Points.Add(dataPoint20);
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(690, 426);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "Coronavirus Search Numbers";
            title2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            title2.Name = "Title1";
            title2.Text = "Search Popularity of Coronavirus in 2020";
            this.chart1.Titles.Add(title2);
            // 
            // backButton
            // 
            this.backButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backButton.Location = new System.Drawing.Point(323, 453);
            this.backButton.Name = "backButton";
            this.backButton.Size = new System.Drawing.Size(75, 31);
            this.backButton.TabIndex = 1;
            this.backButton.Text = "Back";
            this.backButton.UseVisualStyleBackColor = true;
            this.backButton.Click += new System.EventHandler(this.backButton_Click);
            // 
            // barGraph
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(713, 496);
            this.Controls.Add(this.backButton);
            this.Controls.Add(this.chart1);
            this.Name = "barGraph";
            this.Text = "Bargraph";
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.Button backButton;
    }
}