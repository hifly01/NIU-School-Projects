﻿/********************************************************************
CSCI 473 - Assignment 5 - Spring 2020

Programmers: Theresa Li (Z1814730), Charles Alms (Z1797837) 
Section:    1
TA:         Jennifer Ho & Sridivya Pagadala
Date Due:   4/16/20

Purpose:    This program is teaching us how to build a chess game in C#
*********************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Timers;
using System.Diagnostics;

namespace TheresaLiCharlesAlms_Assign5
{
    public partial class Form1 : Form
    {
        public static Stopwatch theTime; //creates a stopwatch to count the time 

        public static bool whiteFirst = true;       //will be how we switch between each player. White goes first by default
        public static int turncounter = 0;          //turn counter
        public static int whiteLoss = 0;            //counts white captured pieces 
        public static int blackLoss = 0;            //counts black captured pieces
        public static string[,] array;              //game board array to hold the color and pice type

        SolidBrush maroonBrush = new SolidBrush(Color.Maroon); //paints the squares of the board maroon
        SolidBrush whiteBrush = new SolidBrush(Color.White); //and white 

        int startArrayX = 0;    //corresponding start position x pixel  
        int startArrayY = 0;    //corresponding start position y pixel 
        int endArrayX = 0;      //corresponding end position x pixel  
        int endArrayY = 0;      //corresponding end position y pixel 

        int pixelArrayX = 0; //corresponding position x square  
        int pixelArrayY = 0; //corresponding position y square  

        int whitePrisonPlaceX = 0; //x coordinate for being placed in white graveyard 
        int whitePrisonPlaceY = 0; //y coordinate for being placed in white graveyard 
        int blackPrisonPlaceX = 0; //x coordinate for being placed in black graveyard 
        int blackPrisonPlaceY = 0; //y coordinate for being placed in black graveyard 

        public Form1()
        {
            InitializeComponent();

            blackQueen.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackQueen.Parent = chessBoard;

            blackKing.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackKing.Parent = chessBoard;

            blackBishop1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackBishop1.Parent = chessBoard;
            blackBishop2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackBishop2.Parent = chessBoard;

            blackKnight1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackKnight1.Parent = chessBoard;
            blackKnight2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackKnight2.Parent = chessBoard;

            blackRook1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackRook1.Parent = chessBoard;
            blackRook2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackRook2.Parent = chessBoard;

            blackPawn1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn1.Parent = chessBoard;
            blackPawn1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn1.Parent = chessBoard;

            blackPawn2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn2.Parent = chessBoard;
            blackPawn2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn2.Parent = chessBoard;

            blackPawn3.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn3.Parent = chessBoard;
            blackPawn3.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn3.Parent = chessBoard;

            blackPawn4.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn4.Parent = chessBoard;
            blackPawn4.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn4.Parent = chessBoard;

            blackPawn5.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn5.Parent = chessBoard;
            blackPawn5.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn5.Parent = chessBoard;

            blackPawn6.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn6.Parent = chessBoard;
            blackPawn6.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn6.Parent = chessBoard;

            blackPawn7.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn7.Parent = chessBoard;
            blackPawn7.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn7.Parent = chessBoard;

            blackPawn8.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn8.Parent = chessBoard;
            blackPawn8.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn8.Parent = chessBoard;

            whiteQueen.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteQueen.Parent = chessBoard;

            whiteKing.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteKing.Parent = chessBoard;

            whiteBishop1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteBishop1.Parent = chessBoard;
            whiteBishop2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteBishop2.Parent = chessBoard;

            whiteKnight1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteKnight1.Parent = chessBoard;
            whiteKnight2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteKnight2.Parent = chessBoard;

            whiteRook1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteRook1.Parent = chessBoard;
            whiteRook2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteRook2.Parent = chessBoard;

            whitePawn1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn1.Parent = chessBoard;
            whitePawn1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn1.Parent = chessBoard;

            whitePawn2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn2.Parent = chessBoard; 
            whitePawn2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn2.Parent = chessBoard;

            whitePawn3.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn3.Parent = chessBoard;
            whitePawn3.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn3.Parent = chessBoard;

            whitePawn4.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn4.Parent = chessBoard;
            whitePawn4.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn4.Parent = chessBoard;

            whitePawn5.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn5.Parent = chessBoard;
            whitePawn5.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn5.Parent = chessBoard;

            whitePawn6.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn6.Parent = chessBoard;
            whitePawn6.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn6.Parent = chessBoard;

            whitePawn7.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn7.Parent = chessBoard;
            whitePawn7.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn7.Parent = chessBoard;

            whitePawn8.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn8.Parent = chessBoard;
            whitePawn8.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn8.Parent = chessBoard;

            settingUpChessPieces(); //pieces will move to their respective starting location 

            createArray();              //create the game board array

            chessBoard.Enabled = false;     //do not want the players moving pieces before the game starts
            blackGraveYard.Enabled = false;     //disable the graveyards
            whiteGraveYard.Enabled = false;

            whiteTurn.Visible = false;          //turn off turn labels
            blackTurn.Visible = false;

            theTime = new Stopwatch(); //created a stopwatch

            surrender_Button.Enabled = false; //can't surrender when the game hasn't started 
        }

        public void settingUpChessPieces() //pieces will move to their respective starting location 
        {
            blackQueen.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackQueen.Parent = chessBoard;

            blackKing.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackKing.Parent = chessBoard;

            blackBishop1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackBishop1.Parent = chessBoard;
            blackBishop2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackBishop2.Parent = chessBoard;

            blackKnight1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackKnight1.Parent = chessBoard;
            blackKnight2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackKnight2.Parent = chessBoard;

            blackRook1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackRook1.Parent = chessBoard;
            blackRook2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackRook2.Parent = chessBoard;

            blackPawn1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn1.Parent = chessBoard;
            blackPawn1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn1.Parent = chessBoard;

            blackPawn2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn2.Parent = chessBoard;
            blackPawn2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn2.Parent = chessBoard;

            blackPawn3.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn3.Parent = chessBoard;
            blackPawn3.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn3.Parent = chessBoard;

            blackPawn4.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn4.Parent = chessBoard;
            blackPawn4.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn4.Parent = chessBoard;

            blackPawn5.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn5.Parent = chessBoard;
            blackPawn5.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn5.Parent = chessBoard;

            blackPawn6.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn6.Parent = chessBoard;
            blackPawn6.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn6.Parent = chessBoard;

            blackPawn7.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn7.Parent = chessBoard; 
            blackPawn7.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn7.Parent = chessBoard;

            blackPawn8.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn8.Parent = chessBoard;
            blackPawn8.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            blackPawn8.Parent = chessBoard;

            whiteQueen.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteQueen.Parent = chessBoard;

            whiteKing.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteKing.Parent = chessBoard;

            whiteBishop1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteBishop1.Parent = chessBoard;
            whiteBishop2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteBishop2.Parent = chessBoard;

            whiteKnight1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteKnight1.Parent = chessBoard;
            whiteKnight2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteKnight2.Parent = chessBoard;

            whiteRook1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteRook1.Parent = chessBoard;
            whiteRook2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whiteRook2.Parent = chessBoard;

            whitePawn1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn1.Parent = chessBoard; 
            whitePawn1.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn1.Parent = chessBoard;

            whitePawn2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn2.Parent = chessBoard; 
            whitePawn2.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn2.Parent = chessBoard;

            whitePawn3.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn3.Parent = chessBoard;
            whitePawn3.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn3.Parent = chessBoard;

            whitePawn4.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn4.Parent = chessBoard;
            whitePawn4.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn4.Parent = chessBoard;

            whitePawn5.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn5.Parent = chessBoard;
            whitePawn5.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn5.Parent = chessBoard;

            whitePawn6.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn6.Parent = chessBoard;
            whitePawn6.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn6.Parent = chessBoard;

            whitePawn7.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn7.Parent = chessBoard;
            whitePawn7.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn7.Parent = chessBoard;

            whitePawn8.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn8.Parent = chessBoard;
            whitePawn8.BackColor = Color.Transparent; //making the background of pieces transparent and adding the chessboard as background
            whitePawn8.Parent = chessBoard;

            //movces the pieces to the starting locations
            blackRook1.Location = new Point(6, 0);
            blackKnight1.Location = new Point(70, 0);
            blackBishop1.Location = new Point(138, 0);
            blackQueen.Location = new Point(197, 5);
            blackKing.Location = new Point(261, 5);
            blackBishop2.Location = new Point(329, 0);
            blackKnight2.Location = new Point(390, 0);
            blackRook2.Location = new Point(454, 0);

            blackPawn1.Location = new Point(8, 64);
            blackPawn2.Location = new Point(72, 64);
            blackPawn3.Location = new Point(136, 64);
            blackPawn4.Location = new Point(200, 64);
            blackPawn5.Location = new Point(264, 64);
            blackPawn6.Location = new Point(328, 64);
            blackPawn7.Location = new Point(392, 64);
            blackPawn8.Location = new Point(456, 64);

            whiteRook1.Location = new Point(6, 448);
            whiteKnight1.Location = new Point(70, 448);
            whiteBishop1.Location = new Point(136, 448);
            whiteQueen.Location = new Point(195, 453);
            whiteKing.Location = new Point(260, 453);
            whiteBishop2.Location = new Point(327, 448);
            whiteKnight2.Location = new Point(390, 448);
            whiteRook2.Location = new Point(454, 448);

            whitePawn1.Location = new Point(6, 384);
            whitePawn2.Location = new Point(70, 384);
            whitePawn3.Location = new Point(134, 384);
            whitePawn4.Location = new Point(198, 384);
            whitePawn5.Location = new Point(262, 384);
            whitePawn6.Location = new Point(326, 384);
            whitePawn7.Location = new Point(390, 384);
            whitePawn8.Location = new Point(454, 384);
        }

        private void Start_Button_Click(object sender, EventArgs e) //if the start button was clicked 
        {
            theTime.Reset();            //stopwatch will get reset
            settingUpChessPieces();     //set up the pieces
            chessBoard.Enabled = true;  //user can click the board now 
            theTime.Start();            //stopwatch will start

            Start_Button.Enabled = false;       //when start is clicked, 
            surrender_Button.Enabled = true;    //surrender is enabled and start is disabled 
            createArray();                      //create the game board array

            whitebutton.Enabled = false;        //when game starts, can't choose which color goes first 
            blackbutton.Enabled = false;
            randombutton.Enabled = false;
            feedback_TextBox.Clear();           //feedback is cleared 

            turncounter = 0;    //amount of turns reset 
            whiteLoss = 0;      //pieces white lost reset 
            blackLoss = 0;      //pieces black lost reset 

            if (whiteFirst == true)             //if whiteFirst is true, it is white players turn
            {
                feedback_TextBox.AppendText("White will go first"); 
                whiteTurn.Visible = true; //reminder that white can go first 
            }
            else if (whiteFirst == false)       //else black players turn
            {
                feedback_TextBox.AppendText("Black will go first");
                blackTurn.Visible = true; //reminder that black can go first 
            }
        }

        private void surrender_Button_Click(object sender, EventArgs e) //if the stop button was clicked 
        {
            chessBoard.Enabled = false;         //disable the board
            theTime.Stop();                     //stop the timer
            surrender_Button.Enabled = false;   //when surrender is clicked
            Start_Button.Enabled = true;        //start is enabled and surrender is disabled

            whitebutton.Enabled = true;        //can now select which color goes first 
            blackbutton.Enabled = true;
            randombutton.Enabled = true;

            feedback_TextBox.Clear();      //clear feedback 

            if (whiteFirst == true)         //if whites turn and they surrendered
            {
                feedback_TextBox.AppendText("Game Over. White surrendered");
            }
            else if (whiteFirst == false)   //if blacks turn and they surrendered
            {
                feedback_TextBox.AppendText("Game Over. Black surrendered");
            }
            //display game stats
            feedback_TextBox.AppendText("\n\nTurns taken: " + turncounter);
            feedback_TextBox.AppendText("\nTime taken: " + theTime.Elapsed);
            feedback_TextBox.AppendText("\nWhite Player losses: " + whiteLoss);
            feedback_TextBox.AppendText("\nBlack Player losses: " + blackLoss);
        }

        //button for a random player to go first
        private void randombutton_Click(object sender, EventArgs e)
        {
            feedback_TextBox.Clear();
            feedback_TextBox.AppendText("Random player will go first");

            Random rnd = new Random();
            int randomNum = rnd.Next(1, 3);         //generate a number between 1 and 3
            createArray();              //create the game board array

            if (randomNum == 1)         //if 1, white player goes first
            {
                whiteFirst = true;
            }
            else if (randomNum != 1)        //if nto 1, black goes first
            {
                whiteFirst = false;
            }
        }

        //sets the first turn to white 
        private void whitebutton_Click(object sender, EventArgs e)
        {
            feedback_TextBox.Clear();
            feedback_TextBox.AppendText("White will go first");
            createArray();              //create the game board array
            whiteFirst = true;          //white can now move pieces 
        }

        //sets the first turn to black
        private void blackbutton_Click(object sender, EventArgs e)
        {
            feedback_TextBox.Clear();
            feedback_TextBox.AppendText("Black will go first");
            createArray();              //create the game board array
            whiteFirst = false;         //black can now move pieces 
        }

        //draws the chess board
        private void chessBoard_Paint(object sender, PaintEventArgs e) //draws the checkerboard patter
        {
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    if ((j % 2 == 0 && i % 2 == 0) || (j % 2 != 0 && i % 2 != 0))
                    {
                        e.Graphics.FillRectangle(maroonBrush, i * 64, j * 64, 64, 64); //draws all the maroon squares on the chessboard
                    }
                    else if ((j % 2 == 0 && i % 2 != 0) || (j % 2 != 0 && i % 2 == 0))
                    {
                        e.Graphics.FillRectangle(whiteBrush, i * 64, j * 64, 64, 64); //draws all the white squares on the chessboard
                    }
                }
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackQueenLocation = Point.Empty;
        int startblackQueen = 0;
        int resetYBlackQueen = 0;
        int resetXBlackQueen = 0;
        private void blackQueen_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackQueen.BackColor = Color.Gold;             //when clicked, backcolor is yellow 
                blackQueenLocation = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackQueen = blackQueen.Location.X;      //grabs starting location x
                resetYBlackQueen = blackQueen.Location.Y;      //grabs starting location y 

                if (startblackQueen == 0) //if it is the first turn by default will be the following location 
                {
                    startArrayX = 0;
                    startArrayY = 3;
                    startblackQueen++; //not first turn anymore
                }
                pixelToArrayStart(blackQueen.Location.X, blackQueen.Location.Y); //converts pixel location to squares 
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackQueen_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackQueen.BackColor = Color.Transparent; //when not clicked, background will be transparent 
            blackQueenLocation = Point.Empty; //clear starting point 

            pixelToArrayEnd(blackQueen.Location.X, blackQueen.Location.Y); //convert pixels to squares 

            moveQueen(blackQueen, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackQueen, resetYBlackQueen); //call move queen 
        }

        //the actions done when the mouse moves
        private void blackQueen_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackQueenLocation != Point.Empty) //if the queen has a location 
            {
                Point newlocation = this.blackQueen.Location; //get the location 
                newlocation.X += e.X - blackQueenLocation.X; //set the new location x
                newlocation.Y += e.Y - blackQueenLocation.Y; //set the new location y 
                this.blackQueen.Location = newlocation; //then take the image and put it there 
                Cursor.Current = Cursors.Hand; //cursor will be a hand 
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackKingLocation = Point.Empty;
        int startblackKing = 0;
        int resetYBlackKing = 0;
        int resetXBlackKing = 0;
        private void blackKing_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackKing.BackColor = Color.Gold;
                blackKingLocation = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackKing = blackKing.Location.X;
                resetYBlackKing = blackKing.Location.Y;

                if (startblackKing == 0)
                {
                    startArrayX = 0;
                    startArrayY = 4;
                    startblackKing++;
                }
                pixelToArrayStart(blackKing.Location.X, blackKing.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackKing_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackKing.BackColor = Color.Transparent;
            blackKingLocation = Point.Empty;
            pixelToArrayEnd(blackKing.Location.X, blackKing.Location.Y);

            moveKing(blackKing, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackKing, resetYBlackKing);
        }

        //the actions done when the mouse moves
        private void blackKing_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackKingLocation != Point.Empty)
            {
                Point newlocation = this.blackKing.Location;
                newlocation.X += e.X - blackKingLocation.X;
                newlocation.Y += e.Y - blackKingLocation.Y;
                this.blackKing.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackBishop1Location = Point.Empty;
        int startblackBishop1 = 0;
        int resetYBlackBishop1 = 0;
        int resetXBlackBishop1 = 0;
        private void blackBishop1_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackBishop1.BackColor = Color.Gold;
                blackBishop1Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackBishop1 = blackBishop1.Location.X;
                resetYBlackBishop1 = blackBishop1.Location.Y;

                if (startblackBishop1 == 0)
                {
                    startArrayX = 0;
                    startArrayY = 5;
                    startblackBishop1++;
                }
                pixelToArrayStart(blackBishop1.Location.X, blackBishop1.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackBishop1_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackBishop1.BackColor = Color.Transparent;
            blackBishop1Location = Point.Empty;
            pixelToArrayEnd(blackBishop1.Location.X, blackBishop1.Location.Y);

            moveBishop(blackBishop1, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackBishop1, resetYBlackBishop1);
        }

        //the actions done when the mouse moves
        private void blackBishop1_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackBishop1Location != Point.Empty)
            {
                Point newlocation = this.blackBishop1.Location;
                newlocation.X += e.X - blackBishop1Location.X;
                newlocation.Y += e.Y - blackBishop1Location.Y;
                this.blackBishop1.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackKnight1Location = Point.Empty;
        int startblackKnight1 = 0;
        int resetYBlackKnight1 = 0;
        int resetXBlackKnight1 = 0;
        private void blackKnight1_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackKnight1.BackColor = Color.Gold;
                blackKnight1Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackKnight1 = blackKnight1.Location.X;
                resetYBlackKnight1 = blackKnight1.Location.Y;

                if (startblackKnight1 == 0)
                {
                    startArrayX = 0;
                    startArrayY = 1;
                    startblackKnight1++;
                }
                pixelToArrayStart(blackKnight1.Location.X, blackKnight1.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackKnight1_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackKnight1.BackColor = Color.Transparent;
            blackKnight1Location = Point.Empty;
            pixelToArrayEnd(blackKnight1.Location.X, blackKnight1.Location.Y);

            moveKnight(blackKnight1, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackKnight1, resetYBlackKnight1);
        }

        //the actions done when the mouse moves
        private void blackKnight1_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackKnight1Location != Point.Empty)
            {
                Point newlocation = this.blackKnight1.Location;
                newlocation.X += e.X - blackKnight1Location.X;
                newlocation.Y += e.Y - blackKnight1Location.Y;
                this.blackKnight1.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackBishop2Location = Point.Empty;
        int startblackBishop2 = 0;
        int resetYBlackBishop2 = 0;
        int resetXBlackBishop2 = 0;
        private void blackBishop2_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackBishop2.BackColor = Color.Gold;
                blackBishop2Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackBishop2 = blackBishop2.Location.X;
                resetYBlackBishop2 = blackBishop2.Location.Y;

                if (startblackBishop2 == 0)
                {
                    startArrayX = 0;
                    startArrayY = 5;
                    startblackBishop2++;
                }
                pixelToArrayStart(blackBishop2.Location.X, blackBishop2.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackBishop2_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackBishop2.BackColor = Color.Transparent;
            blackBishop2Location = Point.Empty;
            pixelToArrayEnd(blackBishop2.Location.X, blackBishop2.Location.Y);

            moveBishop(blackBishop2, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackBishop2, resetYBlackBishop2);
        }

        //the actions done when the mouse moves
        private void blackBishop2_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackBishop2Location != Point.Empty)
            {
                Point newlocation = this.blackBishop2.Location;
                newlocation.X += e.X - blackBishop2Location.X;
                newlocation.Y += e.Y - blackBishop2Location.Y;
                this.blackBishop2.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackKnight2Location = Point.Empty;
        int startblackKnight2 = 0;
        int resetYBlackKnight2 = 0;
        int resetXBlackKnight2 = 0;
        private void blackKnight2_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackKnight2.BackColor = Color.Gold;
                blackKnight2Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackKnight2 = blackKnight2.Location.X;
                resetYBlackKnight2 = blackKnight2.Location.Y;

                if (startblackKnight2 == 0)
                {
                    startArrayX = 0;
                    startArrayY = 6;
                    startblackKnight2++;
                }
                pixelToArrayStart(blackKnight2.Location.X, blackKnight2.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackKnight2_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackKnight2.BackColor = Color.Transparent;
            blackKnight2Location = Point.Empty;
            pixelToArrayEnd(blackKnight2.Location.X, blackKnight2.Location.Y);

            moveKnight(blackKnight2, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackKnight2, resetYBlackKnight2);
        }

        //the actions done when the mouse moves
        private void blackKnight2_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackKnight2Location != Point.Empty)
            {
                Point newlocation = this.blackKnight2.Location;
                newlocation.X += e.X - blackKnight2Location.X;
                newlocation.Y += e.Y - blackKnight2Location.Y;
                this.blackKnight2.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackRook1Location = Point.Empty;
        int startBlackRook1 = 0;
        int resetYBlackRook1 = 0;
        int resetXBlackRook1 = 0;
        private void blackRook1_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackRook1.BackColor = Color.Gold;
                blackRook1Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackRook1 = blackRook1.Location.X;
                resetYBlackRook1 = blackRook1.Location.Y;

                if (startBlackRook1 == 0)
                {
                    startArrayX = 0;
                    startArrayY = 0;
                    startBlackRook1++;
                }
                pixelToArrayStart(blackRook1.Location.X, blackRook1.Location.Y);

            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackRook1_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackRook1.BackColor = Color.Transparent;
            blackRook1Location = Point.Empty;
            pixelToArrayEnd(blackRook1.Location.X, blackRook1.Location.Y);

            moveRook(blackRook1, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackRook1, resetYBlackRook1);
        }

        //the actions done when the mouse moves
        private void blackRook1_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackRook1Location != Point.Empty)
            {
                Point newlocation = this.blackRook1.Location;
                newlocation.X += e.X - blackRook1Location.X;
                newlocation.Y += e.Y - blackRook1Location.Y;
                this.blackRook1.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackRook2Location = Point.Empty;
        int startBlackRook2 = 0;
        int resetYBlackRook2 = 0;
        int resetXBlackRook2 = 0;
        private void blackRook2_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackRook2.BackColor = Color.Gold;
                blackRook2Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackRook2 = blackRook2.Location.X;
                resetYBlackRook2 = blackRook2.Location.Y;

                if (startBlackRook2 == 0)
                {
                    startArrayX = 0;
                    startArrayY = 7;
                    startBlackRook2++;
                }
                pixelToArrayStart(blackRook2.Location.X, blackRook2.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackRook2_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackRook2.BackColor = Color.Transparent;
            blackRook2Location = Point.Empty;
            pixelToArrayEnd(blackRook2.Location.X, blackRook2.Location.Y);

            moveRook(blackRook2, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackRook2, resetYBlackRook2);
        }

        //the actions done when the mouse moves
        private void blackRook2_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackRook2Location != Point.Empty)
            {
                Point newlocation = this.blackRook2.Location;
                newlocation.X += e.X - blackRook2Location.X;
                newlocation.Y += e.Y - blackRook2Location.Y;
                this.blackRook2.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackPawn1Location = Point.Empty;
        int startblackPawn1 = 0;
        int resetYBlackPawn1 = 0;
        int resetXBlackPawn1 = 0;
        private void blackPawn1_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackPawn1.BackColor = Color.Gold;
                blackPawn1Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackPawn1 = blackPawn1.Location.X;
                resetYBlackPawn1 = blackPawn1.Location.Y;

                if (startblackPawn1 == 0)
                {
                    startArrayX = 1;
                    startArrayY = 0;
                    startblackPawn1++;
                }
                pixelToArrayStart(blackPawn1.Location.X, blackPawn1.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackPawn1_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackPawn1.BackColor = Color.Transparent;
            blackPawn1Location = Point.Empty;
            pixelToArrayEnd(blackPawn1.Location.X, blackPawn1.Location.Y);

            movePawn(blackPawn1, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackPawn1, resetYBlackPawn1);
        }

        //the actions done when the mouse moves
        private void blackPawn1_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackPawn1Location != Point.Empty)
            {
                Point newlocation = this.blackPawn1.Location;
                newlocation.X += e.X - blackPawn1Location.X;
                newlocation.Y += e.Y - blackPawn1Location.Y;
                this.blackPawn1.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackPawn2Location = Point.Empty;
        int startblackPawn2 = 0;
        int resetYBlackPawn2 = 0;
        int resetXBlackPawn2 = 0;
        private void blackPawn2_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackPawn2.BackColor = Color.Gold;
                blackPawn2Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackPawn2 = blackPawn2.Location.X;
                resetYBlackPawn2 = blackPawn2.Location.Y;

                if (startblackPawn2 == 0)
                {
                    startArrayX = 1;
                    startArrayY = 1;
                    startblackPawn2++;
                }
                pixelToArrayStart(blackPawn2.Location.X, blackPawn2.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackPawn2_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackPawn2.BackColor = Color.Transparent;
            blackPawn2Location = Point.Empty;
            pixelToArrayEnd(blackPawn2.Location.X, blackPawn2.Location.Y);

            movePawn(blackPawn2, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackPawn2, resetYBlackPawn2);
        }

        //the actions done when the mouse moves
        private void blackPawn2_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackPawn2Location != Point.Empty)
            {
                Point newlocation = this.blackPawn2.Location;
                newlocation.X += e.X - blackPawn2Location.X;
                newlocation.Y += e.Y - blackPawn2Location.Y;
                this.blackPawn2.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackPawn3Location = Point.Empty;
        int startblackPawn3 = 0;
        int resetYBlackPawn3 = 0;
        int resetXBlackPawn3 = 0;
        private void blackPawn3_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackPawn3.BackColor = Color.Gold;
                blackPawn3Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackPawn3 = blackPawn3.Location.X;
                resetYBlackPawn3 = blackPawn3.Location.Y;

                if (startblackPawn3 == 0)
                {
                    startArrayX = 1;
                    startArrayY = 2;
                    startblackPawn3++;
                }
                pixelToArrayStart(blackPawn3.Location.X, blackPawn3.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackPawn3_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackPawn3.BackColor = Color.Transparent;
            blackPawn3Location = Point.Empty;
            pixelToArrayEnd(blackPawn3.Location.X, blackPawn3.Location.Y);

            movePawn(blackPawn3, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackPawn3, resetYBlackPawn3);
        }

        //the actions done when the mouse moves
        private void blackPawn3_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackPawn3Location != Point.Empty)
            {
                Point newlocation = this.blackPawn3.Location;
                newlocation.X += e.X - blackPawn3Location.X;
                newlocation.Y += e.Y - blackPawn3Location.Y;
                this.blackPawn3.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackPawn4Location = Point.Empty;
        int startblackPawn4 = 0;
        int resetYBlackPawn4 = 0;
        int resetXBlackPawn4 = 0;
        private void blackPawn4_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackPawn4.BackColor = Color.Gold;
                blackPawn4Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackPawn4 = blackPawn4.Location.X;
                resetYBlackPawn4 = blackPawn4.Location.Y;

                if (startblackPawn4 == 0)
                {
                    startArrayX = 1;
                    startArrayY = 3;
                    startblackPawn4++;
                }
                pixelToArrayStart(blackPawn4.Location.X, blackPawn4.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackPawn4_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackPawn4.BackColor = Color.Transparent;
            blackPawn4Location = Point.Empty;
            pixelToArrayEnd(blackPawn4.Location.X, blackPawn4.Location.Y);

            movePawn(blackPawn4, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackPawn4, resetYBlackPawn4);
        }

        //the actions done when the mouse moves
        private void blackPawn4_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackPawn4Location != Point.Empty)
            {
                Point newlocation = this.blackPawn4.Location;
                newlocation.X += e.X - blackPawn4Location.X;
                newlocation.Y += e.Y - blackPawn4Location.Y;
                this.blackPawn4.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackPawn5Location = Point.Empty;
        int startblackPawn5 = 0;
        int resetYBlackPawn5 = 0;
        int resetXBlackPawn5 = 0;
        private void blackPawn5_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackPawn5.BackColor = Color.Gold;
                blackPawn5Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackPawn5 = blackPawn5.Location.X;
                resetYBlackPawn5 = blackPawn5.Location.Y;

                if (startblackPawn5 == 0)
                {
                    startArrayX = 1;
                    startArrayY = 4;
                    startblackPawn5++;
                }
                pixelToArrayStart(blackPawn5.Location.X, blackPawn5.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackPawn5_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackPawn5.BackColor = Color.Transparent;
            blackPawn5Location = Point.Empty;
            pixelToArrayEnd(blackPawn5.Location.X, blackPawn5.Location.Y);

            movePawn(blackPawn5, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackPawn5, resetYBlackPawn5);
        }

        //the actions done when the mouse moves
        private void blackPawn5_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackPawn5Location != Point.Empty)
            {
                Point newlocation = this.blackPawn5.Location;
                newlocation.X += e.X - blackPawn5Location.X;
                newlocation.Y += e.Y - blackPawn5Location.Y;
                this.blackPawn5.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackPawn6Location = Point.Empty;
        int startblackPawn6 = 0;
        int resetYBlackPawn6 = 0;
        int resetXBlackPawn6 = 0;
        private void blackPawn6_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackPawn6.BackColor = Color.Gold;
                blackPawn6Location = new Point(e.X, e.Y);      //grabs the starting points

                resetXBlackPawn6 = blackPawn6.Location.X;
                resetYBlackPawn6 = blackPawn6.Location.Y;

                if (startblackPawn6 == 0)
                {
                    startArrayX = 1;
                    startArrayY = 5;
                    startblackPawn6++;
                }
                pixelToArrayStart(blackPawn6.Location.X, blackPawn6.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackPawn6_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackPawn6.BackColor = Color.Transparent;
            blackPawn6Location = Point.Empty;
            pixelToArrayEnd(blackPawn6.Location.X, blackPawn6.Location.Y);

            movePawn(blackPawn6, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackPawn6, resetYBlackPawn6);
        }

        //the actions done when the mouse moves
        private void blackPawn6_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackPawn6Location != Point.Empty)
            {
                Point newlocation = this.blackPawn6.Location;
                newlocation.X += e.X - blackPawn6Location.X;
                newlocation.Y += e.Y - blackPawn6Location.Y;
                this.blackPawn6.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackPawn7Location = Point.Empty;
        int startblackPawn7 = 0;
        int resetYBlackPawn7 = 0;
        int resetXBlackPawn7 = 0;
        private void blackPawn7_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackPawn7.BackColor = Color.Gold;
                blackPawn7Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackPawn7 = blackPawn7.Location.X;
                resetYBlackPawn7 = blackPawn7.Location.Y;

                if (startblackPawn7 == 0)
                {
                    startArrayX = 1;
                    startArrayY = 6;
                    startblackPawn7++;
                }
                pixelToArrayStart(blackPawn7.Location.X, blackPawn7.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackPawn7_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackPawn7.BackColor = Color.Transparent;
            blackPawn7Location = Point.Empty;
            pixelToArrayEnd(blackPawn7.Location.X, blackPawn7.Location.Y);

            movePawn(blackPawn7, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackPawn7, resetYBlackPawn7);
        }

        //the actions done when the mouse moves
        private void blackPawn7_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackPawn7Location != Point.Empty)
            {
                Point newlocation = this.blackPawn7.Location;
                newlocation.X += e.X - blackPawn7Location.X;
                newlocation.Y += e.Y - blackPawn7Location.Y;
                this.blackPawn7.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point blackPawn8Location = Point.Empty;
        int startblackPawn8 = 0;
        int resetYBlackPawn8 = 0;
        int resetXBlackPawn8 = 0;
        private void blackPawn8_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                blackPawn8.BackColor = Color.Gold;
                blackPawn8Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXBlackPawn8 = blackPawn8.Location.X;
                resetYBlackPawn8 = blackPawn8.Location.Y;

                if (startblackPawn8 == 0)
                {
                    startArrayX = 1;
                    startArrayY = 7;
                    startblackPawn8++;
                }
                pixelToArrayStart(blackPawn8.Location.X, blackPawn8.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void blackPawn8_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            blackPawn8.BackColor = Color.Transparent;
            blackPawn8Location = Point.Empty;
            pixelToArrayEnd(blackPawn8.Location.X, blackPawn8.Location.Y);
            movePawn(blackPawn8, startArrayX, startArrayY, endArrayX, endArrayY, resetXBlackPawn8, resetYBlackPawn8);
        }

        //the actions done when the mouse moves
        private void blackPawn8_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (blackPawn8Location != Point.Empty)
            {
                Point newlocation = this.blackPawn8.Location;
                newlocation.X += e.X - blackPawn8Location.X;
                newlocation.Y += e.Y - blackPawn8Location.Y;
                this.blackPawn8.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whiteQueenLocation = Point.Empty;
        int startwhiteQueen = 0;
        int resetYWhiteQueen = 0;
        int resetXWhiteQueen = 0;
        private void whiteQueen_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whiteQueen.BackColor = Color.Gold;
                whiteQueenLocation = new Point(e.X, e.Y);      //grabs the starting points

                resetXWhiteQueen = whiteQueen.Location.X;
                resetYWhiteQueen = whiteQueen.Location.Y;

                if (startwhiteQueen == 0)
                {
                    startArrayX = 7;
                    startArrayY = 3;
                    startwhiteQueen++;
                }
                pixelToArrayStart(whiteQueen.Location.X, whiteQueen.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whiteQueen_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whiteQueen.BackColor = Color.Transparent;
            whiteQueenLocation = Point.Empty;

            pixelToArrayEnd(whiteQueen.Location.X, whiteQueen.Location.Y);

            moveQueen(whiteQueen, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhiteQueen, resetYWhiteQueen);
        }

        //the actions done when the mouse moves
        private void whiteQueen_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whiteQueenLocation != Point.Empty)
            {
                Point newlocation = this.whiteQueen.Location;
                newlocation.X += e.X - whiteQueenLocation.X;
                newlocation.Y += e.Y - whiteQueenLocation.Y;
                this.whiteQueen.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whiteKingLocation = Point.Empty;
        int startwhiteKing = 0;
        int resetYWhiteKing = 0;
        int resetXWhiteKing = 0;
        private void whiteKing_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whiteKing.BackColor = Color.Gold;
                whiteKingLocation = new Point(e.X, e.Y);      //grabs the starting points
                resetXWhiteKing = whiteKing.Location.X;
                resetYWhiteKing = whiteKing.Location.Y;

                if (startwhiteKing == 0)
                {
                    startArrayX = 7;
                    startArrayY = 4;
                    startwhiteKing++;
                }
                pixelToArrayStart(whiteKing.Location.X, whiteKing.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whiteKing_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whiteKing.BackColor = Color.Transparent;
            whiteKingLocation = Point.Empty;
            pixelToArrayEnd(whiteKing.Location.X, whiteKing.Location.Y);

            moveKing(whiteKing, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhiteKing, resetYWhiteKing);
        }

        //the actions done when the mouse moves
        private void whiteKing_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whiteKingLocation != Point.Empty)
            {
                Point newlocation = this.whiteKing.Location;
                newlocation.X += e.X - whiteKingLocation.X;
                newlocation.Y += e.Y - whiteKingLocation.Y;
                this.whiteKing.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whiteBishop1Location = Point.Empty;
        int startwhiteBishop1 = 0;
        int resetYWhiteBishop1 = 0;
        int resetXWhiteBishop1 = 0;
        private void whiteBishop1_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whiteBishop1.BackColor = Color.Gold;
                whiteBishop1Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXWhiteBishop1 = whiteBishop1.Location.X;
                resetYWhiteBishop1 = whiteBishop1.Location.Y;

                if (startwhiteBishop1 == 0)
                {
                    startArrayX = 7;
                    startArrayY = 2;
                    startwhiteBishop1++;
                }
                pixelToArrayStart(whiteBishop1.Location.X, whiteBishop1.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whiteBishop1_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whiteBishop1.BackColor = Color.Transparent;
            whiteBishop1Location = Point.Empty;
            pixelToArrayEnd(whiteBishop1.Location.X, whiteBishop1.Location.Y);

            moveBishop(whiteBishop1, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhiteBishop1, resetYWhiteBishop1);
        }

        //the actions done when the mouse moves
        private void whiteBishop1_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whiteBishop1Location != Point.Empty)
            {
                Point newlocation = this.whiteBishop1.Location;
                newlocation.X += e.X - whiteBishop1Location.X;
                newlocation.Y += e.Y - whiteBishop1Location.Y;
                this.whiteBishop1.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whiteKnight1Location = Point.Empty;
        int startwhiteKnight1 = 0;
        int resetYWhiteKnight1 = 0;
        int resetXWhiteKnight1 = 0;
        private void whiteKnight1_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whiteKnight1.BackColor = Color.Gold;
                whiteKnight1Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXWhiteKnight1 = whiteKnight1.Location.X;
                resetYWhiteKnight1 = whiteKnight1.Location.Y;

                if (startwhiteKnight1 == 0)
                {
                    startArrayX = 7;
                    startArrayY = 1;
                    startwhiteKnight1++;
                }
                pixelToArrayStart(whiteKnight1.Location.X, whiteKnight1.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whiteKnight1_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whiteKnight1.BackColor = Color.Transparent;
            whiteKnight1Location = Point.Empty;
            pixelToArrayEnd(whiteKnight1.Location.X, whiteKnight1.Location.Y);

            moveKnight(whiteKnight1, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhiteKnight1, resetYWhiteKnight1);
        }

        //the actions done when the mouse moves
        private void whiteKnight1_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whiteKnight1Location != Point.Empty)
            {
                Point newlocation = this.whiteKnight1.Location;
                newlocation.X += e.X - whiteKnight1Location.X;
                newlocation.Y += e.Y - whiteKnight1Location.Y;
                this.whiteKnight1.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whiteBishop2Location = Point.Empty;
        int startwhiteBishop2 = 0;
        int resetYWhiteBishop2 = 0;
        int resetXWhiteBishop2 = 0;
        private void whiteBishop2_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whiteBishop2.BackColor = Color.Gold;
                whiteBishop2Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXWhiteBishop2 = whiteBishop2.Location.X;
                resetYWhiteBishop2 = whiteBishop2.Location.Y;

                if (startwhiteBishop2 == 0)
                {
                    startArrayX = 7;
                    startArrayY = 5;
                    startwhiteBishop2++;
                }
                pixelToArrayStart(whiteBishop2.Location.X, whiteBishop2.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whiteBishop2_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whiteBishop2.BackColor = Color.Transparent;
            whiteBishop2Location = Point.Empty;
            pixelToArrayEnd(whiteBishop2.Location.X, whiteBishop2.Location.Y);

            moveBishop(whiteBishop2, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhiteBishop2, resetYWhiteBishop2);
        }

        //the actions done when the mouse moves
        private void whiteBishop2_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whiteBishop2Location != Point.Empty)
            {
                Point newlocation = this.whiteBishop2.Location;
                newlocation.X += e.X - whiteBishop2Location.X;
                newlocation.Y += e.Y - whiteBishop2Location.Y;
                this.whiteBishop2.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whiteKnight2Location = Point.Empty;
        int startwhiteKnight2 = 0;
        int resetYWhiteKnight2 = 0;
        int resetXWhiteKnight2 = 0;
        private void whiteKnight2_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whiteKnight2.BackColor = Color.Gold;
                whiteKnight2Location = new Point(e.X, e.Y);      //grabs the starting points

                resetXWhiteKnight2 = whiteKnight2.Location.X;
                resetYWhiteKnight2 = whiteKnight2.Location.Y;

                if (startwhiteKnight2 == 0)
                {
                    startArrayX = 7;
                    startArrayY = 6;
                    startwhiteKnight2++;
                }
                pixelToArrayStart(whiteKnight2.Location.X, whiteKnight2.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whiteKnight2_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whiteKnight2.BackColor = Color.Transparent;
            whiteKnight2Location = Point.Empty;

            pixelToArrayEnd(whiteKnight2.Location.X, whiteKnight2.Location.Y);

            moveKnight(whiteKnight2, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhiteKnight2, resetYWhiteKnight2);
        }

        //the actions done when the mouse moves
        private void whiteKnight2_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whiteKnight2Location != Point.Empty)
            {
                Point newlocation = this.whiteKnight2.Location;
                newlocation.X += e.X - whiteKnight2Location.X;
                newlocation.Y += e.Y - whiteKnight2Location.Y;
                this.whiteKnight2.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whiteRook1Location = Point.Empty;
        int startwhiteRook1 = 0;
        int resetYWhiteRook1 = 0;
        int resetXWhiteRook1 = 0;
        private void whiteRook1_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whiteRook1.BackColor = Color.Gold;
                whiteRook1Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXWhiteRook1 = whiteRook1.Location.X;
                resetYWhiteRook1 = whiteRook1.Location.Y;

                if (startwhiteRook1 == 0)
                {
                    startArrayX = 7;
                    startArrayY = 0;
                    startwhiteRook1++;
                }
                pixelToArrayStart(whiteRook1.Location.X, whiteRook1.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whiteRook1_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whiteRook1.BackColor = Color.Transparent;
            whiteRook1Location = Point.Empty;

            pixelToArrayEnd(whiteRook1.Location.X, whiteRook1.Location.Y);

            moveRook(whiteRook1, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhiteRook1, resetYWhiteRook1);
        }

        //the actions done when the mouse moves
        private void whiteRook1_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whiteRook1Location != Point.Empty)
            {
                Point newlocation = this.whiteRook1.Location;
                newlocation.X += e.X - whiteRook1Location.X;
                newlocation.Y += e.Y - whiteRook1Location.Y;
                this.whiteRook1.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whiteRook2Location = Point.Empty;
        int startwhiteRook2 = 0;
        int resetYWhiteRook2 = 0;
        int resetXWhiteRook2 = 0;
        private void whiteRook2_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whiteRook2.BackColor = Color.Gold;
                whiteRook2Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXWhiteRook2 = whiteRook2.Location.X;
                resetYWhiteRook2 = whiteRook2.Location.Y;

                if (startwhiteRook2 == 0)
                {
                    startArrayX = 7;
                    startArrayY = 7;
                    startwhiteRook2++;
                }
                pixelToArrayStart(whiteRook2.Location.X, whiteRook2.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whiteRook2_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whiteRook2.BackColor = Color.Transparent;
            whiteRook2Location = Point.Empty;
            pixelToArrayEnd(whiteRook2.Location.X, whiteRook2.Location.Y);

            moveRook(whiteRook2, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhiteRook2, resetYWhiteRook2);
        }

        //the actions done when the mouse moves
        private void whiteRook2_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whiteRook2Location != Point.Empty)
            {
                Point newlocation = this.whiteRook2.Location;
                newlocation.X += e.X - whiteRook2Location.X;
                newlocation.Y += e.Y - whiteRook2Location.Y;
                this.whiteRook2.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whitePawn1Location = Point.Empty;
        int startwhitePawn1 = 0;
        int resetYWhitePawn1 = 0;
        int resetXWhitePawn1 = 0;
        private void whitePawn1_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whitePawn1.BackColor = Color.Gold;
                whitePawn1Location = new Point(e.X, e.Y);      //grabs the starting points

                resetXWhitePawn1 = whitePawn1.Location.X;
                resetYWhitePawn1 = whitePawn1.Location.Y;

                if (startwhitePawn1 == 0)
                {
                    startArrayX = 6;
                    startArrayY = 0;
                    startwhitePawn1++;
                }
                pixelToArrayStart(whitePawn1.Location.X, whitePawn1.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whitePawn1_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whitePawn1.BackColor = Color.Transparent;
            whitePawn1Location = Point.Empty;

            pixelToArrayEnd(whitePawn1.Location.X, whitePawn1.Location.Y);

            movePawn(whitePawn1, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhitePawn1, resetYWhitePawn1);
        }

        //the actions done when the mouse moves
        private void whitePawn1_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whitePawn1Location != Point.Empty)
            {
                Point newlocation = this.whitePawn1.Location;
                newlocation.X += e.X - whitePawn1Location.X;
                newlocation.Y += e.Y - whitePawn1Location.Y;
                this.whitePawn1.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whitePawn2Location = Point.Empty;
        int startwhitePawn2 = 0;
        int resetYWhitePawn2 = 0;
        int resetXWhitePawn2 = 0;
        private void whitePawn2_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whitePawn2.BackColor = Color.Gold;
                whitePawn2Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXWhitePawn2 = whitePawn2.Location.X;
                resetYWhitePawn2 = whitePawn2.Location.Y;

                if (startwhitePawn2 == 0)
                {
                    startArrayX = 6;
                    startArrayY = 1;
                    startwhitePawn2++;
                }
                pixelToArrayStart(whitePawn2.Location.X, whitePawn2.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whitePawn2_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whitePawn2.BackColor = Color.Transparent;
            whitePawn2Location = Point.Empty;
            pixelToArrayEnd(whitePawn2.Location.X, whitePawn2.Location.Y);

            movePawn(whitePawn2, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhitePawn2, resetYWhitePawn2);
        }

        //the actions done when the mouse moves
        private void whitePawn2_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whitePawn2Location != Point.Empty)
            {
                Point newlocation = this.whitePawn2.Location;
                newlocation.X += e.X - whitePawn2Location.X;
                newlocation.Y += e.Y - whitePawn2Location.Y;
                this.whitePawn2.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whitePawn3Location = Point.Empty;
        int startwhitePawn3 = 0;
        int resetYWhitePawn3 = 0;
        int resetXWhitePawn3 = 0;
        private void whitePawn3_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whitePawn3.BackColor = Color.Gold;
                whitePawn3Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXWhitePawn3 = whitePawn3.Location.X;
                resetYWhitePawn3 = whitePawn3.Location.Y;

                if (startwhitePawn3 == 0)
                {
                    startArrayX = 6;
                    startArrayY = 2;
                    startwhitePawn3++;
                }
                pixelToArrayStart(whitePawn3.Location.X, whitePawn3.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whitePawn3_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whitePawn3.BackColor = Color.Transparent;
            whitePawn3Location = Point.Empty;

            pixelToArrayEnd(whitePawn3.Location.X, whitePawn3.Location.Y);

            movePawn(whitePawn3, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhitePawn3, resetYWhitePawn3);
        }

        //the actions done when the mouse moves
        private void whitePawn3_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whitePawn3Location != Point.Empty)
            {
                Point newlocation = this.whitePawn3.Location;
                newlocation.X += e.X - whitePawn3Location.X;
                newlocation.Y += e.Y - whitePawn3Location.Y;
                this.whitePawn3.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whitePawn4Location = Point.Empty;
        int startwhitePawn4 = 0;
        int resetYWhitePawn4 = 0;
        int resetXWhitePawn4 = 0;
        private void whitePawn4_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whitePawn4.BackColor = Color.Gold;
                whitePawn4Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXWhitePawn4 = whitePawn4.Location.X;
                resetYWhitePawn4 = whitePawn4.Location.Y;

                if (startwhitePawn4 == 0)
                {
                    startArrayX = 6;
                    startArrayY = 3;
                    startwhitePawn4++;
                }
                pixelToArrayStart(whitePawn4.Location.X, whitePawn4.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whitePawn4_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whitePawn4.BackColor = Color.Transparent;
            whitePawn4Location = Point.Empty;

            pixelToArrayEnd(whitePawn4.Location.X, whitePawn4.Location.Y);

            movePawn(whitePawn4, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhitePawn4, resetYWhitePawn4);
        }

        //the actions done when the mouse moves
        private void whitePawn4_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whitePawn4Location != Point.Empty)
            {
                Point newlocation = this.whitePawn4.Location;
                newlocation.X += e.X - whitePawn4Location.X;
                newlocation.Y += e.Y - whitePawn4Location.Y;
                this.whitePawn4.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whitePawn5Location = Point.Empty;
        int startwhitePawn5 = 0;
        int resetYWhitePawn5 = 0;
        int resetXWhitePawn5 = 0;
        private void whitePawn5_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whitePawn5.BackColor = Color.Gold;
                whitePawn5Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXWhitePawn5 = whitePawn5.Location.X;
                resetYWhitePawn5 = whitePawn5.Location.Y;

                if (startwhitePawn5 == 0)
                {
                    startArrayX = 6;
                    startArrayY = 4;
                    startwhitePawn5++;
                }
                pixelToArrayStart(whitePawn5.Location.X, whitePawn5.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whitePawn5_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whitePawn5.BackColor = Color.Transparent;
            whitePawn5Location = Point.Empty;
            pixelToArrayEnd(whitePawn5.Location.X, whitePawn5.Location.Y);

            movePawn(whitePawn5, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhitePawn5, resetYWhitePawn5);
        }

        //the actions done when the mouse moves
        private void whitePawn5_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whitePawn5Location != Point.Empty)
            {
                Point newlocation = this.whitePawn5.Location;
                newlocation.X += e.X - whitePawn5Location.X;
                newlocation.Y += e.Y - whitePawn5Location.Y;
                this.whitePawn5.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whitePawn6Location = Point.Empty;
        int startwhitePawn6 = 0;
        int resetYWhitePawn6 = 0;
        int resetXWhitePawn6 = 0;
        private void whitePawn6_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whitePawn6.BackColor = Color.Gold;
                whitePawn6Location = new Point(e.X, e.Y);      //grabs the starting points
                resetXWhitePawn6 = whitePawn6.Location.X;
                resetYWhitePawn6 = whitePawn6.Location.Y;

                if (startwhitePawn6 == 0)
                {
                    startArrayX = 6;
                    startArrayY = 5;
                    startwhitePawn6++;
                }
                pixelToArrayStart(whitePawn6.Location.X, whitePawn6.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whitePawn6_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whitePawn6.BackColor = Color.Transparent;
            whitePawn6Location = Point.Empty;
            pixelToArrayEnd(whitePawn6.Location.X, whitePawn6.Location.Y);

            movePawn(whitePawn6, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhitePawn6, resetYWhitePawn6);
        }

        //the actions done when the mouse moves
        private void whitePawn6_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whitePawn6Location != Point.Empty)
            {
                Point newlocation = this.whitePawn6.Location;
                newlocation.X += e.X - whitePawn6Location.X;
                newlocation.Y += e.Y - whitePawn6Location.Y;
                this.whitePawn6.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whitePawn7Location = Point.Empty;
        int startwhitePawn7 = 0;
        int resetYWhitePawn7 = 0;
        int resetXWhitePawn7 = 0;
        private void whitePawn7_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whitePawn7.BackColor = Color.Gold;
                whitePawn7Location = new Point(e.X, e.Y);      //grabs the starting points

                resetXWhitePawn7 = whitePawn7.Location.X;
                resetYWhitePawn7 = whitePawn7.Location.Y;

                if (startwhitePawn7 == 0)
                {
                    startArrayX = 6;
                    startArrayY = 6;
                    startwhitePawn7++;
                }
                pixelToArrayStart(whitePawn7.Location.X, whitePawn7.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whitePawn7_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whitePawn7.BackColor = Color.Transparent;
            whitePawn7Location = Point.Empty;
            pixelToArrayEnd(whitePawn7.Location.X, whitePawn7.Location.Y);

            movePawn(whitePawn7, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhitePawn7, resetYWhitePawn7);
        }

        //the actions done when the mouse moves
        private void whitePawn7_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whitePawn7Location != Point.Empty)
            {
                Point newlocation = this.whitePawn7.Location;
                newlocation.X += e.X - whitePawn7Location.X;
                newlocation.Y += e.Y - whitePawn7Location.Y;
                this.whitePawn7.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //this will be for moving the map. Holding the mouse will allow you to drag it
        private Point whitePawn8Location = Point.Empty;
        int startwhitePawn8 = 0;
        int resetYWhitePawn8 = 0;
        int resetXWhitePawn8 = 0;
        private void whitePawn8_MouseDown(object sender, MouseEventArgs e) //starts when you click and hold the map
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Left) //this is when the image gets clicked on 
            {
                whitePawn8.BackColor = Color.Gold;
                whitePawn8Location = new Point(e.X, e.Y);      //grabs the starting points

                resetXWhitePawn8 = whitePawn8.Location.X;
                resetYWhitePawn8 = whitePawn8.Location.Y;

                if (startwhitePawn8 == 0)
                {
                    startArrayX = 6;
                    startArrayY = 7;
                    startwhitePawn8++;
                }
                pixelToArrayStart(whitePawn8.Location.X, whitePawn8.Location.Y);
            }
        }

        //when you relase the map, turn the drag bool to false
        private void whitePawn8_MouseUp(object sender, MouseEventArgs e)     //when you let go of the mouse button
        {
            whitePawn8.BackColor = Color.Transparent;

            pixelToArrayEnd(whitePawn8.Location.X, whitePawn8.Location.Y);

            movePawn(whitePawn8, startArrayX, startArrayY, endArrayX, endArrayY, resetXWhitePawn8, resetYWhitePawn8);

            whitePawn8Location = Point.Empty;
        }

        //the actions done when the mouse moves
        private void whitePawn8_MouseMove(object sender, MouseEventArgs e)     //when you move the mouse and hold the map
        {
            if (whitePawn8Location != Point.Empty)
            {
                Point newlocation = this.whitePawn8.Location;
                newlocation.X += e.X - whitePawn8Location.X;
                newlocation.Y += e.Y - whitePawn8Location.Y;

                this.whitePawn8.Location = newlocation;
                Cursor.Current = Cursors.Hand;
            }
        }

        //converts the pixels to ints for the array at the begining
        private void pixelToArrayStart(int X, int Y)
        {
            if (X >= 0 && X < 64) //Column 0
            {
                if (Y >= 0 && Y < 64) //row 1 
                {
                    startArrayX = 0;
                    startArrayY = 0;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    startArrayX = 1;
                    startArrayY = 0;
                }
                else if (Y >= 128 && Y < 192) //row 3 
                {
                    startArrayX = 2;
                    startArrayY = 0;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    startArrayX = 3;
                    startArrayY = 0;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    startArrayX = 4;
                    startArrayY = 0;
                }
                else if (Y >= 320 && Y < 384) //row 6
                {
                    startArrayX = 5;
                    startArrayY = 0;
                }
                else if (Y >= 384 && Y < 448) //row 7 
                {
                    startArrayX = 6;
                    startArrayY = 0;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    startArrayX = 7;
                    startArrayY = 0;
                }
            }
            else if (X >= 64 && X < 127) //Column 1
            {
                if (Y >= 0 && Y < 64) //row 1
                {
                    startArrayX = 0;
                    startArrayY = 1;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    startArrayX = 1;
                    startArrayY = 1;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    startArrayX = 2;
                    startArrayY = 1;
                }
                else if (Y >= 192 && Y < 256) //row 4 
                {
                    startArrayX = 3;
                    startArrayY = 1;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    startArrayX = 4;
                    startArrayY = 1;
                }
                else if (Y >= 320 && Y < 384) //row 6
                {
                    startArrayX = 5;
                    startArrayY = 1;
                }
                else if (Y >= 384 && Y < 448) //row 7 
                {
                    startArrayX = 6;
                    startArrayY = 1;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    startArrayX = 7;
                    startArrayY = 1;
                }
            }
            else if (X >= 128 && X < 192) //Column 2
            {
                if (Y >= 0 && Y < 64) //row 1
                {
                    startArrayX = 0;
                    startArrayY = 2;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    startArrayX = 1;
                    startArrayY = 2;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    startArrayX = 2;
                    startArrayY = 2;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    startArrayX = 3;
                    startArrayY = 2;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    startArrayX = 4;
                    startArrayY = 2;
                }
                else if (Y >= 320 && Y < 384) //row 6
                {
                    startArrayX = 5;
                    startArrayY = 2;
                }
                else if (Y >= 384 && Y < 448) //row 7 
                {
                    startArrayX = 6;
                    startArrayY = 2;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    startArrayX = 7;
                    startArrayY = 2;
                }
            }
            else if (X >= 192 && X < 256) //Column 3
            {
                if (Y >= 0 && Y < 64) //row 1
                {
                    startArrayX = 0;
                    startArrayY = 3;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    startArrayX = 1;
                    startArrayY = 3;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    startArrayX = 2;
                    startArrayY = 3;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    startArrayX = 3;
                    startArrayY = 3;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    startArrayX = 4;
                    startArrayY = 3;
                }
                else if (Y >= 320 && Y < 384) //row 6
                {
                    startArrayX = 5;
                    startArrayY = 3;
                }
                else if (Y >= 384 && Y < 448) //row 7
                {
                    startArrayX = 6;
                    startArrayY = 3;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    startArrayX = 7;
                    startArrayY = 3;
                }
            }
            else if (X >= 256 && X < 320) //Column 4
            {
                if (Y >= 0 && Y < 64) //row 1
                {
                    startArrayX = 0;
                    startArrayY = 4;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    startArrayX = 1;
                    startArrayY = 4;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    startArrayX = 2;
                    startArrayY = 4;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    startArrayX = 3;
                    startArrayY = 4;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    startArrayX = 4;
                    startArrayY = 4;
                }
                else if (Y >= 320 && Y < 384) //row 6
                {
                    startArrayX = 5;
                    startArrayY = 4;
                }
                else if (Y >= 384 && Y < 448) //row 7
                {
                    startArrayX = 6;
                    startArrayY = 4;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    startArrayX = 7;
                    startArrayY = 4;
                }
            }
            else if (X >= 320 && X < 384) //Column 5
            {
                if (Y >= 0 && Y < 64) //row 1
                {
                    startArrayX = 0;
                    startArrayY = 5;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    startArrayX = 1;
                    startArrayY = 5;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    startArrayX = 2;
                    startArrayY = 5;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    startArrayX = 3;
                    startArrayY = 5;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    startArrayX = 4;
                    startArrayY = 5;
                }
                else if (Y >= 320 && Y < 384) //row 6 
                {
                    startArrayX = 5;
                    startArrayY = 5;
                }
                else if (Y >= 384 && Y < 448) //row 7 
                {
                    startArrayX = 6;
                    startArrayY = 5;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    startArrayX = 7;
                    startArrayY = 5;
                }
            }
            else if (X >= 384 && X < 448) //Column 6
            {
                if (Y >= 0 && Y < 64) //row 1
                {
                    startArrayX = 0;
                    startArrayY = 6;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    startArrayX = 1;
                    startArrayY = 6;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    startArrayX = 2;
                    startArrayY = 6;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    startArrayX = 3;
                    startArrayY = 6;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    startArrayX = 4;
                    startArrayY = 6;
                }
                else if (Y >= 320 && Y < 384) //row 6 
                {
                    startArrayX = 5;
                    startArrayY = 6;
                }
                else if (Y >= 384 && Y < 448) //row 7 
                {
                    startArrayX = 6;
                    startArrayY = 6;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    startArrayX = 7;
                    startArrayY = 6;
                }
            }
            else if (X >= 448 && X < 512) //Column 7
            {
                if (Y >= 0 && Y < 64) //row 1
                {
                    startArrayX = 0;
                    startArrayY = 7;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    startArrayX = 1;
                    startArrayY = 7;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    startArrayX = 2;
                    startArrayY = 7;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    startArrayX = 3;
                    startArrayY = 7;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    startArrayX = 4;
                    startArrayY = 7;
                }
                else if (Y >= 320 && Y < 384) //row 6
                {
                    startArrayX = 5;
                    startArrayY = 7;
                }
                else if (Y >= 384 && Y < 448) //row 7
                {
                    startArrayX = 6;
                    startArrayY = 7;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    startArrayX = 7;
                    startArrayY = 7;
                }
            }
        }

        //converts the pixels to ints for the array at the end
        private void pixelToArrayEnd(int X, int Y)
        {
            if (X > 0 && X < 64) //Column 0
            {
                if (Y >= 0 && Y < 64) //row 1
                {
                    endArrayX = 0;
                    endArrayY = 0;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    endArrayX = 1;
                    endArrayY = 0;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    endArrayX = 2;
                    endArrayY = 0;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    endArrayX = 3;
                    endArrayY = 0;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    endArrayX = 4;
                    endArrayY = 0;
                }
                else if (Y >= 320 && Y < 384) //row 6
                {
                    endArrayX = 5;
                    endArrayY = 0;
                }
                else if (Y >= 384 && Y < 448) //row 7
                {
                    endArrayX = 6;
                    endArrayY = 0;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    endArrayX = 7;
                    endArrayY = 0;
                }
            }
            else if (X >= 64 && X < 127) //Column 1
            {
                if (Y >= 0 && Y < 64) //row 1
                {
                    endArrayX = 0;
                    endArrayY = 1;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    endArrayX = 1;
                    endArrayY = 1;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    endArrayX = 2;
                    endArrayY = 1;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    endArrayX = 3;
                    endArrayY = 1;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    endArrayX = 4;
                    endArrayY = 1;
                }
                else if (Y >= 320 && Y < 384) //row 6
                {
                    endArrayX = 5;
                    endArrayY = 1;
                }
                else if (Y >= 384 && Y < 448) //row 7
                {
                    endArrayX = 6;
                    endArrayY = 1;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    endArrayX = 7;
                    endArrayY = 1;
                }
            }
            else if (X >= 128 && X < 192) //Column 2
            {
                if (Y >= 0 && Y < 64) //row 1
                {
                    endArrayX = 0;
                    endArrayY = 2;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    endArrayX = 1;
                    endArrayY = 2;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    endArrayX = 2;
                    endArrayY = 2;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    endArrayX = 3;
                    endArrayY = 2;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    endArrayX = 4;
                    endArrayY = 2;
                }
                else if (Y >= 320 && Y < 384) //row 6
                {
                    endArrayX = 5;
                    endArrayY = 2;
                }
                else if (Y >= 384 && Y < 448) //row 7 
                {
                    endArrayX = 6;
                    endArrayY = 2;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    endArrayX = 7;
                    endArrayY = 2;
                }
            }
            else if (X >= 192 && X < 256) //Column 3
            {
                if (Y >= 0 && Y < 64) //row 1
                {
                    endArrayX = 0;
                    endArrayY = 3;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    endArrayX = 1;
                    endArrayY = 3;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    endArrayX = 2;
                    endArrayY = 3;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    endArrayX = 3;
                    endArrayY = 3;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    endArrayX = 4;
                    endArrayY = 3;
                }
                else if (Y >= 320 && Y < 384) //row 6
                {
                    endArrayX = 5;
                    endArrayY = 3;
                }
                else if (Y >= 384 && Y < 448) //row 7
                {
                    endArrayX = 6;
                    endArrayY = 3;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    endArrayX = 7;
                    endArrayY = 3;
                }
            }
            else if (X >= 256 && X < 320) //Column 4
            {
                if (Y >= 0 && Y < 64) //row 1
                {
                    endArrayX = 0;
                    endArrayY = 4;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    endArrayX = 1;
                    endArrayY = 4;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    endArrayX = 2;
                    endArrayY = 4;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    endArrayX = 3;
                    endArrayY = 4;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    endArrayX = 4;
                    endArrayY = 4;
                }
                else if (Y >= 320 && Y < 384) //row 6
                {
                    endArrayX = 5;
                    endArrayY = 4;
                }
                else if (Y >= 384 && Y < 448) //row 7 
                {
                    endArrayX = 6;
                    endArrayY = 4;
                }
                else if (Y >= 448 && Y < 512) //row 8 
                {
                    endArrayX = 7;
                    endArrayY = 4;
                }
            }
            else if (X >= 320 && X < 384) //Column 5
            {
                if (Y >= 0 && Y <= 64) //row 1
                {
                    endArrayX = 0;
                    endArrayY = 5;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    endArrayX = 1;
                    endArrayY = 5;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    endArrayX = 2;
                    endArrayY = 5;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    endArrayX = 3;
                    endArrayY = 5;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    endArrayX = 4;
                    endArrayY = 5;
                }
                else if (Y >= 320 && Y < 384) //row 6 
                {
                    endArrayX = 5;
                    endArrayY = 5;
                }
                else if (Y >= 384 && Y < 448) //row 7
                {
                    endArrayX = 6;
                    endArrayY = 5;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    endArrayX = 7;
                    endArrayY = 5;
                }
            }
            else if (X >= 384 && X < 448) //Column 6
            {
                if (Y >= 0 && Y < 64) //row 1
                {
                    endArrayX = 0;
                    endArrayY = 6;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    endArrayX = 1;
                    endArrayY = 6;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    endArrayX = 2;
                    endArrayY = 6;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    endArrayX = 3;
                    endArrayY = 6;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    endArrayX = 4;
                    endArrayY = 6;
                }
                else if (Y >= 320 && Y < 384) //row 6
                {
                    endArrayX = 5;
                    endArrayY = 6;
                }
                else if (Y >= 384 && Y < 448) //row 7
                {
                    endArrayX = 6;
                    endArrayY = 6;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    endArrayX = 7;
                    endArrayY = 6;
                }
            }
            else if (X >= 448 && X < 512) //Column 7
            {
                if (Y >= 0 && Y < 64) //row 1
                {
                    endArrayX = 0;
                    endArrayY = 7;
                }
                else if (Y >= 64 && Y < 128) //row 2
                {
                    endArrayX = 1;
                    endArrayY = 7;
                }
                else if (Y >= 128 && Y < 192) //row 3
                {
                    endArrayX = 2;
                    endArrayY = 7;
                }
                else if (Y >= 192 && Y < 256) //row 4
                {
                    endArrayX = 3;
                    endArrayY = 7;
                }
                else if (Y >= 256 && Y < 320) //row 5
                {
                    endArrayX = 4;
                    endArrayY = 7;
                }
                else if (Y >= 320 && Y < 384) //row 6
                {
                    endArrayX = 5;
                    endArrayY = 7;
                }
                else if (Y >= 384 && Y < 448) //row 7
                {
                    endArrayX = 6;
                    endArrayY = 7;
                }
                else if (Y >= 448 && Y < 512) //row 8
                {
                    endArrayX = 7;
                    endArrayY = 7;
                }
            }
        }

        //converts the array to pixels
        private void arrayToPixel(int cols, int rows)
        {
            if (cols == 0) //Column 0
            {
                pixelArrayY = 13;

                if (rows == 0)
                {
                    pixelArrayX = 14;
                }
                else if (rows == 1)
                {
                    pixelArrayX = 74;
                }
                else if (rows == 2)
                {
                    pixelArrayX = 136;
                }
                else if (rows == 3)
                {
                    pixelArrayX = 200;
                }
                else if (rows == 4)
                {
                    pixelArrayX = 266;
                }
                else if (rows == 5)
                {
                    pixelArrayX = 330;
                }
                else if (rows == 6)
                {
                    pixelArrayX = 392;
                }
                else if (rows == 7)
                {
                    pixelArrayX = 453;
                }
            }
            else if (cols == 1) //Column 1
            {
                pixelArrayY = 70;

                if (rows == 0)
                {
                    pixelArrayX = 14;
                }
                else if (rows == 1)
                {
                    pixelArrayX = 74;
                }
                else if (rows == 2)
                {
                    pixelArrayX = 136;
                }
                else if (rows == 3)
                {
                    pixelArrayX = 200;
                }
                else if (rows == 4)
                {
                    pixelArrayX = 266;
                }
                else if (rows == 5)
                {
                    pixelArrayX = 330;
                }
                else if (rows == 6)
                {
                    pixelArrayX = 392;
                }
                else if (rows == 7)
                {
                    pixelArrayX = 453;
                }
            }
            else if (cols == 2) //Column 2
            {
                pixelArrayY = 133;

                if (rows == 0)
                {
                    pixelArrayX = 14;
                }
                else if (rows == 1)
                {
                    pixelArrayX = 74;
                }
                else if (rows == 2)
                {
                    pixelArrayX = 136;
                }
                else if (rows == 3)
                {
                    pixelArrayX = 200;
                }
                else if (rows == 4)
                {
                    pixelArrayX = 266;
                }
                else if (rows == 5)
                {
                    pixelArrayX = 330;
                }
                else if (rows == 6)
                {
                    pixelArrayX = 392;
                }
                else if (rows == 7)
                {
                    pixelArrayX = 453;
                }
            }
            else if (cols == 3) //Column 3
            {
                pixelArrayY = 199;

                if (rows == 0)
                {
                    pixelArrayX = 14;
                }
                else if (rows == 1)
                {
                    pixelArrayX = 74;
                }
                else if (rows == 2)
                {
                    pixelArrayX = 136;
                }
                else if (rows == 3)
                {
                    pixelArrayX = 200;
                }
                else if (rows == 4)
                {
                    pixelArrayX = 266;
                }
                else if (rows == 5)
                {
                    pixelArrayX = 330;
                }
                else if (rows == 6)
                {
                    pixelArrayX = 392;
                }
                else if (rows == 7)
                {
                    pixelArrayX = 453;
                }
            }
            else if (cols == 4) //Column 4
            {
                pixelArrayY = 263;

                if (rows == 0)
                {
                    pixelArrayX = 14;
                }
                else if (rows == 1)
                {
                    pixelArrayX = 74;
                }
                else if (rows == 2)
                {
                    pixelArrayX = 136;
                }
                else if (rows == 3)
                {
                    pixelArrayX = 200;
                }
                else if (rows == 4)
                {
                    pixelArrayX = 266;
                }
                else if (rows == 5)
                {
                    pixelArrayX = 330;
                }
                else if (rows == 6)
                {
                    pixelArrayX = 392;
                }
                else if (rows == 7)
                {
                    pixelArrayX = 453;
                }
            }
            else if (cols == 5) //Column 5
            {
                pixelArrayY = 326;

                if (rows == 0)
                {
                    pixelArrayX = 14;
                }
                else if (rows == 1)
                {
                    pixelArrayX = 74;
                }
                else if (rows == 2)
                {
                    pixelArrayX = 136;
                }
                else if (rows == 3)
                {
                    pixelArrayX = 200;
                }
                else if (rows == 4)
                {
                    pixelArrayX = 266;
                }
                else if (rows == 5)
                {
                    pixelArrayX = 330;
                }
                else if (rows == 6)
                {
                    pixelArrayX = 392;
                }
                else if (rows == 7)
                {
                    pixelArrayX = 453;
                }
            }
            else if (cols == 6) //Column 6
            {
                pixelArrayY = 393;

                if (rows == 0)
                {
                    pixelArrayX = 14;
                }
                else if (rows == 1)
                {
                    pixelArrayX = 74;
                }
                else if (rows == 2)
                {
                    pixelArrayX = 136;
                }
                else if (rows == 3)
                {
                    pixelArrayX = 200;
                }
                else if (rows == 4)
                {
                    pixelArrayX = 266;
                }
                else if (rows == 5)
                {
                    pixelArrayX = 330;
                }
                else if (rows == 6)
                {
                    pixelArrayX = 392;
                }
                else if (rows == 7)
                {
                    pixelArrayX = 453;
                }
            }
            else if (cols == 7) //Column 7
            {
                pixelArrayY = 453;

                if (rows == 0)
                {
                    pixelArrayX = 14;
                }
                else if (rows == 1)
                {
                    pixelArrayX = 74;
                }
                else if (rows == 2)
                {
                    pixelArrayX = 136;
                }
                else if (rows == 3)
                {
                    pixelArrayX = 200;
                }
                else if (rows == 4)
                {
                    pixelArrayX = 266;
                }
                else if (rows == 5)
                {
                    pixelArrayX = 330;
                }
                else if (rows == 6)
                {
                    pixelArrayX = 392;
                }
                else if (rows == 7)
                {
                    pixelArrayX = 453;
                }
            }
        }

        int prisonCount1 = 0;       //counters for starting new rows
        int prisonCount2 = 0;
        //when a white piece captures a black piece
        private void moveToWhitePrison(string prisonerName) //disposing of pieces that are captured 
        {
            PictureBox prisonerPiece = null;
            foreach (object p in chessBoard.Controls)
            {
                if (p.GetType() == typeof(PictureBox))
                {
                    if (((PictureBox)p).Name == prisonerName) //matches name of piece with list
                    {
                        prisonerPiece = (PictureBox)p;
                    }
                }
            }

            if (prisonerPiece != null)
            {
                prisonerPiece.Parent = whiteGraveYard; //disposed in graveyard
                prisonerPiece.Location = new Point(whitePrisonPlaceX, whitePrisonPlaceY);       //add piece to graveyard
                whitePrisonPlaceX += 64;
                prisonCount1++;

                if (prisonCount1 % 3 == 0)      //if there were 3 pieces captured, start a new row
                {
                    whitePrisonPlaceY += 64;
                    whitePrisonPlaceX = 0;
                }
            }
        }

        //when a black piece captures a white piece
        private void moveToBlackPrison(string prisonerName) //disposing of pieces that are captured 
        {
            PictureBox prisonerPiece = null;
            foreach (object p in chessBoard.Controls)
            {
                if (p.GetType() == typeof(PictureBox))
                {
                    if (((PictureBox)p).Name == prisonerName) //matches name of piece with list
                    {
                        prisonerPiece = (PictureBox)p;
                    }
                }
            }

            if (prisonerPiece != null)
            {
                prisonerPiece.Parent = blackGraveYard; //disposed in graveyard
                prisonerPiece.Location = new Point(blackPrisonPlaceX, blackPrisonPlaceY);   //add piece to graveyard
                blackPrisonPlaceX += 64;
                prisonCount2++;

                if (prisonCount2 % 3 == 0)              //if there were 3 pieces captured, start a new row
                {
                    blackPrisonPlaceY += 64;
                    blackPrisonPlaceX = 0;
                }
            }
        }

        //how the pawn can move
        string movedTo;
        private void movePawn(PictureBox piece, int startX, int startY, int endX, int endY, int resetX, int resetY)     //parameters will be where we first clicked to get the piece, and where we want to move
        {
            movedTo = array[endX, endY];                //gets what piece is on the square trying to move to
            if (whiteFirst == true)                     //if it is whites turn
            {
                if (array[startX, startY] == "whitePawn8" || array[startX, startY] == "whitePawn7" || array[startX, startY] == "whitePawn6" || array[startX, startY] == "whitePawn5"
                    || array[startX, startY] == "whitePawn4" || array[startX, startY] == "whitePawn3" || array[startX, startY] == "whitePawn2" || array[startX, startY] == "whitePawn1")            //if we are moving a white pawn
                {
                    if (startY == endY && endX == startX - 2)     //if the pawn moves up 2 square
                    {
                        if (startX == 6)                          //if the white pawns are at the starting position
                        {
                            if (array[endX, endY] == null)        //if the moved spot is empty
                            {
                                array[endX, endY] = array[startX, startY]; //move piece in array to end point 
                                array[startX, startY] = null; //then the starting point is now null 
                                whiteFirst = false; //now black will go 
                                turncounter++; //turn incremented
                                whiteTurn.Visible = false; //white not going 
                                blackTurn.Visible = true; //black is going 
                                winner(); //checking for winner 

                            }
                            else        //if the pawn is trying to move into a space taken right in front of it
                            {
                                piece.Location = new Point(resetX, resetY); //reset piece 
                                feedback_TextBox.Clear();
                                feedback_TextBox.AppendText("You can not move there. Pawns only move 1 square forward (or 2 squares forward for the first round) and attack diagonally");
                            }
                        }                        
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("You can not move there. Pawns can only move 2 squares on their first move ");
                        }
                    }
                    else if (startY == endY && endX == startX - 1)     //if the pawn moves up 1 square
                    {
                        if (array[endX, endY] == null)              //if the moved spot is empty
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteFirst = false;
                            turncounter++;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();

                            if (endX == 0)
                            {
                                promotion(piece, endX, endY);
                            }
                        }
                        else        //if the pawn is trying to move into a space taken right in front of it
                        {
                            piece.Location = new Point(resetX, resetY);

                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("You can not move there. Pawns only move 1 square forward (or 2 squares forward for the first round) and attack diagonally");
                        }
                    }
                    //if attacking diagonally
                    else if ((endX == startX - 1 && endY == startY - 1) || (endX == startX - 1 && endY == startY + 1))
                    {
                        if (movedTo[0] == 'b' && array[endX, endY] != null)           //if the white pawn meets a black piece diagonally
                        {
                            moveToWhitePrison(movedTo);                         //send captured piece to prison
                            array[endX, endY] = array[startX, startY];          //array at end points = the starting piece
                            array[startX, startY] = null;
                            whiteFirst = false;
                            turncounter++;                                      //increase turn counter
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;                           //switch turn labels
                            blackLoss++;
                            winner();                                           //check to see if theres a winner

                            if (endX == 0)                                      //if white pawn reaches the end
                            {
                                promotion(piece, endX, endY);                          //set it to a queen
                            }
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);

                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("You can not move there. There's a piece in the way");
                        }
                    }
                    else
                    {
                        piece.Location = new Point(resetX, resetY);
                        feedback_TextBox.Clear();
                        feedback_TextBox.AppendText("You can not move there. Pawns only move 1 square forward (or 2 squares forawrd for the first round) and attack diagonally");
                    }
                }
                else
                {
                    piece.Location = new Point(resetX, resetY);
                    feedback_TextBox.Clear();
                    feedback_TextBox.AppendText("That is not your piece");
                }
            }
            else if (whiteFirst == false)               //if its blacks turn
            {
                if (array[startX, startY] == "blackPawn8" || array[startX, startY] == "blackPawn7" || array[startX, startY] == "blackPawn6" || array[startX, startY] == "blackPawn5"
                    || array[startX, startY] == "blackPawn4" || array[startX, startY] == "blackPawn3" || array[startX, startY] == "blackPawn2" || array[startX, startY] == "blackPawn1")       //if we are moving a black pawn
                {
                    if (startY == endY && endX == startX + 2)     //if the pawn moves up 2 square
                    {
                        if (startX == 1)
                        {
                            if (array[endX, endY] == null)              //if the moved spot is empty
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = true;
                                turncounter++;
                                whiteTurn.Visible = true;
                                blackTurn.Visible = false;
                                winner();
                            }
                            else        //if the pawn is trying to move into a space taken right in front of it
                            {
                                piece.Location = new Point(resetX, resetY);
                                feedback_TextBox.Clear();
                                feedback_TextBox.AppendText("You can not move there. Pawns only move 1 square forward (or 2 squares foward for the first round) and attack diagonally");
                            }
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("Pawns can only move 2 squares on the first move.");
                        }
                    }
                    else if (startY == endY && endX == startX + 1)     //if the pawn moves up 1 square
                    {
                        if (array[endX, endY] == null)              //if the moved spot is empty
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteFirst = true;
                            turncounter++;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                            if (endX == 7)                                      //if black pawn reaches the end
                            {
                                promotion(piece, endX, endY);                          //set it to a queen
                            }
                        }
                        else        //if the pawn is trying to move into a space taken right in front of it
                        {
                            feedback_TextBox.Clear();
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.AppendText("You can not move there. Pawns only move 1 square forward and attack diagonally");
                        }
                    }
                    else if ((endX == startX + 1 && endY == startY - 1) || (endX == startX + 1 && endY == startY + 1))
                    {
                        if (movedTo[0] == 'w' && array[endX, endY] != null)           //if the white pawn meets a black piece diagonally
                        {
                            moveToBlackPrison(movedTo);
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteLoss++;
                            turncounter++;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            whiteFirst = true;             //change the turn to be white players
                            winner();
                            if (endX == 7)                                      //if black pawn reaches the end
                            {
                                promotion(piece, endX, endY);                          //set it to a queen
                            }
                        }
                        else
                        {
                            feedback_TextBox.Clear();
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.AppendText("You can not move there. There's a piece in the way.");
                        }
                    }
                    else
                    {
                        feedback_TextBox.Clear();
                        piece.Location = new Point(resetX, resetY);
                        feedback_TextBox.AppendText("You can not move there. Pawns only move 1 square forward and attack diagonally");
                    }
                }
                else
                {
                    feedback_TextBox.Clear();
                    piece.Location = new Point(resetX, resetY);
                    feedback_TextBox.AppendText("That is not your piece");
                }
            }
        }

        //move the rooks
        bool canMoveRook = false;
        private void moveRook(PictureBox piece, int startX, int startY, int endX, int endY, int resetX, int resetY)
        {
            int differenceX = 0;
            int differenceY = 0;
            int stopEarly = 0;
            int whiteCapture = 0;
            int blackCapture = 0;
            if (whiteFirst == true)      //if it is whites turn
            {
                if (array[startX, startY] == "whiteRook1" || array[startX, startY] == "whiteRook2")            //if we are moving a white rook
                {
                    if (((startY == endY) && (startX != endX)) || ((startX == endX) && (startY != endY)))    //if we try to move left and right
                    {
                        differenceX = Math.Abs(endX - startX);           //we want the difference of the 2 points
                        differenceY = Math.Abs(endY - startY);

                        if (differenceX == 0) //if the x's are the same 
                        {
                            if (startY < endY) //and the start point is less than the end point 
                            {
                                for (int i = startY; i <= endY; i++) //loops through until the start matching the end 
                                {
                                    if (array[startX, i] == null || array[startX, i] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveRook = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[startX, i]; //stores the piece in the way 
                                        if (movedTo[0] == 'b')             //if we hit an enemy piece
                                        {
                                            whiteCapture = i; //piece is captured
                                            canMoveRook = true; //rook can move 
                                            stopEarly++; //and rook stops moving early 
                                            break;
                                        }
                                        else
                                        {
                                            canMoveRook = false; //rook can't other 
                                            piece.Location = new Point(resetX, resetY); //rook gets set back to original locaiton 
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveRook == true) //if rook can move 
                                {
                                    if (stopEarly > 0) //checks if rook was stopped early 
                                    {
                                        moveToWhitePrison(movedTo); //moves piece in way to graveyard 
                                        array[startX, whiteCapture] = array[startX, startY]; //rook goes from starting point to capture point 
                                        arrayToPixel(startX, whiteCapture); //convert array position to pixels
                                        piece.Location = new Point(pixelArrayX, pixelArrayY); //sets image there 
                                        array[startX, startY] = null; //starting point is empty
                                        whiteFirst = false; //black can go 
                                        stopEarly = 0; //stopping is reset 
                                        blackLoss++; //black loses a piece 
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY]; //if no pieces in way, piece moves from start to end 
                                        array[startX, startY] = null; //start is null 
                                        whiteFirst = false; //black can go 
                                    }
                                    turncounter++; //turn counter increments 
                                    whiteTurn.Visible = false; //white can't go 
                                    blackTurn.Visible = true; //black can go  
                                    winner(); //checks for winner 
                                }
                            }
                            else
                            {
                                for (int i = startY; i >= endY; i--)
                                {
                                    if (array[startX, i] == null || array[startX, i] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveRook = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[startX, i];
                                        if (movedTo[0] == 'b')             //if we hit an enemy piece
                                        {
                                            whiteCapture = i;
                                            canMoveRook = true;
                                            stopEarly++;
                                            break;
                                        }
                                        else
                                        {
                                            canMoveRook = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveRook == true)
                                {
                                    if (stopEarly > 0)
                                    {
                                        moveToWhitePrison(movedTo);
                                        array[startX, whiteCapture] = array[startX, startY];
                                        arrayToPixel(startX, whiteCapture);
                                        piece.Location = new Point(pixelArrayX, pixelArrayY);
                                        array[startX, startY] = null;
                                        whiteFirst = false;
                                        stopEarly = 0;
                                        blackLoss++;
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = false;
                                    }
                                    turncounter++;
                                    whiteTurn.Visible = false;
                                    blackTurn.Visible = true;
                                    winner();
                                }
                            }
                        }
                        else if (differenceY == 0)
                        {
                            if (startX < endX)
                            {
                                for (int i = startX; i <= endX; i++)
                                {
                                    if (array[i, startY] == null || array[i, startY] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveRook = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[i, startY];
                                        if (movedTo[0] == 'b')             //if we hit an enemy piece
                                        {
                                            whiteCapture = i;
                                            canMoveRook = true;
                                            stopEarly++;

                                            break;
                                        }
                                        else
                                        {
                                            canMoveRook = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveRook == true)
                                {
                                    if (stopEarly > 0)
                                    {
                                        moveToWhitePrison(movedTo);
                                        array[whiteCapture, startY] = array[startX, startY];
                                        arrayToPixel(whiteCapture, startY);
                                        piece.Location = new Point(pixelArrayX, pixelArrayY);
                                        array[startX, startY] = null;
                                        whiteFirst = false;
                                        stopEarly = 0;
                                        blackLoss++;
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = false;
                                    }
                                    turncounter++;
                                    whiteTurn.Visible = false;
                                    blackTurn.Visible = true;
                                    winner();
                                }
                            }
                            else
                            {
                                for (int i = startX; i >= endX; i--)
                                {
                                    if (array[i, startY] == null || array[i, startY] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveRook = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[i, startY];
                                        if (movedTo[0] == 'b')             //if we hit an enemy piece
                                        {
                                            whiteCapture = i;
                                            canMoveRook = true;
                                            stopEarly++;

                                            break;
                                        }
                                        else
                                        {
                                            canMoveRook = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveRook == true)
                                {
                                    if (stopEarly > 0)
                                    {
                                        moveToWhitePrison(movedTo);
                                        array[whiteCapture, startY] = array[startX, startY];
                                        arrayToPixel(whiteCapture, startY);
                                        piece.Location = new Point(pixelArrayX, pixelArrayY);
                                        array[startX, startY] = null;
                                        whiteFirst = false;
                                        stopEarly = 0;
                                        blackLoss++;
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = false;
                                    }
                                    turncounter++;
                                    whiteTurn.Visible = false;
                                    blackTurn.Visible = true;
                                    winner();
                                }
                            }
                        }
                    }
                    else
                    {
                        piece.Location = new Point(resetX, resetY);
                        feedback_TextBox.Clear();
                        feedback_TextBox.AppendText("Rooks can only move up and down OR left and right");
                    }
                }
                else
                {
                    piece.Location = new Point(resetX, resetY);
                    feedback_TextBox.Clear();
                    feedback_TextBox.AppendText("That is not your piece");
                }
            }
            else if (whiteFirst == false)    //if blacks turn
            {
                if (array[startX, startY] == "blackRook1" || array[startX, startY] == "blackRook2")            //if we are moving a white rook
                {
                    if (((startY == endY) && (startX != endX)) || ((startX == endX) && (startY != endY)))    //if we try to move left and right
                    {
                        differenceX = Math.Abs(endX - startX);           //we want the difference of the 2 points
                        differenceY = Math.Abs(endY - startY);

                        if (differenceX == 0)
                        {
                            if (startY < endY)
                            {
                                for (int i = startY; i <= endY; i++)
                                {
                                    if (array[startX, i] == null || array[startX, i] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveRook = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[startX, i];
                                        if (movedTo[0] == 'w')             //if we hit an enemy piece
                                        {
                                            blackCapture = i;
                                            canMoveRook = true;
                                            stopEarly++;
                                            break;
                                        }
                                        else
                                        {
                                            canMoveRook = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveRook == true)
                                {
                                    if (stopEarly > 0)
                                    {
                                        moveToBlackPrison(movedTo);
                                        array[startX, blackCapture] = array[startX, startY];
                                        arrayToPixel(startX, blackCapture);
                                        piece.Location = new Point(pixelArrayX, pixelArrayY);
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                        stopEarly = 0;
                                        whiteLoss++;
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                    }
                                    turncounter++;
                                    whiteTurn.Visible = true;
                                    blackTurn.Visible = false;
                                    winner();
                                }
                            }
                            else
                            {
                                for (int i = startY; i >= endY; i--)
                                {
                                    if (array[startX, i] == null || array[startX, i] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveRook = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[startX, i];
                                        if (movedTo[0] == 'w')             //if we hit an enemy piece
                                        {
                                            blackCapture = i;
                                            canMoveRook = true;
                                            stopEarly++;
                                            break;
                                        }
                                        else
                                        {
                                            canMoveRook = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveRook == true)
                                {
                                    if (stopEarly > 0)
                                    {
                                        moveToBlackPrison(movedTo);
                                        array[startX, blackCapture] = array[startX, startY];
                                        arrayToPixel(startX, blackCapture);
                                        piece.Location = new Point(pixelArrayX, pixelArrayY);
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                        stopEarly = 0;
                                        whiteLoss++;
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                    }

                                    turncounter++;
                                    whiteTurn.Visible = true;
                                    blackTurn.Visible = false;
                                    winner();
                                }
                            }
                        }
                        else if (differenceY == 0)
                        {
                            if (startX < endX)
                            {
                                for (int i = startX; i <= endX; i++)
                                {
                                    if (array[i, startY] == null || array[i, startY] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveRook = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[i, startY];
                                        if (movedTo[0] == 'w')             //if we hit an enemy piece
                                        {
                                            blackCapture = i;
                                            canMoveRook = true;
                                            stopEarly++;

                                            break;
                                        }
                                        else
                                        {
                                            canMoveRook = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveRook == true)
                                {
                                    if (stopEarly > 0)
                                    {
                                        moveToBlackPrison(array[blackCapture, startY]);
                                        whiteLoss++;
                                        movedTo = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                        stopEarly = 0;
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                    }

                                    turncounter++;
                                    whiteTurn.Visible = true;
                                    blackTurn.Visible = false;
                                    winner();
                                }
                            }
                            else
                            {
                                for (int i = startX; i >= endX; i--)
                                {
                                    if (array[i, startY] == null || array[i, startY] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveRook = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[i, startY];
                                        if (movedTo[0] == 'w')             //if we hit an enemy piece
                                        {
                                            blackCapture = i;
                                            canMoveRook = true;
                                            stopEarly++;

                                            break;
                                        }
                                        else
                                        {
                                            canMoveRook = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveRook == true)
                                {
                                    if (stopEarly > 0)
                                    {
                                        moveToBlackPrison(movedTo);
                                        array[blackCapture, startY] = array[startX, startY];
                                        arrayToPixel(blackCapture, startY);
                                        piece.Location = new Point(pixelArrayX, pixelArrayY);
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                        stopEarly = 0;
                                        whiteLoss++;
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                    }
                                    turncounter++;
                                    whiteTurn.Visible = true;
                                    blackTurn.Visible = false;
                                    winner();
                                }
                            }
                        }
                    }
                    else
                    {
                        piece.Location = new Point(resetX, resetY);
                        feedback_TextBox.Clear();
                        feedback_TextBox.AppendText("Rooks can only move up and down OR left and right");
                    }
                }
                else
                {
                    piece.Location = new Point(resetX, resetY);
                    feedback_TextBox.Clear();
                    feedback_TextBox.AppendText("That is not your piece");
                }
            }
            else
            {
                piece.Location = new Point(resetX, resetY);
                feedback_TextBox.AppendText("That is not your piece");

            }
        }

        //move the bishops
        bool canMoveBishop = false;
        private void moveBishop(PictureBox piece, int startX, int startY, int endX, int endY, int resetX, int resetY)
        {
            int differenceX = 0;
            int differenceY = 0;
            int stopEarly = 0;
            int whiteCapture = 0;
            int blackCapture = 0;

            if (whiteFirst == true)                     //if whites turn
            {
                if (array[startX, startY] == "whiteBishop1" || array[startX, startY] == "whiteBishop2")      //if the selected piece was a white king
                {
                    if (((startY != endY) && (startX != endX)) && ((startX > endX) && (startY < endY)))           //moves diagonally top right
                    {
                        differenceX = Math.Abs(endX - startX); //finds the difference between the two poitns 
                        differenceY = Math.Abs(endY - startY);
                        int x = startX; //starting x position 
                        int y = startY; //starting y position 
                        for (int i = startX; i >= endX; i--) //goes through until start is the same as end 
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveBishop = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y]; //stores piece in the way 
                                if (movedTo[0] == 'b')             //if we hit an enemy piece
                                {
                                    whiteCapture = i; //captures piece
                                    canMoveBishop = true; //bishop can move now 
                                    stopEarly++; //bishop was stopped early if tried jumping over pieces 
                                    break;
                                }
                                else
                                {
                                    canMoveBishop = false; //bishop can't move 
                                    piece.Location = new Point(resetX, resetY); //bishop gets reset to the original spot 
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y++;
                        }

                        if (canMoveBishop == true) //if bishop can move 
                        {
                            if (stopEarly > 0) //checks if bishop was stopped early 
                            {
                                moveToWhitePrison(movedTo); //move piece to prison 
                                array[whiteCapture, y] = array[startX, startY]; //bishop moves from start to captured point 
                                arrayToPixel(whiteCapture, y); //converts square position to pixels 
                                piece.Location = new Point(pixelArrayX, pixelArrayY); //sets piece to that location 
                                array[startX, startY] = null; //start is set to nothing
                                whiteFirst = false; //white can't go 
                                stopEarly = 0; //stopearly is reset 
                                blackLoss++; //black lost a piece 
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY]; //bishop moves straight from start point to end point 
                                array[startX, startY] = null; //start point is null 
                                whiteFirst = false; //white can't go 
                            }
                            turncounter++; //turn gets incremented 
                            whiteTurn.Visible = false; //white can't go
                            blackTurn.Visible = true; //black can 
                            winner(); //check for winner
                        }

                    } //moves diagonally bottom left
                    else if (((startY != endY) && (startX != endX)) && ((startX < endX) && (startY < endY)))           //moves diagonally bottom right
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;
                        for (int i = startX; i <= endX; i++)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveBishop = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'b')             //if we hit an enemy piece
                                {
                                    whiteCapture = i;
                                    canMoveBishop = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveBishop = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y++;
                        }

                        if (canMoveBishop == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToWhitePrison(movedTo);
                                blackLoss++;
                                array[whiteCapture, y] = array[startX, startY];
                                arrayToPixel(whiteCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = false;
                                stopEarly = 0;
                                feedback_TextBox.AppendText("3. help");
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = false;
                                feedback_TextBox.AppendText("4. help");
                            }
                            turncounter++;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();
                        }

                    }
                    else if (((startY != endY) && (startX != endX)) && ((startX > endX) && (startY > endY)))           //moves diagonally top left
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;

                        for (int i = startX; i >= endX; i--)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveBishop = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'b')             //if we hit an enemy piece
                                {
                                    whiteCapture = i;
                                    canMoveBishop = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveBishop = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y--;
                        }

                        if (canMoveBishop == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToWhitePrison(movedTo);
                                array[whiteCapture, y] = array[startX, startY];
                                arrayToPixel(whiteCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = false;
                                stopEarly = 0;
                                blackLoss++;
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = false;
                            }
                            turncounter++;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();
                        }

                    }
                    else if (((startY != endY) && (startX != endX)) && ((startX < endX) && (startY > endY)))         //moves diagonally bottom right   
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;
                        for (int i = startX; i <= endX; i++)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveBishop = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'b')             //if we hit an enemy piece
                                {
                                    whiteCapture = i;
                                    canMoveBishop = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveBishop = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y--;
                        }

                        if (canMoveBishop == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToWhitePrison(movedTo);
                                blackLoss++;
                                array[whiteCapture, y] = array[startX, startY];
                                arrayToPixel(whiteCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = false;
                                stopEarly = 0;
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = false;
                            }
                            turncounter++;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();
                        }

                    }
                    else
                    {
                        piece.Location = new Point(resetX, resetY);
                        feedback_TextBox.Clear();
                        feedback_TextBox.AppendText("Bishops can move up to 8 spaces diagonally only");
                    }
                }
                else
                {
                    piece.Location = new Point(resetX, resetY);
                    feedback_TextBox.Clear();
                    feedback_TextBox.AppendText("That is not your piece");
                }
            }
            else if (whiteFirst == false)                     //if black turn
            {
                if (array[startX, startY] == "blackBishop1" || array[startX, startY] == "blackBishop2")      //if the selected piece was a white king
                {
                    if (((startY != endY) && (startX != endX)) && ((startX > endX) && (startY < endY)))           //moves diagonally bottom right
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;
                        for (int i = startX; i >= endX; i--)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveBishop = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'w')             //if we hit an enemy piece
                                {
                                    blackCapture = i;
                                    canMoveBishop = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveBishop = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y++;
                        }

                        if (canMoveBishop == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToBlackPrison(movedTo);
                                array[blackCapture, y] = array[startX, startY];
                                arrayToPixel(blackCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = true;
                                stopEarly = 0;
                                whiteLoss++;
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = true;
                            }
                            turncounter++;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }

                    } //moves diagonally bottom left
                    else if (((startY != endY) && (startX != endX)) && ((startX < endX) && (startY < endY)))           //moves diagonally bottom right
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;
                        for (int i = startX; i <= endX; i++)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveBishop = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'w')             //if we hit an enemy piece
                                {
                                    blackCapture = i;
                                    canMoveBishop = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveBishop = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y++;
                        }

                        if (canMoveBishop == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToBlackPrison(movedTo);
                                whiteLoss++;
                                array[blackCapture, y] = array[startX, startY];
                                arrayToPixel(blackCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = true;
                                stopEarly = 0;
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = true;
                            }
                            turncounter++;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }

                    }
                    else if (((startY != endY) && (startX != endX)) && ((startX > endX) && (startY > endY)))           //moves diagonally top left
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;

                        for (int i = startX; i >= endX; i--)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveBishop = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'w')             //if we hit an enemy piece
                                {
                                    blackCapture = i;
                                    canMoveBishop = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveBishop = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y--;
                        }

                        if (canMoveBishop == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToBlackPrison(movedTo);
                                whiteLoss++;
                                array[blackCapture, y] = array[startX, startY];
                                arrayToPixel(blackCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = true;
                                stopEarly = 0;
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = true;
                            }
                            turncounter++;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }

                    }
                    else if (((startY != endY) && (startX != endX)) && ((startX < endX) && (startY > endY)))         //moves diagonally top right   
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;
                        for (int i = startX; i <= endX; i++)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveBishop = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'w')             //if we hit an enemy piece
                                {
                                    blackCapture = i;
                                    canMoveBishop = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveBishop = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y--;
                        }

                        if (canMoveBishop == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToBlackPrison(movedTo);
                                whiteLoss++;
                                array[blackCapture, y] = array[startX, startY];
                                arrayToPixel(blackCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = true;
                                stopEarly = 0;
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = true;
                            }
                            turncounter++;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }
                    }
                    else
                    {
                        piece.Location = new Point(resetX, resetY);
                        feedback_TextBox.Clear();
                        feedback_TextBox.AppendText("Bishops can move up to 8 spaces diagonally only");
                    }
                }
                else
                {
                    piece.Location = new Point(resetX, resetY);
                    //feedback_TextBox.Clear();
                    feedback_TextBox.AppendText("That is not your piece");
                }
            }
            else
            {
                piece.Location = new Point(resetX, resetY);
                feedback_TextBox.AppendText("That is not your piece");
            }
        }

        //move the king
        private void moveKing(PictureBox piece, int startX, int startY, int endX, int endY, int resetX, int resetY)
        {
            movedTo = array[endX, endY];                //gets what piece is on the square trying to move to

            if (whiteFirst == true)                     //if whites turn
            {
                whiteTurn.Visible = true;
                blackTurn.Visible = false;
                if (array[startX, startY] == "whiteKing")      //if the selected piece was a white king
                {
                    if ((endX == startX + 1 && endY == startY) || (endX == startX - 1 && endY == startY))        //if moving to the sides
                    {
                        if (array[endX, endY] == null)                    //if the space is empty
                        {
                            array[endX, endY] = array[startX, startY];      //set the array to the end location = to the starting location
                            array[startX, startY] = null;
                            turncounter++;                                  //increase turn counter
                            whiteFirst = false;                             //switch turns
                            whiteTurn.Visible = false;                      //switch turn label
                            blackTurn.Visible = true;
                            winner();                                       //check to see if anyone won
                        }
                        else if (movedTo[0] == 'b')                  //if the white king moves to a black piece
                        {
                            moveToWhitePrison(movedTo);              //send the picture to prison 
                            blackLoss++;        
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = false;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if ((endY == startY + 1 && endX == startX) || (endY == startY - 1 && endX == startX))   //moving up/down
                    {
                        if (array[endX, endY] == null)                    //if the space is empty
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = false;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();
                        }
                        else if (movedTo[0] == 'b')                  //if the white king moves to a black piece
                        {
                            moveToWhitePrison(movedTo);
                            blackLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = false;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if ((endX == startX + 1 && endY == startY + 1) || (endX == startX + 1 && endY == startY - 1))       //moving diagonal top/bottom right
                    {
                        if (array[endX, endY] == null)                    //if the space is empty
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = false;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();
                        }
                        else if (movedTo[0] == 'b')                  //if the white king moves to a black piece
                        {
                            moveToWhitePrison(movedTo);
                            blackLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = false;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if ((endX == startX - 1 && endY == startY + 1) || (endX == startX - 1 && endY == startY - 1))       //moving diagonal top/bottom left
                    {
                        if (array[endX, endY] == null)                    //if the space is empty
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = false;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();
                        }
                        else if (movedTo[0] == 'b')                  //if the white king moves to a black piece
                        {
                            moveToWhitePrison(movedTo);
                            blackLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = false;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();
                        }
                        else                                        //if the king tries to move somewhere else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else
                    {
                        piece.Location = new Point(resetX, resetY);
                        feedback_TextBox.Clear();
                        feedback_TextBox.AppendText("That is not an acceptable move");
                    }
                }
                else
                {
                    piece.Location = new Point(resetX, resetY);
                    feedback_TextBox.Clear();
                    feedback_TextBox.AppendText("That is not an acceptable move");
                }
            }

            else if (whiteFirst == false)                           //if it is black players turn
            {
                whiteTurn.Visible = false;
                blackTurn.Visible = true;
                if (array[startX, startY] == "blackKing")
                {
                    if ((endX == startX + 1 && endY == startY) || (endX == startX - 1 && endY == startY))        //if moving to the sides
                    {
                        if (array[endX, endY] == null)                    //if the space is empty
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = true;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }
                        else if (movedTo[0] == 'w')                  //if the black king moves to a white piece
                        {
                            moveToBlackPrison(movedTo);
                            whiteLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = true;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if ((endY == startY + 1 && endX == startX) || (endY == startY - 1 && endX == startX))   //moving up/down
                    {
                        if (array[endX, endY] == null)                    //if the space is empty
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = true;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }
                        else if (movedTo[0] == 'w')                  //if the black king moves to a white piece
                        {
                            moveToBlackPrison(movedTo);
                            whiteLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = true;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if ((endX == startX + 1 && endY == startY + 1) || (endX == startX + 1 && endY == startY - 1))       //moving diagonal top/bottom right
                    {
                        if (array[endX, endY] == null)                    //if the space is empty
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = true;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }
                        else if (movedTo[0] == 'w')                  //if the black king moves to a white piece
                        {
                            moveToBlackPrison(movedTo);
                            whiteLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = true;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if ((endX == startX - 1 && endY == startY + 1) || (endX == startX - 1 && endY == startY - 1))       //moving diagonal top/bottom left
                    {
                        if (array[endX, endY] == null)                    //if the space is empty
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = true;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }
                        else if (movedTo[0] == 'w')                  //if the black king moves to a white piece
                        {
                            moveToBlackPrison(movedTo);
                            whiteLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            turncounter++;
                            whiteFirst = true;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else
                    {
                        piece.Location = new Point(resetX, resetY);
                        feedback_TextBox.Clear();
                        feedback_TextBox.AppendText("That is not an acceptable move");
                    }
                }
                else
                {
                    piece.Location = new Point(resetX, resetY);
                    feedback_TextBox.Clear();
                    feedback_TextBox.AppendText("That is not an acceptable move");
                }
            }
            else
            {
                piece.Location = new Point(resetX, resetY);
                feedback_TextBox.Clear();
                feedback_TextBox.AppendText("That is not your piece");
            }
        }

        //move the queen
        bool canMoveQueen = false;
        private void moveQueen(PictureBox piece, int startX, int startY, int endX, int endY, int resetX, int resetY)
        {
            int differenceX = 0;
            int differenceY = 0;
            int stopEarly = 0;
            int whiteCapture = 0;
            int blackCapture = 0;
            if (whiteFirst == true)      //if it is whites turn
            {
                if (array[startX, startY] == "whiteQueen")            //if we are moving a white queen
                {
                    if (((startY == endY) && (startX != endX)) || ((startX == endX) && (startY != endY)))    //if we try to move left and right
                    {
                        differenceX = Math.Abs(endX - startX);           //we want the difference of the 2 points
                        differenceY = Math.Abs(endY - startY);

                        if (differenceX == 0)
                        {
                            if (startY < endY)
                            {
                                for (int i = startY; i <= endY; i++)
                                {
                                    if (array[startX, i] == null || array[startX, i] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveQueen = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[startX, i];
                                        if (movedTo[0] == 'b')             //if we hit an enemy piece
                                        {
                                            whiteCapture = i;
                                            canMoveQueen = true;
                                            stopEarly++;                //if a piece was captured, increase counter
                                            break;
                                        }
                                        else
                                        {
                                            canMoveQueen = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveQueen == true)                   //if the queen was allowed to move
                                {
                                    if (stopEarly > 0)                      //if counter is greater than 0, capture piece
                                    {
                                        moveToWhitePrison(movedTo);
                                        array[startX, whiteCapture] = array[startX, startY];
                                        arrayToPixel(startX, whiteCapture);
                                        piece.Location = new Point(pixelArrayX, pixelArrayY);
                                        array[startX, startY] = null;
                                        whiteFirst = false;
                                        stopEarly = 0;
                                        blackLoss++;
                                    }
                                    else                                    //else move normally
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = false;
                                    }
                                    turncounter++;                          //increase turn counter and switch turns
                                    whiteTurn.Visible = false;
                                    blackTurn.Visible = true;
                                    winner();
                                }
                            }
                            else
                            {
                                for (int i = startY; i >= endY; i--)
                                {
                                    if (array[startX, i] == null || array[startX, i] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveQueen = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[startX, i];
                                        if (movedTo[0] == 'b')             //if we hit an enemy piece
                                        {
                                            whiteCapture = i;
                                            canMoveQueen = true;
                                            stopEarly++;
                                            break;
                                        }
                                        else
                                        {
                                            canMoveQueen = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveQueen == true)
                                {
                                    if (stopEarly > 0)
                                    {
                                        moveToWhitePrison(movedTo);
                                        array[startX, whiteCapture] = array[startX, startY];
                                        arrayToPixel(startX, whiteCapture);
                                        piece.Location = new Point(pixelArrayX, pixelArrayY);
                                        array[startX, startY] = null;
                                        whiteFirst = false;
                                        stopEarly = 0;
                                        blackLoss++;
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = false;
                                    }
                                    turncounter++;
                                    whiteTurn.Visible = false;
                                    blackTurn.Visible = true;
                                    winner();
                                }
                            }
                        }
                        else if (differenceY == 0)
                        {
                            if (startX < endX)
                            {
                                for (int i = startX; i <= endX; i++)
                                {
                                    if (array[i, startY] == null || array[i, startY] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveQueen = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[i, startY];
                                        if (movedTo[0] == 'b')             //if we hit an enemy piece
                                        {
                                            whiteCapture = i;
                                            canMoveQueen = true;
                                            stopEarly++;

                                            break;
                                        }
                                        else
                                        {
                                            canMoveQueen = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveQueen == true)
                                {
                                    if (stopEarly > 0)
                                    {
                                        moveToWhitePrison(movedTo);
                                        array[whiteCapture, startY] = array[startX, startY];
                                        arrayToPixel(whiteCapture, startY);
                                        piece.Location = new Point(pixelArrayX, pixelArrayY);
                                        array[startX, startY] = null;
                                        whiteFirst = false;
                                        stopEarly = 0;
                                        blackLoss++;
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = false;
                                    }
                                    turncounter++;
                                    whiteTurn.Visible = false;
                                    blackTurn.Visible = true;
                                    winner();
                                }
                            }
                            else
                            {
                                for (int i = startX; i >= endX; i--)
                                {
                                    if (array[i, startY] == null || array[i, startY] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveQueen = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[i, startY];
                                        if (movedTo[0] == 'b')             //if we hit an enemy piece
                                        {
                                            whiteCapture = i;
                                            canMoveQueen = true;
                                            stopEarly++;

                                            break;
                                        }
                                        else
                                        {
                                            canMoveQueen = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveQueen == true)
                                {
                                    if (stopEarly > 0)
                                    {
                                        moveToWhitePrison(movedTo);
                                        array[whiteCapture, startY] = array[startX, startY];
                                        arrayToPixel(whiteCapture, startY);
                                        piece.Location = new Point(pixelArrayX, pixelArrayY);
                                        array[startX, startY] = null;
                                        whiteFirst = false;
                                        stopEarly = 0;
                                        blackLoss++;
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = false;
                                    }
                                    turncounter++;
                                    whiteTurn.Visible = false;
                                    blackTurn.Visible = true;
                                    winner();
                                }
                            }
                        }
                    }
                    else if (((startY != endY) && (startX != endX)) && ((startX > endX) && (startY < endY)))           //moves diagonally top right
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;
                        for (int i = startX; i >= endX; i--)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveQueen = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'b')             //if we hit an enemy piece
                                {
                                    whiteCapture = i;
                                    canMoveQueen = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveQueen = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y++;
                        }

                        if (canMoveQueen == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToWhitePrison(movedTo);
                                array[whiteCapture, y] = array[startX, startY];
                                arrayToPixel(whiteCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = false;
                                stopEarly = 0;
                                blackLoss++;
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = false;
                            }
                            turncounter++;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();
                        }

                    } //moves diagonally bottom left
                    else if (((startY != endY) && (startX != endX)) && ((startX < endX) && (startY < endY)))           //moves diagonally bottom right
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;
                        for (int i = startX; i <= endX; i++)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveQueen = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'b')             //if we hit an enemy piece
                                {
                                    whiteCapture = i;
                                    canMoveQueen = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveQueen = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y++;
                        }

                        if (canMoveQueen == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToWhitePrison(movedTo);
                                blackLoss++;
                                array[whiteCapture, y] = array[startX, startY];
                                arrayToPixel(whiteCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = false;
                                stopEarly = 0;
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = false;
                            }
                            turncounter++;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();
                        }

                    }
                    else if (((startY != endY) && (startX != endX)) && ((startX > endX) && (startY > endY)))           //moves diagonally top left
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;

                        for (int i = startX; i >= endX; i--)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveQueen = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'b')             //if we hit an enemy piece
                                {
                                    whiteCapture = i;
                                    canMoveQueen = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveQueen = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y--;
                        }

                        if (canMoveQueen == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToWhitePrison(movedTo);
                                array[whiteCapture, y] = array[startX, startY];
                                arrayToPixel(whiteCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = false;
                                stopEarly = 0;
                                blackLoss++;
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = false;
                            }
                            turncounter++;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();
                        }

                    }
                    else if (((startY != endY) && (startX != endX)) && ((startX < endX) && (startY > endY)))         //moves diagonally bottom right   
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;
                        for (int i = startX; i <= endX; i++)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveQueen = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'b')             //if we hit an enemy piece
                                {
                                    whiteCapture = i;
                                    canMoveQueen = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveQueen = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y--;
                        }

                        if (canMoveQueen == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToWhitePrison(movedTo);
                                blackLoss++;
                                array[whiteCapture, y] = array[startX, startY];
                                arrayToPixel(whiteCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = false;
                                stopEarly = 0;
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = false;
                            }
                            turncounter++;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            winner();
                        }

                    }
                    else
                    {
                        piece.Location = new Point(resetX, resetY);
                        feedback_TextBox.Clear();
                        feedback_TextBox.AppendText("The queen can not move there");
                    }
                }
                else
                {
                    piece.Location = new Point(resetX, resetY);
                    feedback_TextBox.Clear();
                    feedback_TextBox.AppendText("That is not your piece");
                }
            }

            else if (whiteFirst == false)    //if blacks turn
            {
                if (array[startX, startY] == "blackQueen")            //if we are moving a white rook
                {
                    if (((startY == endY) && (startX != endX)) || ((startX == endX) && (startY != endY)))    //if we try to move left and right
                    {
                        differenceX = Math.Abs(endX - startX);           //we want the difference of the 2 points
                        differenceY = Math.Abs(endY - startY);

                        if (differenceX == 0)
                        {
                            if (startY < endY)
                            {
                                for (int i = startY; i <= endY; i++)
                                {
                                    if (array[startX, i] == null || array[startX, i] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveQueen = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[startX, i];
                                        if (movedTo[0] == 'w')             //if we hit an enemy piece
                                        {
                                            blackCapture = i;
                                            canMoveQueen = true;
                                            stopEarly++;
                                            break;
                                        }
                                        else
                                        {
                                            canMoveQueen = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveQueen == true)
                                {
                                    if (stopEarly > 0)
                                    {
                                        moveToBlackPrison(movedTo);
                                        array[startX, blackCapture] = array[startX, startY];
                                        arrayToPixel(startX, blackCapture);
                                        piece.Location = new Point(pixelArrayX, pixelArrayY);
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                        stopEarly = 0;
                                        whiteLoss++;
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                    }
                                    turncounter++;
                                    whiteTurn.Visible = true;
                                    blackTurn.Visible = false;
                                    winner();
                                }
                            }
                            else
                            {
                                for (int i = startY; i >= endY; i--)
                                {
                                    if (array[startX, i] == null || array[startX, i] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveQueen = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[startX, i];
                                        if (movedTo[0] == 'w')             //if we hit an enemy piece
                                        {
                                            blackCapture = i;
                                            canMoveQueen = true;
                                            stopEarly++;
                                            break;
                                        }
                                        else
                                        {
                                            canMoveQueen = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveQueen == true)
                                {
                                    if (stopEarly > 0)
                                    {
                                        moveToBlackPrison(movedTo);
                                        array[startX, blackCapture] = array[startX, startY];
                                        arrayToPixel(startX, blackCapture);
                                        piece.Location = new Point(pixelArrayX, pixelArrayY);
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                        stopEarly = 0;
                                        whiteLoss++;
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                    }

                                    turncounter++;
                                    whiteTurn.Visible = true;
                                    blackTurn.Visible = false;
                                    winner();
                                }
                            }
                        }
                        else if (differenceY == 0)
                        {
                            if (startX < endX)
                            {
                                for (int i = startX; i <= endX; i++)
                                {
                                    if (array[i, startY] == null || array[i, startY] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveQueen = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[i, startY];
                                        if (movedTo[0] == 'w')             //if we hit an enemy piece
                                        {
                                            blackCapture = i;
                                            canMoveQueen = true;
                                            stopEarly++;

                                            break;
                                        }
                                        else
                                        {
                                            canMoveQueen = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveQueen == true)
                                {
                                    if (stopEarly > 0)
                                    {
                                        moveToBlackPrison(array[blackCapture, startY]);
                                        whiteLoss++;
                                        movedTo = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                        stopEarly = 0;
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                    }

                                    turncounter++;
                                    whiteTurn.Visible = true;
                                    blackTurn.Visible = false;
                                    winner();
                                }
                            }
                            else
                            {
                                for (int i = startX; i >= endX; i--)
                                {
                                    if (array[i, startY] == null || array[i, startY] == piece.Name)                //if all of the points from the start to end are empty
                                    {
                                        canMoveQueen = true;                         //we want to be able to move
                                    }
                                    else
                                    {
                                        movedTo = array[i, startY];
                                        if (movedTo[0] == 'w')             //if we hit an enemy piece
                                        {
                                            blackCapture = i;
                                            canMoveQueen = true;
                                            stopEarly++;

                                            break;
                                        }
                                        else
                                        {
                                            canMoveQueen = false;
                                            piece.Location = new Point(resetX, resetY);
                                            feedback_TextBox.Clear();
                                            feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                            break;
                                        }
                                    }
                                }

                                if (canMoveQueen == true)
                                {
                                    if (stopEarly > 0)
                                    {
                                        moveToBlackPrison(movedTo);
                                        array[blackCapture, startY] = array[startX, startY];
                                        arrayToPixel(blackCapture, startY);
                                        piece.Location = new Point(pixelArrayX, pixelArrayY);
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                        stopEarly = 0;
                                        whiteLoss++;
                                    }
                                    else
                                    {
                                        array[endX, endY] = array[startX, startY];
                                        array[startX, startY] = null;
                                        whiteFirst = true;
                                    }
                                    turncounter++;
                                    whiteTurn.Visible = true;
                                    blackTurn.Visible = false;
                                    winner();
                                }
                            }
                        }
                    }
                    else if (((startY != endY) && (startX != endX)) && ((startX > endX) && (startY < endY)))           //moves diagonally bottom right
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;
                        for (int i = startX; i >= endX; i--)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveQueen = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'w')             //if we hit an enemy piece
                                {
                                    blackCapture = i;
                                    canMoveQueen = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveQueen = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y++;
                        }

                        if (canMoveQueen == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToBlackPrison(movedTo);
                                array[blackCapture, y] = array[startX, startY];
                                arrayToPixel(blackCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = true;
                                stopEarly = 0;
                                whiteLoss++;
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = true;
                            }
                            turncounter++;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }

                    } //moves diagonally bottom left
                    else if (((startY != endY) && (startX != endX)) && ((startX < endX) && (startY < endY)))           //moves diagonally bottom right
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;
                        for (int i = startX; i <= endX; i++)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveQueen = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'w')             //if we hit an enemy piece
                                {
                                    blackCapture = i;
                                    canMoveQueen = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveQueen = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y++;
                        }

                        if (canMoveQueen == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToBlackPrison(movedTo);
                                whiteLoss++;
                                array[blackCapture, y] = array[startX, startY];
                                arrayToPixel(blackCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = true;
                                stopEarly = 0;
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = true;
                            }
                            turncounter++;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }

                    }
                    else if (((startY != endY) && (startX != endX)) && ((startX > endX) && (startY > endY)))           //moves diagonally top left
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;

                        for (int i = startX; i >= endX; i--)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveQueen = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'w')             //if we hit an enemy piece
                                {
                                    blackCapture = i;
                                    canMoveQueen = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveQueen = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y--;
                        }

                        if (canMoveQueen == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToBlackPrison(movedTo);
                                whiteLoss++;
                                array[blackCapture, y] = array[startX, startY];
                                arrayToPixel(blackCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = true;
                                stopEarly = 0;
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = true;
                            }
                            turncounter++;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }

                    }
                    else if (((startY != endY) && (startX != endX)) && ((startX < endX) && (startY > endY)))         //moves diagonally top right   
                    {
                        differenceX = Math.Abs(endX - startX);
                        differenceY = Math.Abs(endY - startY);
                        int x = startX;
                        int y = startY;
                        for (int i = startX; i <= endX; i++)
                        {
                            if (array[i, y] == null || array[i, y] == piece.Name)                //if all of the points from the start to end are empty
                            {
                                canMoveQueen = true;                         //we want to be able to move
                            }
                            else
                            {
                                movedTo = array[i, y];
                                if (movedTo[0] == 'w')             //if we hit an enemy piece
                                {
                                    blackCapture = i;
                                    canMoveQueen = true;
                                    stopEarly++;
                                    break;
                                }
                                else
                                {
                                    canMoveQueen = false;
                                    piece.Location = new Point(resetX, resetY);
                                    feedback_TextBox.Clear();
                                    feedback_TextBox.AppendText("You can not move there. There are pieces in the way");
                                    break;
                                }
                            }
                            y--;
                        }

                        if (canMoveQueen == true)
                        {
                            if (stopEarly > 0)
                            {
                                moveToBlackPrison(movedTo);
                                whiteLoss++;
                                array[blackCapture, y] = array[startX, startY];
                                arrayToPixel(blackCapture, y);
                                piece.Location = new Point(pixelArrayX, pixelArrayY);
                                array[startX, startY] = null;
                                whiteFirst = true;
                                stopEarly = 0;
                            }
                            else
                            {
                                array[endX, endY] = array[startX, startY];
                                array[startX, startY] = null;
                                whiteFirst = true;
                            }
                            turncounter++;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            winner();
                        }
                    }
                    else
                    {
                        piece.Location = new Point(resetX, resetY);
                        feedback_TextBox.Clear();
                        feedback_TextBox.AppendText("Queen can not move there");
                    }
                }
                else
                {
                    piece.Location = new Point(resetX, resetY);
                    feedback_TextBox.Clear();
                    feedback_TextBox.AppendText("That is not your piece");
                }
            }
            else
            {
                piece.Location = new Point(resetX, resetY);
                feedback_TextBox.AppendText("That is not your piece");
            }
        }

        //move knights
        private void moveKnight(PictureBox piece, int startX, int startY, int endX, int endY, int resetX, int resetY)
        {
            movedTo = array[endX, endY];                //gets what piece is on the square trying to move to

            int x = startX;
            int y = startY;

            if (whiteFirst == true)      //if it is whites turn
            {
                if (array[startX, startY] == "whiteKnight1" || array[startX, startY] == "whiteKnight2")            //if we are moving a white rook
                {
                    if (x + 2 == endX && y + 1 == endY)       //if trying to move right 2, down 1
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else if (movedTo[0] == 'b')        //if an enemy piece is there
                        {
                            moveToWhitePrison(movedTo);
                            blackLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if (x + 2 == endX && y - 1 == endY)     //if trying to move right 2, up 1
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else if (movedTo[0] == 'b')        //if an enemy piece is there
                        {
                            moveToWhitePrison(movedTo);
                            blackLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if (x - 2 == endX && y - 1 == endY)     //if trying to move left 2, up 1
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else if (movedTo[0] == 'b')        //if an enemy piece is there
                        {
                            moveToWhitePrison(movedTo);
                            blackLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if (x - 2 == endX && y + 1 == endY)     //if trying to move left 2, down 1
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else if (movedTo[0] == 'b')        //if an enemy piece is there
                        {
                            moveToWhitePrison(movedTo);
                            blackLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if (x + 1 == endX && y + 2 == endY)     //if trying to move right 1 and down 2
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else if (movedTo[0] == 'b')        //if an enemy piece is there
                        {
                            moveToWhitePrison(movedTo);
                            blackLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if (x + 1 == endX && y - 2 == endY)     //if trying to move right 1, up 2
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else if (movedTo[0] == 'b')        //if an enemy piece is there
                        {
                            moveToWhitePrison(movedTo);
                            blackLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if (x - 1 == endX && y + 2 == endY)    //if trying to move left 1, down 2
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else if (movedTo[0] == 'b')        //if an enemy piece is there
                        {
                            moveToWhitePrison(movedTo);
                            blackLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if (x - 1 == endX && y - 2 == endY)    //if trying to move left 1, up 2
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else if (movedTo[0] == 'b')        //if an enemy piece is there
                        {
                            moveToWhitePrison(movedTo);
                            blackLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = false;
                            blackTurn.Visible = true;
                            turncounter++;
                            whiteFirst = false;
                            winner();
                        }
                        else
                        {
                            piece.Location = new Point(resetX, resetY);
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else
                    {
                        piece.Location = new Point(resetX, resetY);
                        feedback_TextBox.Clear();
                        feedback_TextBox.AppendText("That is not an acceptable move");
                    }
                }
                else
                {
                    piece.Location = new Point(resetX, resetY);
                    feedback_TextBox.Clear();
                    feedback_TextBox.AppendText("That is not an acceptable move");
                }
            }

            else if (whiteFirst == false)                       //if black players turn
            {
                if (array[startX, startY] == "blackKnight1" || array[startX, startY] == "blackKnight2")     //if a black knight
                {
                    if (x + 2 == endX && y + 1 == endY)       //if trying to move right 2, down 1
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else if (movedTo[0] == 'w')        //if an enemy piece is there
                        {
                            moveToBlackPrison(movedTo);
                            whiteLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else
                        {
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if (x + 2 == endX && y - 1 == endY)     //if trying to move right 2, up 1
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else if (movedTo[0] == 'w')        //if an enemy piece is there
                        {
                            moveToBlackPrison(movedTo);
                            whiteLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else
                        {
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if (x - 2 == endX && y - 1 == endY)     //if trying to move left 2, up 1
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else if (movedTo[0] == 'w')        //if an enemy piece is there
                        {
                            moveToBlackPrison(movedTo);
                            whiteLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else
                        {
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if (x - 2 == endX && y + 1 == endY)     //if trying to move left 2, down 1
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else if (movedTo[0] == 'w')        //if an enemy piece is there
                        {
                            moveToBlackPrison(movedTo);
                            whiteLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else
                        {
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if (x + 1 == endX && y + 2 == endY)     //if trying to move right 1 and down 2
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else if (movedTo[0] == 'w')        //if an enemy piece is there
                        {
                            moveToBlackPrison(movedTo);
                            whiteLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else
                        {
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if (x + 1 == endX && y - 2 == endY)     //if trying to move right 1, up 2
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else if (movedTo[0] == 'w')        //if an enemy piece is there
                        {
                            moveToBlackPrison(movedTo);
                            whiteLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else
                        {
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if (x - 1 == endX && y + 2 == endY)    //if trying to move left 1, down 2
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else if (movedTo[0] == 'w')        //if an enemy piece is there
                        {
                            moveToBlackPrison(movedTo);
                            whiteLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else
                        {
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else if (x - 1 == endX && y - 2 == endY)    //if trying to move left 1, up 2
                    {
                        if (array[endX, endY] == null)        //if empty move there
                        {
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else if (movedTo[0] == 'w')        //if an enemy piece is there
                        {
                            moveToBlackPrison(movedTo);
                            whiteLoss++;
                            array[endX, endY] = array[startX, startY];
                            array[startX, startY] = null;
                            whiteTurn.Visible = true;
                            blackTurn.Visible = false;
                            turncounter++;
                            whiteFirst = true;
                            winner();
                        }
                        else
                        {
                            feedback_TextBox.Clear();
                            feedback_TextBox.AppendText("That is not an acceptable move");
                        }
                    }
                    else
                    {
                        piece.Location = new Point(resetX, resetY);
                        feedback_TextBox.Clear();
                        feedback_TextBox.AppendText("That is not an acceptable move");
                    }
                }
                else
                {
                    piece.Location = new Point(resetX, resetY);
                    feedback_TextBox.Clear();
                    feedback_TextBox.AppendText("That is not an acceptable move");
                }
            }
            else
            {
                piece.Location = new Point(resetX, resetY);
                feedback_TextBox.Clear();
                feedback_TextBox.AppendText("It is not your turn");
            }
        }

        //creates the starting array will pieces set up
        private void createArray()
        {
            array = new string[8, 8];
            array[0, 0] = "blackRook1";     //add the white rooks
            array[0, 7] = "blackRook2";
            array[0, 1] = "blackKnight1";     //add the white horses
            array[0, 6] = "blackKnight2";
            array[0, 2] = "blackBishop1";     //add the white bishops
            array[0, 5] = "blackBishop2";
            array[0, 3] = "blackQueen";     //add white queen
            array[0, 4] = "blackKing";     //add the white king

            array[7, 0] = "whiteRook1";     //add the black rooks
            array[7, 7] = "whiteRook2";
            array[7, 1] = "whiteKnight1";     //add the black horses
            array[7, 6] = "whiteKnight2";
            array[7, 2] = "whiteBishop1";     //add the black bishops
            array[7, 5] = "whiteBishop2";
            array[7, 4] = "whiteKing";     //add black king
            array[7, 3] = "whiteQueen";     //add the black queen

            array[1, 0] = "blackPawn1"; //adding black pawns
            array[1, 1] = "blackPawn2";
            array[1, 2] = "blackPawn3";
            array[1, 3] = "blackPawn4";
            array[1, 4] = "blackPawn5";
            array[1, 5] = "blackPawn6";
            array[1, 6] = "blackPawn7";
            array[1, 7] = "blackPawn8";

            array[6, 0] = "whitePawn1"; //adding white pawns 
            array[6, 1] = "whitePawn2";
            array[6, 2] = "whitePawn3";
            array[6, 3] = "whitePawn4";
            array[6, 4] = "whitePawn5";
            array[6, 5] = "whitePawn6";
            array[6, 6] = "whitePawn7";
            array[6, 7] = "whitePawn8";

            for (int i = 0; i < 8; i++) //other spaces will be null 
            {
                array[2, i] = null;
                array[3, i] = null;
                array[4, i] = null;
                array[5, i] = null;
            }
        }

        //will get the total amount of pieces on the game board and count how many each player has. Winner has more than 0 pieces or if king is dead
        private void winner()
        {
            bool whiteKing = false;                     //bools to see if the king is still alive
            bool blackKing = false;

            for (int i = 0; i < 8; i++)                 //check the board for the king
            {
                for (int j = 0; j < 8; j++)
                {
                    string pieceName = array[i, j];
                    if (array[i, j] != null)
                    {
                        if (array[i, j] == "whiteKing")         //if white king was found
                        {
                            whiteKing = true;
                        }
                        else if (array[i, j] == "blackKing")    //if black king was found
                        {
                            blackKing = true;
                        }
                    }
                }
            }
            if (whiteLoss >= 16)           //if white player lost all pieces
            {
                feedback_TextBox.Clear();
                feedback_TextBox.AppendText("Game over. White player lost all pieces. Black player wins");
                endGame();
            }
            else if (blackLoss >= 16)      //if black player lost all pieces
            {
                feedback_TextBox.Clear();
                feedback_TextBox.AppendText("Game over. Black player lost all pieces. White player wins");
                endGame();
            }
            else if (whiteKing == false)    //if white king was killed
            {
                feedback_TextBox.Clear();
                feedback_TextBox.AppendText("Game over. White player has lost their king. Black player wins");
                endGame();
            }
            else if (blackKing == false)    //if black king wass killed
            {
                feedback_TextBox.Clear();
                feedback_TextBox.AppendText("Game over. Black player has lost their king. White player wins");
                endGame();
            }
        }

        //for stopping the game
        private void endGame()
        {   //displays stats 
            feedback_TextBox.AppendText("\n\nTurns taken: " + turncounter);
            feedback_TextBox.AppendText("\nTime taken: " + theTime.Elapsed);
            feedback_TextBox.AppendText("\nWhite Player losses: " + whiteLoss);
            feedback_TextBox.AppendText("\nBlack Player losses: " + blackLoss);

            theTime.Reset(); //stopwatch will get reset
            Start_Button.Enabled = true; //game can be restarted 
            surrender_Button.Enabled = false; //can't end when just did 
            chessBoard.Enabled = false; //can't click the board when game done 
        }

        //helpful for seeing details about the pieces
        private void chessBoard_MouseDoubleClick(object sender, MouseEventArgs e)
        {   //this was for debugging purposes as well 
            int row, col;

            col = e.X / (chessBoard.Width / 8);     //when you click the chess board, this will tell
            row = e.Y / (chessBoard.Height / 8);    //where you are on it

            feedback_TextBox.Clear();
            feedback_TextBox.AppendText("You have clicked row " + row + " and column " + col + "\n"); //displays rows and columns and where are the pieces in our array 

            if (array[row, col] == "blackPawn1")
            {
                feedback_TextBox.AppendText("\nBlack pawn 1. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "blackPawn2")
            {
                feedback_TextBox.AppendText("\nBlack pawn 2. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "blackPawn3")
            {
                feedback_TextBox.AppendText("\nBlack pawn 3. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "blackPawn4")
            {
                feedback_TextBox.AppendText("\nBlack pawn 4. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "blackPawn5")
            {
                feedback_TextBox.AppendText("\nBlack pawn 5. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "blackPawn6")
            {
                feedback_TextBox.AppendText("\nBlack pawn 6. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "blackPawn7")
            {
                feedback_TextBox.AppendText("\nBlack pawn 7. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "blackPawn8")
            {
                feedback_TextBox.AppendText("\nBlack pawn 8. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "whitePawn1")
            {
                feedback_TextBox.AppendText("\nWhite pawn 1. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "whitePawn2")
            {
                feedback_TextBox.AppendText("\nWhite pawn 2. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "whitePawn3")
            {
                feedback_TextBox.AppendText("\nWhite pawn 3. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "whitePawn4")
            {
                feedback_TextBox.AppendText("\nWhite pawn 4. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "whitePawn5")
            {
                feedback_TextBox.AppendText("\nWhite pawn 5. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "whitePawn6")
            {
                feedback_TextBox.AppendText("\nWhite pawn 6. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "whitePawn7")
            {
                feedback_TextBox.AppendText("\nWhite pawn 7. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "whitePawn8")
            {
                feedback_TextBox.AppendText("\nWhite pawn 8. Can move only 1 square forward(or 2 squares forawrd for the first round) and attacks 1 square diagonally forward");
            }
            else if (array[row, col] == "blackRook1")
            {
                feedback_TextBox.AppendText("\nBlack rook 1. Can move up to 8 square forward, back, left and right");
            }
            else if (array[row, col] == "blackRook2")
            {
                feedback_TextBox.AppendText("\nBlack rook 2. Can move up to 8 square forward, back, left and right");
            }
            else if (array[row, col] == "whiteRook1")
            {
                feedback_TextBox.AppendText("\nWhite rook 1. Can move up to 8 square forward, back, left and right");
            }
            else if (array[row, col] == "whiteRook2")
            {
                feedback_TextBox.AppendText("\nWhite rook 2. Can move up to 8 square forward, back, left and right");
            }
            else if (array[row, col] == "blackKing")
            {
                feedback_TextBox.AppendText("\nBlack king. Can move 1 square forward, back, left, right and diagonally");
                feedback_TextBox.AppendText("\nDo not let him get captured");
            }
            else if (array[row, col] == "whiteKing")
            {
                feedback_TextBox.AppendText("\nWhite king. Can move 1 square forward, back, left, right and diagonally");
                feedback_TextBox.AppendText("\nDo not let him get captured");
            }
            else if (array[row, col] == "blackQueen")
            {
                feedback_TextBox.AppendText("\nBlack queen. Can move up to 8 square forward, back, left, right and diagonally");
            }
            else if (array[row, col] == "whiteQueen")
            {
                feedback_TextBox.AppendText("\nWhite queen. Can move up to 8 square forward, back, left, right and diagonally");
            }
            else if (array[row, col] == "blackKnight1")
            {
                feedback_TextBox.AppendText("\nBlack knight 1. Can move 1 square forward/back and 2 to the sides, or 2 squares forward/back and 1 to the side");
                feedback_TextBox.AppendText("\nCan jump over pieces");
            }
            else if (array[row, col] == "blackKnight2")
            {
                feedback_TextBox.AppendText("\nBlack knight 2. Can move 1 square forward/back and 2 to the sides, or 2 squares forward/back and 1 to the side");
                feedback_TextBox.AppendText("\nCan jump over pieces");
            }
            else if (array[row, col] == "whiteKnight1")
            {
                feedback_TextBox.AppendText("\nWhite knight 1. Can move 1 square forward/back and 2 to the sides, or 2 squares forward/back and 1 to the side");
                feedback_TextBox.AppendText("\nCan jump over pieces");
            }
            else if (array[row, col] == "whiteKnight2")
            {
                feedback_TextBox.AppendText("\nWhite knight 2. Can move 1 square forward/back and 2 to the sides, or 2 squares forward/back and 1 to the side");
                feedback_TextBox.AppendText("\nCan jump over pieces");
            }
            else if (array[row, col] == "blackBishop1")
            {
                feedback_TextBox.AppendText("\nBlack bishop 1. Can move up to 8 squares diagonally");
            }
            else if (array[row, col] == "blackBishop2")
            {
                feedback_TextBox.AppendText("\nBlack bishop2. Can move up to 8 squares diagonally");
            }
            else if (array[row, col] == "whiteBishop1")
            {
                feedback_TextBox.AppendText("\nWhite bishop1. Can move up to 8 squares diagonally");
            }
            else if (array[row, col] == "whiteBishop2")
            {
                feedback_TextBox.AppendText("\nWhite bishop2. Can move up to 8 squares diagonally");
            }
            else if (array[row, col] == null)
            {
                feedback_TextBox.AppendText("\nEmpty space");
            }
        }

        //for when the pawn reaches the other end, set it to a queen
        private void promotion(PictureBox piece, int xcor, int ycor)
        {
            string promotion = array[xcor, ycor]; //takes the coordinate of the pawn
            if (promotion[0] == 'w') //checks if its white 
            {
                System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
                Image image = ((System.Drawing.Image)(resources.GetObject("whiteQueen.Image"))); //replaces image with a white queen 
                piece.Image = image; //sets it 
                array[xcor, ycor] = "whiteQueen"; //changes array 
            }
            else if(promotion[0] == 'b') //checks if its black 
            {
                System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
                Image image = ((System.Drawing.Image)(resources.GetObject("blackQueen.Image"))); //replaces image with a black queen 
                piece.Image = image; //sets it
                array[xcor, ycor] = "blackQueen"; //array 
            }
        }
    }
}