﻿/********************************************************************
CSCI 473 - Assignment 5 - Spring 2020

Programmers: Theresa Li (Z1814730), Charles Alms (Z1797837) 
Section:    1
TA:         Jennifer Ho & Sridivya Pagadala
Date Due:   4/16/20

Purpose:    This program is teaching us how to build a chess game in C#
*********************************************************************/
namespace TheresaLiCharlesAlms_Assign5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.chessBoard = new System.Windows.Forms.PictureBox();
            this.feedback_TextBox = new System.Windows.Forms.RichTextBox();
            this.Start_Button = new System.Windows.Forms.Button();
            this.surrender_Button = new System.Windows.Forms.Button();
            this.blackbutton = new System.Windows.Forms.Button();
            this.whitebutton = new System.Windows.Forms.Button();
            this.randombutton = new System.Windows.Forms.Button();
            this.blackGraveYard = new System.Windows.Forms.PictureBox();
            this.blackQueen = new System.Windows.Forms.PictureBox();
            this.blackKing = new System.Windows.Forms.PictureBox();
            this.blackBishop1 = new System.Windows.Forms.PictureBox();
            this.blackKnight1 = new System.Windows.Forms.PictureBox();
            this.blackBishop2 = new System.Windows.Forms.PictureBox();
            this.blackKnight2 = new System.Windows.Forms.PictureBox();
            this.blackRook1 = new System.Windows.Forms.PictureBox();
            this.blackRook2 = new System.Windows.Forms.PictureBox();
            this.blackPawn1 = new System.Windows.Forms.PictureBox();
            this.blackPawn2 = new System.Windows.Forms.PictureBox();
            this.blackPawn3 = new System.Windows.Forms.PictureBox();
            this.blackPawn4 = new System.Windows.Forms.PictureBox();
            this.blackPawn5 = new System.Windows.Forms.PictureBox();
            this.blackPawn6 = new System.Windows.Forms.PictureBox();
            this.blackPawn7 = new System.Windows.Forms.PictureBox();
            this.blackPawn8 = new System.Windows.Forms.PictureBox();
            this.whiteQueen = new System.Windows.Forms.PictureBox();
            this.whiteKing = new System.Windows.Forms.PictureBox();
            this.whiteBishop1 = new System.Windows.Forms.PictureBox();
            this.whiteBishop2 = new System.Windows.Forms.PictureBox();
            this.whiteKnight1 = new System.Windows.Forms.PictureBox();
            this.whiteKnight2 = new System.Windows.Forms.PictureBox();
            this.whiteRook1 = new System.Windows.Forms.PictureBox();
            this.whiteRook2 = new System.Windows.Forms.PictureBox();
            this.whitePawn1 = new System.Windows.Forms.PictureBox();
            this.whitePawn2 = new System.Windows.Forms.PictureBox();
            this.whitePawn3 = new System.Windows.Forms.PictureBox();
            this.whitePawn4 = new System.Windows.Forms.PictureBox();
            this.whitePawn5 = new System.Windows.Forms.PictureBox();
            this.whitePawn6 = new System.Windows.Forms.PictureBox();
            this.whitePawn7 = new System.Windows.Forms.PictureBox();
            this.whitePawn8 = new System.Windows.Forms.PictureBox();
            this.whiteGraveYard = new System.Windows.Forms.PictureBox();
            this.blackTurn = new System.Windows.Forms.Label();
            this.whiteTurn = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.chessBoard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackGraveYard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackQueen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackKing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackBishop1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackKnight1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackBishop2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackKnight2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackRook1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackRook2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteQueen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteKing)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteBishop1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteBishop2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteKnight1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteKnight2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteRook1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteRook2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteGraveYard)).BeginInit();
            this.SuspendLayout();
            // 
            // chessBoard
            // 
            this.chessBoard.BackColor = System.Drawing.Color.White;
            this.chessBoard.Location = new System.Drawing.Point(62, 48);
            this.chessBoard.Name = "chessBoard";
            this.chessBoard.Size = new System.Drawing.Size(512, 512);
            this.chessBoard.TabIndex = 0;
            this.chessBoard.TabStop = false;
            this.chessBoard.Paint += new System.Windows.Forms.PaintEventHandler(this.chessBoard_Paint);
            this.chessBoard.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.chessBoard_MouseDoubleClick);
            // 
            // feedback_TextBox
            // 
            this.feedback_TextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.feedback_TextBox.Location = new System.Drawing.Point(62, 564);
            this.feedback_TextBox.Name = "feedback_TextBox";
            this.feedback_TextBox.ReadOnly = true;
            this.feedback_TextBox.Size = new System.Drawing.Size(512, 110);
            this.feedback_TextBox.TabIndex = 1;
            this.feedback_TextBox.Text = "";
            // 
            // Start_Button
            // 
            this.Start_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Start_Button.Location = new System.Drawing.Point(62, 12);
            this.Start_Button.Name = "Start_Button";
            this.Start_Button.Size = new System.Drawing.Size(75, 30);
            this.Start_Button.TabIndex = 2;
            this.Start_Button.Text = "Start";
            this.Start_Button.UseVisualStyleBackColor = true;
            this.Start_Button.Click += new System.EventHandler(this.Start_Button_Click);
            // 
            // surrender_Button
            // 
            this.surrender_Button.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.surrender_Button.Location = new System.Drawing.Point(143, 12);
            this.surrender_Button.Name = "surrender_Button";
            this.surrender_Button.Size = new System.Drawing.Size(88, 30);
            this.surrender_Button.TabIndex = 3;
            this.surrender_Button.Text = "Surrender";
            this.surrender_Button.UseVisualStyleBackColor = true;
            this.surrender_Button.Click += new System.EventHandler(this.surrender_Button_Click);
            // 
            // blackbutton
            // 
            this.blackbutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.blackbutton.Location = new System.Drawing.Point(499, 12);
            this.blackbutton.Name = "blackbutton";
            this.blackbutton.Size = new System.Drawing.Size(75, 30);
            this.blackbutton.TabIndex = 7;
            this.blackbutton.Text = "Black";
            this.blackbutton.UseVisualStyleBackColor = true;
            this.blackbutton.Click += new System.EventHandler(this.blackbutton_Click);
            // 
            // whitebutton
            // 
            this.whitebutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.whitebutton.Location = new System.Drawing.Point(418, 12);
            this.whitebutton.Name = "whitebutton";
            this.whitebutton.Size = new System.Drawing.Size(75, 30);
            this.whitebutton.TabIndex = 8;
            this.whitebutton.Text = "White";
            this.whitebutton.UseVisualStyleBackColor = true;
            this.whitebutton.Click += new System.EventHandler(this.whitebutton_Click);
            // 
            // randombutton
            // 
            this.randombutton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.randombutton.Location = new System.Drawing.Point(330, 12);
            this.randombutton.Name = "randombutton";
            this.randombutton.Size = new System.Drawing.Size(82, 30);
            this.randombutton.TabIndex = 9;
            this.randombutton.Text = "Random";
            this.randombutton.UseVisualStyleBackColor = true;
            this.randombutton.Click += new System.EventHandler(this.randombutton_Click);
            // 
            // blackGraveYard
            // 
            this.blackGraveYard.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.blackGraveYard.Location = new System.Drawing.Point(580, 28);
            this.blackGraveYard.Name = "blackGraveYard";
            this.blackGraveYard.Size = new System.Drawing.Size(192, 320);
            this.blackGraveYard.TabIndex = 10;
            this.blackGraveYard.TabStop = false;
            // 
            // blackQueen
            // 
            this.blackQueen.BackColor = System.Drawing.Color.Transparent;
            this.blackQueen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.blackQueen.Image = ((System.Drawing.Image)(resources.GetObject("blackQueen.Image")));
            this.blackQueen.Location = new System.Drawing.Point(258, 49);
            this.blackQueen.Name = "blackQueen";
            this.blackQueen.Size = new System.Drawing.Size(55, 58);
            this.blackQueen.TabIndex = 11;
            this.blackQueen.TabStop = false;
            this.blackQueen.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackQueen_MouseDown);
            this.blackQueen.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackQueen_MouseMove);
            this.blackQueen.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackQueen_MouseUp);
            // 
            // blackKing
            // 
            this.blackKing.BackColor = System.Drawing.Color.Transparent;
            this.blackKing.Image = ((System.Drawing.Image)(resources.GetObject("blackKing.Image")));
            this.blackKing.Location = new System.Drawing.Point(321, 48);
            this.blackKing.Name = "blackKing";
            this.blackKing.Size = new System.Drawing.Size(59, 61);
            this.blackKing.TabIndex = 12;
            this.blackKing.TabStop = false;
            this.blackKing.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackKing_MouseDown);
            this.blackKing.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackKing_MouseMove);
            this.blackKing.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackKing_MouseUp);
            // 
            // blackBishop1
            // 
            this.blackBishop1.BackColor = System.Drawing.Color.Transparent;
            this.blackBishop1.Image = ((System.Drawing.Image)(resources.GetObject("blackBishop1.Image")));
            this.blackBishop1.Location = new System.Drawing.Point(391, 48);
            this.blackBishop1.Name = "blackBishop1";
            this.blackBishop1.Size = new System.Drawing.Size(45, 62);
            this.blackBishop1.TabIndex = 13;
            this.blackBishop1.TabStop = false;
            this.blackBishop1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackBishop1_MouseDown);
            this.blackBishop1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackBishop1_MouseMove);
            this.blackBishop1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackBishop1_MouseUp);
            // 
            // blackKnight1
            // 
            this.blackKnight1.BackColor = System.Drawing.Color.Transparent;
            this.blackKnight1.Image = ((System.Drawing.Image)(resources.GetObject("blackKnight1.Image")));
            this.blackKnight1.Location = new System.Drawing.Point(149, 50);
            this.blackKnight1.Name = "blackKnight1";
            this.blackKnight1.Size = new System.Drawing.Size(52, 61);
            this.blackKnight1.TabIndex = 14;
            this.blackKnight1.TabStop = false;
            this.blackKnight1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackKnight1_MouseDown);
            this.blackKnight1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackKnight1_MouseMove);
            this.blackKnight1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackKnight1_MouseUp);
            // 
            // blackBishop2
            // 
            this.blackBishop2.BackColor = System.Drawing.Color.Transparent;
            this.blackBishop2.Image = ((System.Drawing.Image)(resources.GetObject("blackBishop2.Image")));
            this.blackBishop2.Location = new System.Drawing.Point(207, 49);
            this.blackBishop2.Name = "blackBishop2";
            this.blackBishop2.Size = new System.Drawing.Size(45, 62);
            this.blackBishop2.TabIndex = 15;
            this.blackBishop2.TabStop = false;
            this.blackBishop2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackBishop2_MouseDown);
            this.blackBishop2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackBishop2_MouseMove);
            this.blackBishop2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackBishop2_MouseUp);
            // 
            // blackKnight2
            // 
            this.blackKnight2.BackColor = System.Drawing.Color.Transparent;
            this.blackKnight2.Image = ((System.Drawing.Image)(resources.GetObject("blackKnight2.Image")));
            this.blackKnight2.Location = new System.Drawing.Point(442, 50);
            this.blackKnight2.Name = "blackKnight2";
            this.blackKnight2.Size = new System.Drawing.Size(52, 61);
            this.blackKnight2.TabIndex = 16;
            this.blackKnight2.TabStop = false;
            this.blackKnight2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackKnight2_MouseDown);
            this.blackKnight2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackKnight2_MouseMove);
            this.blackKnight2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackKnight2_MouseUp);
            // 
            // blackRook1
            // 
            this.blackRook1.BackColor = System.Drawing.Color.Transparent;
            this.blackRook1.Image = ((System.Drawing.Image)(resources.GetObject("blackRook1.Image")));
            this.blackRook1.Location = new System.Drawing.Point(84, 50);
            this.blackRook1.Name = "blackRook1";
            this.blackRook1.Size = new System.Drawing.Size(53, 64);
            this.blackRook1.TabIndex = 17;
            this.blackRook1.TabStop = false;
            this.blackRook1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackRook1_MouseDown);
            this.blackRook1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackRook1_MouseMove);
            this.blackRook1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackRook1_MouseUp);
            // 
            // blackRook2
            // 
            this.blackRook2.BackColor = System.Drawing.Color.Transparent;
            this.blackRook2.Image = ((System.Drawing.Image)(resources.GetObject("blackRook2.Image")));
            this.blackRook2.Location = new System.Drawing.Point(500, 50);
            this.blackRook2.Name = "blackRook2";
            this.blackRook2.Size = new System.Drawing.Size(53, 64);
            this.blackRook2.TabIndex = 18;
            this.blackRook2.TabStop = false;
            this.blackRook2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackRook2_MouseDown);
            this.blackRook2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackRook2_MouseMove);
            this.blackRook2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackRook2_MouseUp);
            // 
            // blackPawn1
            // 
            this.blackPawn1.BackColor = System.Drawing.Color.Transparent;
            this.blackPawn1.Image = ((System.Drawing.Image)(resources.GetObject("blackPawn1.Image")));
            this.blackPawn1.Location = new System.Drawing.Point(89, 120);
            this.blackPawn1.Name = "blackPawn1";
            this.blackPawn1.Size = new System.Drawing.Size(48, 62);
            this.blackPawn1.TabIndex = 19;
            this.blackPawn1.TabStop = false;
            this.blackPawn1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackPawn1_MouseDown);
            this.blackPawn1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackPawn1_MouseMove);
            this.blackPawn1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackPawn1_MouseUp);
            // 
            // blackPawn2
            // 
            this.blackPawn2.BackColor = System.Drawing.Color.Transparent;
            this.blackPawn2.Image = ((System.Drawing.Image)(resources.GetObject("blackPawn2.Image")));
            this.blackPawn2.Location = new System.Drawing.Point(149, 120);
            this.blackPawn2.Name = "blackPawn2";
            this.blackPawn2.Size = new System.Drawing.Size(48, 62);
            this.blackPawn2.TabIndex = 20;
            this.blackPawn2.TabStop = false;
            this.blackPawn2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackPawn2_MouseDown);
            this.blackPawn2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackPawn2_MouseMove);
            this.blackPawn2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackPawn2_MouseUp);
            // 
            // blackPawn3
            // 
            this.blackPawn3.BackColor = System.Drawing.Color.Transparent;
            this.blackPawn3.Image = ((System.Drawing.Image)(resources.GetObject("blackPawn3.Image")));
            this.blackPawn3.Location = new System.Drawing.Point(207, 120);
            this.blackPawn3.Name = "blackPawn3";
            this.blackPawn3.Size = new System.Drawing.Size(48, 62);
            this.blackPawn3.TabIndex = 21;
            this.blackPawn3.TabStop = false;
            this.blackPawn3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackPawn3_MouseDown);
            this.blackPawn3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackPawn3_MouseMove);
            this.blackPawn3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackPawn3_MouseUp);
            // 
            // blackPawn4
            // 
            this.blackPawn4.BackColor = System.Drawing.Color.Transparent;
            this.blackPawn4.Image = ((System.Drawing.Image)(resources.GetObject("blackPawn4.Image")));
            this.blackPawn4.Location = new System.Drawing.Point(265, 120);
            this.blackPawn4.Name = "blackPawn4";
            this.blackPawn4.Size = new System.Drawing.Size(48, 62);
            this.blackPawn4.TabIndex = 22;
            this.blackPawn4.TabStop = false;
            this.blackPawn4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackPawn4_MouseDown);
            this.blackPawn4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackPawn4_MouseMove);
            this.blackPawn4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackPawn4_MouseUp);
            // 
            // blackPawn5
            // 
            this.blackPawn5.BackColor = System.Drawing.Color.Transparent;
            this.blackPawn5.Image = ((System.Drawing.Image)(resources.GetObject("blackPawn5.Image")));
            this.blackPawn5.Location = new System.Drawing.Point(330, 120);
            this.blackPawn5.Name = "blackPawn5";
            this.blackPawn5.Size = new System.Drawing.Size(48, 62);
            this.blackPawn5.TabIndex = 23;
            this.blackPawn5.TabStop = false;
            this.blackPawn5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackPawn5_MouseDown);
            this.blackPawn5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackPawn5_MouseMove);
            this.blackPawn5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackPawn5_MouseUp);
            // 
            // blackPawn6
            // 
            this.blackPawn6.BackColor = System.Drawing.Color.Transparent;
            this.blackPawn6.Image = ((System.Drawing.Image)(resources.GetObject("blackPawn6.Image")));
            this.blackPawn6.Location = new System.Drawing.Point(388, 120);
            this.blackPawn6.Name = "blackPawn6";
            this.blackPawn6.Size = new System.Drawing.Size(48, 62);
            this.blackPawn6.TabIndex = 24;
            this.blackPawn6.TabStop = false;
            this.blackPawn6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackPawn6_MouseDown);
            this.blackPawn6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackPawn6_MouseMove);
            this.blackPawn6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackPawn6_MouseUp);
            // 
            // blackPawn7
            // 
            this.blackPawn7.BackColor = System.Drawing.Color.Transparent;
            this.blackPawn7.Image = ((System.Drawing.Image)(resources.GetObject("blackPawn7.Image")));
            this.blackPawn7.Location = new System.Drawing.Point(445, 120);
            this.blackPawn7.Name = "blackPawn7";
            this.blackPawn7.Size = new System.Drawing.Size(48, 62);
            this.blackPawn7.TabIndex = 25;
            this.blackPawn7.TabStop = false;
            this.blackPawn7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackPawn7_MouseDown);
            this.blackPawn7.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackPawn7_MouseMove);
            this.blackPawn7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackPawn7_MouseUp);
            // 
            // blackPawn8
            // 
            this.blackPawn8.BackColor = System.Drawing.Color.Transparent;
            this.blackPawn8.Image = ((System.Drawing.Image)(resources.GetObject("blackPawn8.Image")));
            this.blackPawn8.Location = new System.Drawing.Point(500, 120);
            this.blackPawn8.Name = "blackPawn8";
            this.blackPawn8.Size = new System.Drawing.Size(48, 62);
            this.blackPawn8.TabIndex = 26;
            this.blackPawn8.TabStop = false;
            this.blackPawn8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.blackPawn8_MouseDown);
            this.blackPawn8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.blackPawn8_MouseMove);
            this.blackPawn8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.blackPawn8_MouseUp);
            // 
            // whiteQueen
            // 
            this.whiteQueen.BackColor = System.Drawing.Color.Transparent;
            this.whiteQueen.Image = ((System.Drawing.Image)(resources.GetObject("whiteQueen.Image")));
            this.whiteQueen.Location = new System.Drawing.Point(252, 495);
            this.whiteQueen.Name = "whiteQueen";
            this.whiteQueen.Size = new System.Drawing.Size(61, 62);
            this.whiteQueen.TabIndex = 27;
            this.whiteQueen.TabStop = false;
            this.whiteQueen.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whiteQueen_MouseDown);
            this.whiteQueen.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whiteQueen_MouseMove);
            this.whiteQueen.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whiteQueen_MouseUp);
            // 
            // whiteKing
            // 
            this.whiteKing.Image = ((System.Drawing.Image)(resources.GetObject("whiteKing.Image")));
            this.whiteKing.Location = new System.Drawing.Point(321, 497);
            this.whiteKing.Name = "whiteKing";
            this.whiteKing.Size = new System.Drawing.Size(62, 61);
            this.whiteKing.TabIndex = 28;
            this.whiteKing.TabStop = false;
            this.whiteKing.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whiteKing_MouseDown);
            this.whiteKing.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whiteKing_MouseMove);
            this.whiteKing.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whiteKing_MouseUp);
            // 
            // whiteBishop1
            // 
            this.whiteBishop1.BackColor = System.Drawing.Color.Transparent;
            this.whiteBishop1.Image = ((System.Drawing.Image)(resources.GetObject("whiteBishop1.Image")));
            this.whiteBishop1.Location = new System.Drawing.Point(391, 496);
            this.whiteBishop1.Name = "whiteBishop1";
            this.whiteBishop1.Size = new System.Drawing.Size(50, 62);
            this.whiteBishop1.TabIndex = 29;
            this.whiteBishop1.TabStop = false;
            this.whiteBishop1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whiteBishop1_MouseDown);
            this.whiteBishop1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whiteBishop1_MouseMove);
            this.whiteBishop1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whiteBishop1_MouseUp);
            // 
            // whiteBishop2
            // 
            this.whiteBishop2.BackColor = System.Drawing.Color.Transparent;
            this.whiteBishop2.Image = ((System.Drawing.Image)(resources.GetObject("whiteBishop2.Image")));
            this.whiteBishop2.Location = new System.Drawing.Point(194, 495);
            this.whiteBishop2.Name = "whiteBishop2";
            this.whiteBishop2.Size = new System.Drawing.Size(50, 62);
            this.whiteBishop2.TabIndex = 30;
            this.whiteBishop2.TabStop = false;
            this.whiteBishop2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whiteBishop2_MouseDown);
            this.whiteBishop2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whiteBishop2_MouseMove);
            this.whiteBishop2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whiteBishop2_MouseUp);
            // 
            // whiteKnight1
            // 
            this.whiteKnight1.BackColor = System.Drawing.Color.Transparent;
            this.whiteKnight1.Image = ((System.Drawing.Image)(resources.GetObject("whiteKnight1.Image")));
            this.whiteKnight1.Location = new System.Drawing.Point(134, 495);
            this.whiteKnight1.Name = "whiteKnight1";
            this.whiteKnight1.Size = new System.Drawing.Size(54, 62);
            this.whiteKnight1.TabIndex = 31;
            this.whiteKnight1.TabStop = false;
            this.whiteKnight1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whiteKnight1_MouseDown);
            this.whiteKnight1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whiteKnight1_MouseMove);
            this.whiteKnight1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whiteKnight1_MouseUp);
            // 
            // whiteKnight2
            // 
            this.whiteKnight2.BackColor = System.Drawing.Color.Transparent;
            this.whiteKnight2.Image = ((System.Drawing.Image)(resources.GetObject("whiteKnight2.Image")));
            this.whiteKnight2.Location = new System.Drawing.Point(447, 496);
            this.whiteKnight2.Name = "whiteKnight2";
            this.whiteKnight2.Size = new System.Drawing.Size(54, 62);
            this.whiteKnight2.TabIndex = 32;
            this.whiteKnight2.TabStop = false;
            this.whiteKnight2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whiteKnight2_MouseDown);
            this.whiteKnight2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whiteKnight2_MouseMove);
            this.whiteKnight2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whiteKnight2_MouseUp);
            // 
            // whiteRook1
            // 
            this.whiteRook1.BackColor = System.Drawing.Color.Transparent;
            this.whiteRook1.Image = ((System.Drawing.Image)(resources.GetObject("whiteRook1.Image")));
            this.whiteRook1.Location = new System.Drawing.Point(75, 495);
            this.whiteRook1.Name = "whiteRook1";
            this.whiteRook1.Size = new System.Drawing.Size(53, 62);
            this.whiteRook1.TabIndex = 33;
            this.whiteRook1.TabStop = false;
            this.whiteRook1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whiteRook1_MouseDown);
            this.whiteRook1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whiteRook1_MouseMove);
            this.whiteRook1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whiteRook1_MouseUp);
            // 
            // whiteRook2
            // 
            this.whiteRook2.BackColor = System.Drawing.Color.Transparent;
            this.whiteRook2.Image = ((System.Drawing.Image)(resources.GetObject("whiteRook2.Image")));
            this.whiteRook2.Location = new System.Drawing.Point(507, 496);
            this.whiteRook2.Name = "whiteRook2";
            this.whiteRook2.Size = new System.Drawing.Size(53, 62);
            this.whiteRook2.TabIndex = 34;
            this.whiteRook2.TabStop = false;
            this.whiteRook2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whiteRook2_MouseDown);
            this.whiteRook2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whiteRook2_MouseMove);
            this.whiteRook2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whiteRook2_MouseUp);
            // 
            // whitePawn1
            // 
            this.whitePawn1.BackColor = System.Drawing.Color.Transparent;
            this.whitePawn1.Image = ((System.Drawing.Image)(resources.GetObject("whitePawn1.Image")));
            this.whitePawn1.Location = new System.Drawing.Point(508, 428);
            this.whitePawn1.Name = "whitePawn1";
            this.whitePawn1.Size = new System.Drawing.Size(52, 62);
            this.whitePawn1.TabIndex = 35;
            this.whitePawn1.TabStop = false;
            this.whitePawn1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whitePawn1_MouseDown);
            this.whitePawn1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whitePawn1_MouseMove);
            this.whitePawn1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whitePawn1_MouseUp);
            // 
            // whitePawn2
            // 
            this.whitePawn2.BackColor = System.Drawing.Color.Transparent;
            this.whitePawn2.Image = ((System.Drawing.Image)(resources.GetObject("whitePawn2.Image")));
            this.whitePawn2.Location = new System.Drawing.Point(450, 428);
            this.whitePawn2.Name = "whitePawn2";
            this.whitePawn2.Size = new System.Drawing.Size(52, 62);
            this.whitePawn2.TabIndex = 36;
            this.whitePawn2.TabStop = false;
            this.whitePawn2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whitePawn2_MouseDown);
            this.whitePawn2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whitePawn2_MouseMove);
            this.whitePawn2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whitePawn2_MouseUp);
            // 
            // whitePawn3
            // 
            this.whitePawn3.BackColor = System.Drawing.Color.Transparent;
            this.whitePawn3.Image = ((System.Drawing.Image)(resources.GetObject("whitePawn3.Image")));
            this.whitePawn3.Location = new System.Drawing.Point(392, 428);
            this.whitePawn3.Name = "whitePawn3";
            this.whitePawn3.Size = new System.Drawing.Size(52, 62);
            this.whitePawn3.TabIndex = 37;
            this.whitePawn3.TabStop = false;
            this.whitePawn3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whitePawn3_MouseDown);
            this.whitePawn3.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whitePawn3_MouseMove);
            this.whitePawn3.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whitePawn3_MouseUp);
            // 
            // whitePawn4
            // 
            this.whitePawn4.BackColor = System.Drawing.Color.Transparent;
            this.whitePawn4.Image = ((System.Drawing.Image)(resources.GetObject("whitePawn4.Image")));
            this.whitePawn4.Location = new System.Drawing.Point(326, 428);
            this.whitePawn4.Name = "whitePawn4";
            this.whitePawn4.Size = new System.Drawing.Size(52, 62);
            this.whitePawn4.TabIndex = 38;
            this.whitePawn4.TabStop = false;
            this.whitePawn4.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whitePawn4_MouseDown);
            this.whitePawn4.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whitePawn4_MouseMove);
            this.whitePawn4.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whitePawn4_MouseUp);
            // 
            // whitePawn5
            // 
            this.whitePawn5.BackColor = System.Drawing.Color.Transparent;
            this.whitePawn5.Image = ((System.Drawing.Image)(resources.GetObject("whitePawn5.Image")));
            this.whitePawn5.Location = new System.Drawing.Point(258, 427);
            this.whitePawn5.Name = "whitePawn5";
            this.whitePawn5.Size = new System.Drawing.Size(52, 62);
            this.whitePawn5.TabIndex = 39;
            this.whitePawn5.TabStop = false;
            this.whitePawn5.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whitePawn5_MouseDown);
            this.whitePawn5.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whitePawn5_MouseMove);
            this.whitePawn5.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whitePawn5_MouseUp);
            // 
            // whitePawn6
            // 
            this.whitePawn6.BackColor = System.Drawing.Color.Transparent;
            this.whitePawn6.Image = ((System.Drawing.Image)(resources.GetObject("whitePawn6.Image")));
            this.whitePawn6.Location = new System.Drawing.Point(194, 427);
            this.whitePawn6.Name = "whitePawn6";
            this.whitePawn6.Size = new System.Drawing.Size(52, 62);
            this.whitePawn6.TabIndex = 40;
            this.whitePawn6.TabStop = false;
            this.whitePawn6.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whitePawn6_MouseDown);
            this.whitePawn6.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whitePawn6_MouseMove);
            this.whitePawn6.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whitePawn6_MouseUp);
            // 
            // whitePawn7
            // 
            this.whitePawn7.BackColor = System.Drawing.Color.Transparent;
            this.whitePawn7.Image = ((System.Drawing.Image)(resources.GetObject("whitePawn7.Image")));
            this.whitePawn7.Location = new System.Drawing.Point(136, 427);
            this.whitePawn7.Name = "whitePawn7";
            this.whitePawn7.Size = new System.Drawing.Size(52, 62);
            this.whitePawn7.TabIndex = 41;
            this.whitePawn7.TabStop = false;
            this.whitePawn7.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whitePawn7_MouseDown);
            this.whitePawn7.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whitePawn7_MouseMove);
            this.whitePawn7.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whitePawn7_MouseUp);
            // 
            // whitePawn8
            // 
            this.whitePawn8.BackColor = System.Drawing.Color.Transparent;
            this.whitePawn8.Image = ((System.Drawing.Image)(resources.GetObject("whitePawn8.Image")));
            this.whitePawn8.Location = new System.Drawing.Point(76, 427);
            this.whitePawn8.Name = "whitePawn8";
            this.whitePawn8.Size = new System.Drawing.Size(52, 62);
            this.whitePawn8.TabIndex = 42;
            this.whitePawn8.TabStop = false;
            this.whitePawn8.MouseDown += new System.Windows.Forms.MouseEventHandler(this.whitePawn8_MouseDown);
            this.whitePawn8.MouseMove += new System.Windows.Forms.MouseEventHandler(this.whitePawn8_MouseMove);
            this.whitePawn8.MouseUp += new System.Windows.Forms.MouseEventHandler(this.whitePawn8_MouseUp);
            // 
            // whiteGraveYard
            // 
            this.whiteGraveYard.BackColor = System.Drawing.Color.DarkGray;
            this.whiteGraveYard.Location = new System.Drawing.Point(580, 354);
            this.whiteGraveYard.Name = "whiteGraveYard";
            this.whiteGraveYard.Size = new System.Drawing.Size(192, 320);
            this.whiteGraveYard.TabIndex = 43;
            this.whiteGraveYard.TabStop = false;
            // 
            // blackTurn
            // 
            this.blackTurn.AutoSize = true;
            this.blackTurn.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.blackTurn.Location = new System.Drawing.Point(9, 72);
            this.blackTurn.Name = "blackTurn";
            this.blackTurn.Size = new System.Drawing.Size(44, 42);
            this.blackTurn.TabIndex = 44;
            this.blackTurn.Text = "B";
            // 
            // whiteTurn
            // 
            this.whiteTurn.AutoSize = true;
            this.whiteTurn.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.whiteTurn.ForeColor = System.Drawing.Color.White;
            this.whiteTurn.Location = new System.Drawing.Point(2, 495);
            this.whiteTurn.Name = "whiteTurn";
            this.whiteTurn.Size = new System.Drawing.Size(54, 42);
            this.whiteTurn.TabIndex = 45;
            this.whiteTurn.Text = "W";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.BurlyWood;
            this.ClientSize = new System.Drawing.Size(796, 690);
            this.Controls.Add(this.whiteTurn);
            this.Controls.Add(this.blackTurn);
            this.Controls.Add(this.whiteGraveYard);
            this.Controls.Add(this.whitePawn8);
            this.Controls.Add(this.whitePawn7);
            this.Controls.Add(this.whitePawn6);
            this.Controls.Add(this.whitePawn5);
            this.Controls.Add(this.whitePawn4);
            this.Controls.Add(this.whitePawn3);
            this.Controls.Add(this.whitePawn2);
            this.Controls.Add(this.whitePawn1);
            this.Controls.Add(this.whiteRook2);
            this.Controls.Add(this.whiteRook1);
            this.Controls.Add(this.whiteKnight2);
            this.Controls.Add(this.whiteKnight1);
            this.Controls.Add(this.whiteBishop2);
            this.Controls.Add(this.whiteBishop1);
            this.Controls.Add(this.whiteKing);
            this.Controls.Add(this.whiteQueen);
            this.Controls.Add(this.blackPawn8);
            this.Controls.Add(this.blackPawn7);
            this.Controls.Add(this.blackPawn6);
            this.Controls.Add(this.blackPawn5);
            this.Controls.Add(this.blackPawn4);
            this.Controls.Add(this.blackPawn3);
            this.Controls.Add(this.blackPawn2);
            this.Controls.Add(this.blackPawn1);
            this.Controls.Add(this.blackRook2);
            this.Controls.Add(this.blackRook1);
            this.Controls.Add(this.blackKnight2);
            this.Controls.Add(this.blackBishop2);
            this.Controls.Add(this.blackKnight1);
            this.Controls.Add(this.blackBishop1);
            this.Controls.Add(this.blackKing);
            this.Controls.Add(this.blackQueen);
            this.Controls.Add(this.blackGraveYard);
            this.Controls.Add(this.randombutton);
            this.Controls.Add(this.whitebutton);
            this.Controls.Add(this.blackbutton);
            this.Controls.Add(this.surrender_Button);
            this.Controls.Add(this.Start_Button);
            this.Controls.Add(this.feedback_TextBox);
            this.Controls.Add(this.chessBoard);
            this.Name = "Form1";
            this.Text = "Super Awesome Chess Game!";
            ((System.ComponentModel.ISupportInitialize)(this.chessBoard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackGraveYard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackQueen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackKing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackBishop1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackKnight1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackBishop2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackKnight2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackRook1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackRook2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blackPawn8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteQueen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteKing)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteBishop1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteBishop2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteKnight1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteKnight2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteRook1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteRook2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whitePawn8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.whiteGraveYard)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox chessBoard;
        private System.Windows.Forms.RichTextBox feedback_TextBox;
        private System.Windows.Forms.Button Start_Button;
        private System.Windows.Forms.Button surrender_Button;
        private System.Windows.Forms.Button blackbutton;
        private System.Windows.Forms.Button whitebutton;
        private System.Windows.Forms.Button randombutton;
        private System.Windows.Forms.PictureBox blackGraveYard;
        private System.Windows.Forms.PictureBox blackQueen;
        private System.Windows.Forms.PictureBox blackKing;
        private System.Windows.Forms.PictureBox blackBishop1;
        private System.Windows.Forms.PictureBox blackKnight1;
        private System.Windows.Forms.PictureBox blackBishop2;
        private System.Windows.Forms.PictureBox blackKnight2;
        private System.Windows.Forms.PictureBox blackRook1;
        private System.Windows.Forms.PictureBox blackRook2;
        private System.Windows.Forms.PictureBox blackPawn1;
        private System.Windows.Forms.PictureBox blackPawn2;
        private System.Windows.Forms.PictureBox blackPawn3;
        private System.Windows.Forms.PictureBox blackPawn4;
        private System.Windows.Forms.PictureBox blackPawn5;
        private System.Windows.Forms.PictureBox blackPawn6;
        private System.Windows.Forms.PictureBox blackPawn7;
        private System.Windows.Forms.PictureBox blackPawn8;
        private System.Windows.Forms.PictureBox whiteQueen;
        private System.Windows.Forms.PictureBox whiteKing;
        private System.Windows.Forms.PictureBox whiteBishop1;
        private System.Windows.Forms.PictureBox whiteBishop2;
        private System.Windows.Forms.PictureBox whiteKnight1;
        private System.Windows.Forms.PictureBox whiteKnight2;
        private System.Windows.Forms.PictureBox whiteRook1;
        private System.Windows.Forms.PictureBox whiteRook2;
        private System.Windows.Forms.PictureBox whitePawn1;
        private System.Windows.Forms.PictureBox whitePawn2;
        private System.Windows.Forms.PictureBox whitePawn3;
        private System.Windows.Forms.PictureBox whitePawn4;
        private System.Windows.Forms.PictureBox whitePawn5;
        private System.Windows.Forms.PictureBox whitePawn6;
        private System.Windows.Forms.PictureBox whitePawn7;
        private System.Windows.Forms.PictureBox whitePawn8;
        private System.Windows.Forms.PictureBox whiteGraveYard;
        private System.Windows.Forms.Label blackTurn;
        private System.Windows.Forms.Label whiteTurn;
    }
}

