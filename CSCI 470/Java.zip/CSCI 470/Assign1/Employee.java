/***************************************************************
CSCI 470		Assignment 2		   9/6/2020
Name: Alyssa Smith

Program: Basic OOP program with constructors and get and set methods

Due Date: September 6, 2020
***************************************************************/

class Employee{

  private String firstName, lastName;
  private double monthlySalary;

  public Employee(String infirstName, String inlastName, double inmonthlySalary)	//Constructor
      {
	 this.firstName = infirstName;
	 this.lastName = inlastName;
	 if(inmonthlySalary<0)	//if neg value coming in, set Salary to 0 in object
	  {
	    this.monthlySalary = 0;
	  }

	 else	//copy Salary coming in, into Employee object
	  {
	    this.monthlySalary = inmonthlySalary;
	  }
      }

  public void setfirstName(String infirstName)	//set method for Employee's first name
      {
	 this.firstName=infirstName;
      }

  public String getfirstName()	//get method for Employee's first name
      {
         return firstName;
      }

  public void setlastName(String inlastName)	//set method for Emplyee's last name
      {
	 this.lastName=inlastName;
      }

  public String getlastName()	//get method for Employee's last name
      {
	 return lastName;
      }

  public void setmonthlySalary(double inmonthlySalary)		//set method for the Employee's monthly salary
      {
	 if(monthlySalary<0)	//if neg value coming in, set Salary to 0 in object
	  {
	    this.monthlySalary=0;
	  }

	 else	//copy Salary coming in, into Employee object
	  {
	    this.monthlySalary=inmonthlySalary;
	  }
      }

  public double getmonthlySalary()	//get copy of Salary out of object
      {
	 return monthlySalary;
      }

};//end of Employee class

