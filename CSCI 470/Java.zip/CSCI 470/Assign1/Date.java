/***************************************************************
CSCI 470                Assignment 2               9/6/2020
Name: Alyssa Smith

Program: Basic OOP program with constructors and get and set methods

Due Date: September 6, 2020
***************************************************************/

class Date {

  int month, day, year;

  Date(int inMonth, int inDay, int inYear)     //Constructor
     {
	this.month=inMonth;
	this.day=inDay;
	this.year=inYear;
     }

  void setMonth(int inMonth)	//set method for Month
     {
	this.month=inMonth;
     }

  int getMonth()		//get method for Month
     {
 	return month;
     }

  void setDay(int inDay)		//set method for Day
     {
	this.day=inDay;
     }

  int getDay()		//get method for Day
     {
	return day;
     }

  void setYear(int inYear)	//set mthod for year
     {
	this.year=inYear;
     }

  int getYear()		//get method for year
     {
	return year;
     }

  void displayDate()	//method to display date
     {
	System.out.println("\nDate: "+month+"/"+day+"/"+year+"\n");
     }

};  //End of program
