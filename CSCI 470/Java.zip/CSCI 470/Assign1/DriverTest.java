/***************************************************************
CSCI 470                Assignment 2               9/6/2020
Name: Alyssa Smith

Program: Basic OOP program with constructors and get and set methods

Due Date: September 6, 2020
***************************************************************/

class DriverTest {

  public static void main(String[] args)
      {

	 Employee emp1 = new Employee("Alyssa","Smith",2000.00);	//call constructor

		 emp1.setmonthlySalary(emp1.getmonthlySalary()*12);	//get copy of monthly salary out of Employee object

		 System.out.printf("\nEmployee 1 has a yearly salary of: %.2f \n",emp1.getmonthlySalary());	//Print out yearly salary

	Employee emp2 = new Employee("Joe","Smith",3000.00);	//call constructor

		 emp2.setmonthlySalary(emp2.getmonthlySalary()*12);	//get copy of monthly salary out of Employee object

		 System.out.printf("Employee 2 has a yearly salary of: %.2f \n",emp2.getmonthlySalary());	//Print out yearly salary

	//10% raise
	emp1.setmonthlySalary(emp1.getmonthlySalary()*1.10);

	System.out.printf("\nEmployee 1 has a new yearly salary of: %.2f \n",emp1.getmonthlySalary()); 	//Print out yearly salary with 10% raise

	emp2.setmonthlySalary(emp2.getmonthlySalary()*1.10);

        System.out.printf("Employee 1 has a new yearly salary of: %.2f \n",emp2.getmonthlySalary());


	Date dt1 = new Date(9,6,2020);	//call constructor

		int month=dt1.getMonth();  //get copy of Month out of Date object
		int day=dt1.getDay();	//get copy of Day out of Date object
		int year=dt1.getYear();	//get copy of Year out of Date object

	System.out.println("\nMonth: "+dt1.getMonth());
	System.out.println("Day: "+dt1.getDay());
	System.out.println("Year: "+dt1.getYear());

	dt1.displayDate();	//Display Date with "/" in between
    }
};  //End of program
