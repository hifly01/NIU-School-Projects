/***************************************************************
CSCI 470

Programmer: Alyssa Smith

Due Date: September 16, 2020

Now we will define a driver program below called TestLine with
main() where execution will begin. It is this class, and this code,
 that will create instances of the Line and call its methods. As a
test module, this code would be improved with additional
System.out.println() statements that explain what is being attempted
 and what the results should be, for example: "About to change l1 to
 an invalid value and then redraw it. Line position
should not change: "*/
//*********************************************************

class TestLine
{

public static void main(String args[])
{

Line l1 = null, l2 = null;
//declare 2 instances of Line class
//create 1 Line object
//Add a try/catch
try
 {
  l1 = new Line (10, 10, 100, 100);
 }
catch(Exception e)
 {
  System.out.println("--EXCEPTION: MY TRY CATCH CAUGHT A GENERIC EXCEPTION IN A SET METHOD FOR BAD VALUE OF X1 FOR AN EXISTING LINE");
 }
//draw it
l1.draw();
//change start point with valid values
//Add a try/catch
try
 {
  l1.setLine(5, 5, l1.getXTwo(), l1.getYTwo());
 }
catch(Exception e)
 {
  System.out.println("--EXCEPTION: MY TRY CATCH CAUGHT A GENERIC EXCEPTION IN A SET METHOD FOR BAD VALUE OF X1 FOR AN EXISTING LINE");
 }
//draw it again with new start point
l1.draw();
//try to change xOne (x1) to an illegal value
//Add a try/catch
try
 {
  l1.setXOne(3000);
 }
catch(Exception e)
 {
  System.out.println("--EXCEPTION: MY TRY CATCH CAUGHT A GENERIC EXCEPTION IN A SET METHOD FOR BAD VALUE OF X1 FOR AN EXISTING LINE\n");
  System.out.println("   java.lang.Exception: Value 3000 Was out of Bounds\n");
 }
//draw the line...x1 should now be zero
l1.draw();
//create a second Line instance, or object
//Add a try/catch
try
 {
  l2 = new Line(100, 100, 400, 400);
 }
catch(Exception e)
 {
  System.out.println("--EXCEPTION: MY TRY CATCH CAUGHT A GENERIC EXCEPTION IN A SET METHOD FOR BAD VALUE OF X1 FOR AN EXISTING LINE");
 }
//draw 2nd line
l2.draw();
//set a new valid yTwo for line 2
//Add a try/catch
try
 {
  l2.setYTwo(479);
 }
catch(Exception e)
 {
  System.out.println("--EXCEPTION: MY TRY CATCH CAUGHT A GENERIC EXCEPTION IN A SET METHOD FOR BAD VALUE OF X1 FOR AN EXISTING LINE");
 }
//draw 2nd line again
l2.draw();

//Print angle for line 1 and 2
System.out.println("The angle of line 1 is "+l1.getAngle());
System.out.println("The angle of line 2 is "+l2.getAngle()+"\n");
//Print lengths for line 1 and 2
System.out.println("The length of line 1 is "+l1.getLength());
System.out.println("The length of line 2 is "+l2.getLength()+"\n");

//Creeate new coordinates
TwoDPoint TD1 = new TwoDPoint(10,100);
TwoDPoint TD2 = new TwoDPoint(5,400);
//Make a new Line
//Add a try/catch
try
 {
  Line l3 = new Line(TD1, TD2);
//Test the constructors
  System.out.println("test 2D point Constructor X1 = "+l3.getXOne()+"\n");
  System.out.println("test 2D point Constructor X2 = "+l3.getXTwo()+"\n");
  System.out.println("test 2D point Constructor Y1 = "+l3.getYOne()+"\n");
  System.out.println("test 2D point Constructor Y2 = "+l3.getYTwo()+"\n");
 }
catch(Exception e)
 {
  System.out.println("--EXCEPTION: MY TRY CATCH CAUGHT A GENERIC EXCEPTION IN A SET METHOD FOR BAD VALUE OF X1 FOR AN EXISTING LINE");
 }

//Create a new Line with invalid constructor value
//Add a try/catch
try
 {
new Line(100,100,100,700);
 }
catch(Exception e)
 {
  System.out.println("EXCEPTION:This try catch caught a Generic Exception for a bad constructor -Failed to create a line with 4 invalid values-leaving with rc of 88\n");
  System.out.println("Java Result: 88");
  System.exit(88);
 }

} // end of main\
}  // end class TestLine

