/*****************************

CSCI 470

Programmer: Alyssa Smith

Due Date: September 16, 2020

*****************************/

public class TwoDPoint
{
  //2 public data menbers called x and y
  public int x, y;

  //Constructor that accepts two integer arguments and stores them in x and y
  public TwoDPoint(int x, int y)
    {
      this.x = x;
      this.y = y;
    }

}//end of class
