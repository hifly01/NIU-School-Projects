package smithpack;

/*****************************************************************
CSCI 470                Assignment 5

Programmer: Alyssa Smith

Due Date: November 15, 2020

Assignment: Grid Tiles

Notes: Create a frame that has a MainPanel that consists of 3 subpanels
*****************************************************************/
import java.awt.BorderLayout;
import javax.swing.JFrame;

public class GraphicsFrame extends JFrame
 {	
   public GraphicsFrame() 	//constructor
    {
	   super();
	  MainPanel mainPanelPtr = new MainPanel();//create mainpanel that overwrites the frame
	  this.add(mainPanelPtr, BorderLayout.CENTER);//main panel covers entire frame
	}
		
   public static void main(String[] args) 
    {
	   createAndShowGUI();	//call createAndShowGUI
    }

   private static void createAndShowGUI() 
    {
	   //Frame initialization
	   GraphicsFrame frame = new GraphicsFrame();	//create the master frame
	  frame.setSize(700,450);	//set the size of the frame
			
	  frame.setVisible(true);
    }
 }
