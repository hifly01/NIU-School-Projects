package smithpack;

import java.awt.BasicStroke;
import java.awt.Color;
/*****************************************************************
CSCI 470                Assignment 5

Programmer: Alyssa Smith

Due Date: November 15, 2020

Assignment: Grid Tiles

Notes: Create a frame that has a MainPanel that consists of 3 subpanels
*****************************************************************/
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.swing.JPanel;

class TileGridPanel extends JPanel implements MouseListener
 {
   int selectedTile = -1; //this is set to 0-4 when user clicks on a button in toolbar

   static final int squareSide = 25; 	//set the square size
   int GridRow = 5;		//set the grid row to 5
   int GridCol = 5;		//set grid column to 5

   Image[][] gif2dArray = new Image[GridRow][GridCol]; //we take gifs in here and draw in tilegrid

   ArrayList<Point> drawingPointsAL = new ArrayList<Point>();
   
   //Call mouse listener
   public TileGridPanel()
    {
 	  CreateMouseListener();	//create mouse listener
    }
   
   //reset method
   public void ResetGridTile()
    { 
	  for(int row = 0; row < GridRow; row++) 
	   {
		 for(int col = 0; col < GridCol; col++) 
		  {
		    gif2dArray[row][col] = null; //setting all to null
	 	  }
	   }
	 
	 drawingPointsAL.clear();   //clear out arraylist of point size 0
	 this.repaint(); //draw empty grid
    }
   
   public void CreateMouseListener()	//Adds mouse listener to Center panel
    { 
	  addMouseListener(this);	//add mouse method
    }

   @Override
   public void mouseClicked(MouseEvent arg0) //user has clicked a tile on panel, now has clicked in the center panel
    {			  
	  Point points = new Point(arg0.getX(), arg0.getY());	//get X and Y where you clicked 
	  drawingPointsAL.add(points);	//add x and y points objects to arraylist
		 
      if(selectedTile == -1) 	//when 0 -4 is clicked
	   {
		 System.out.println("Please select any on the top");	//message prints
	   }
     
	  else 
	   {
		 for(int row = 0; row < GridRow; row++) 	//loop to fill the gif2darray with the selected image
		  {
		    for(int col = 0; col < GridCol; col++) 
			 {
			   gif2dArray[row][col] = MainPanel.imageA[selectedTile]; 	//fill in selected image
			 }
       }
		
	  this.repaint();		//show new grid with your images from 2d array
	}
     }
   
   @Override
   public void mouseEntered(MouseEvent arg0) {	//when mouse enters
   	// TODO Auto-generated method stub
   	
   }

   @Override
   public void mouseExited(MouseEvent arg0) {	//when mouse exits
   	// TODO Auto-generated method stub
   	
   }

   @Override
   public void mousePressed(MouseEvent arg0) {	//when mouse is pressed
   	// TODO Auto-generated method stub
   	
   }

   @Override
   public void mouseReleased(MouseEvent arg0) {	//when mouse is released
   	// TODO Auto-generated method stub
   	
   }
   
   @Override
   public void paintComponent(Graphics g)	//paints the center panel with elements in 2darray
    { 
	  super.paintComponent(g);
      int gridWidth = GridCol*squareSide;  //need to find center area of the center panel
      int gridHeight = GridRow*squareSide;
      int panelWidth = getWidth();		//get the width
      int panelHeight = getHeight();	//get the height
      int startX = (panelWidth-gridWidth)/2;	//get starting point to draw grid based width
      int startY = (panelHeight-gridHeight)/2;	//get Y starting point to draw grid based height
  
      g.setColor(Color.BLUE);	//set pen to blue
      Graphics2D g2 = (Graphics2D) g;	//get larger paint brush 
      g2.setStroke(new BasicStroke(16));
      
      boolean firstPoint = true;	//flag set to true
      int saveX1 = 0, saveY1 = 0;	//saveX1 and saveY1 are initially set to zero
      
      for(Point userPoint : drawingPointsAL)
       {
    	 if(firstPoint)
    	  {
    	    firstPoint = false;	//set flag to false
    	    saveX1 = userPoint.x;	//save the the first x of user
    	    saveY1 = userPoint.y;	//save the first y of the user
    	  }
    	
    	else
    	 {
    	   g2.drawLine(saveX1, saveY1, userPoint.x, userPoint.y);	//draw line to next point
    	  
    	   saveX1 = userPoint.x;	//new saved point
    	   saveY1 = userPoint.y;	//new saved point
    	 }
       }
      
      for(int row = 0; row < GridRow; row++) //loop through to get row
	   {
  	     for(int col = 0; col < GridCol; col++) //loop through to get column
		  {
  	    	//copy gif image array over to the drawing grid
	  	    g.drawImage(gif2dArray[row][col], startX+(squareSide*row), startY+(squareSide*col), this);
		  }
	   }
    }
 }
