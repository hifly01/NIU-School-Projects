package smithpack;

/*****************************************************************
CSCI 470                Assignment 5

Programmer: Alyssa Smith

Due Date: November 15, 2020

Assignment: Grid Tiles

Notes: Create a frame that has a MainPanel that consists of 3 subpanels
*****************************************************************/
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JToolBar;


public class MainPanel extends JPanel implements ActionListener
 {
   String[] imageStringNameA ={"pat1.gif","pat2.gif","pat3.gif","pat4.gif","pat5.gif"};	//images
	
   final static Image[] imageA = new Image[5]; //image arr holds 5 images we load using toolkit code
 
   JToolBar MainPanelToolBar = new JToolBar(); //pointer to toolbar for main panel
   TileGridPanel tileGridPanelPtr = new TileGridPanel(); //pointer to area where we will �paint� items on a tile Grid
   //TileGridPanel drawingPanelPtr = new TileGridPanel();
   
   JPanel resetPanel = new JPanel();	//reset panel
   JButton patch1btn;	//declares five buttons
   JButton patch2btn;
   JButton patch3btn;
   JButton patch4btn;
   JButton patch5btn;
   JButton resetbtn;	//reset button
   
   public MainPanel()
    {
	  Toolkit tileToolBar = Toolkit.getDefaultToolkit(); //Toolkit initialization
	  Dimension d = tileToolBar.getScreenSize();
		
	  //Adding images to the image array
	  for(int i=0; i < imageStringNameA.length; i++) 
	   {
		 imageA[i] = (Image)Toolkit.getDefaultToolkit().getImage(imageStringNameA[i]);	//add image
	   }
	   
	  this.setLayout(new BorderLayout()); //we will add items to north, center south on main panel
	   
	  //prepare north area of main panel 
	  patch1btn = new JButton(new ImageIcon(imageA[0]));	//this how you get a button with an image
	  MainPanelToolBar.add(patch1btn);
	  patch1btn.addActionListener(this);	//sets one button for listening
	  
	  //prepare north area of main panel 
	  patch2btn = new JButton(new ImageIcon(imageA[1]));	//this how you get a button with an image
	  MainPanelToolBar.add(patch2btn);
	  patch2btn.addActionListener(this);	//sets one button for listening
	  
	  //prepare north area of main panel 
	  patch3btn = new JButton(new ImageIcon(imageA[2]));	//this how you get a button with an image
	  MainPanelToolBar.add(patch3btn);
	  patch3btn.addActionListener(this);	//sets one button for listening
	  
	  //prepare north area of main panel 
	  patch4btn = new JButton(new ImageIcon(imageA[3]));	//this how you get a button with an image
	  MainPanelToolBar.add(patch4btn);
	  patch4btn.addActionListener(this);	//sets one button for listening
	  
	  //prepare north area of main panel 
	  patch5btn = new JButton(new ImageIcon(imageA[4]));	//this how you get a button with an image
	  MainPanelToolBar.add(patch5btn);
	  patch5btn.addActionListener(this);	//sets one button for listening
	  
	  this.add(MainPanelToolBar, BorderLayout.NORTH);	//add toolbar to north
		
	  MainPanelToolBar.setBackground(Color.ORANGE); 	//set north background to orange
	  this.add(tileGridPanelPtr, BorderLayout.CENTER);
	  tileGridPanelPtr.setBackground(Color.YELLOW);	//set center background to yellow
	  tileGridPanelPtr.ResetGridTile();
		
	  //Adding reset button to the south region of the panel
	  resetbtn = new JButton("Reset");	//name button reset
	  resetPanel.add(resetbtn);		//add the reset button
	  resetbtn.addActionListener(this);		//add an action listener
	  this.add(resetPanel,BorderLayout.SOUTH);		//set the border layout on south panel
	  resetPanel.setBackground(Color.PINK);		//set the background color to pink
    } //end of constructor
   
   public void actionPerformed(ActionEvent e)  //put in listener method for button clicks on toolbar
    { 
      if(e.getSource() == patch1btn)  //was button 1 clicked in toolbar?
       {
    	 tileGridPanelPtr.selectedTile = 0;  //this sets the variable in tileGridPanel object, need to check for the 5 button clicks
       }
     
      else if(e.getSource() == patch2btn)  //was button 2 clicked in toolbar?
       {
   	     tileGridPanelPtr.selectedTile = 1;  //this sets the variable in tileGridPanel object, need to check for the 5 button clicks
       }
     
      else if(e.getSource() == patch3btn)  //was button 3 clicked in toolbar?
       {
   	     tileGridPanelPtr.selectedTile = 2;  //this sets the variable in tileGridPanel object, need to check for the 5 button clicks
       }
     
      else if(e.getSource() == patch4btn)  //was button 4 clicked in toolbar?
       {
   	     tileGridPanelPtr.selectedTile = 3;  //this sets the variable in tileGridPanel object, need to check for the 5 button clicks
       }
     
      else if(e.getSource() == patch5btn)  //was button 5 clicked in toolbar?
       {
   	     tileGridPanelPtr.selectedTile = 4;  //this sets the variable in tileGridPanel object, need to check for the 5 button clicks
       }
     
      else if(e.getSource() == resetbtn)  //was reset button clicked in toolbar?
       {
   	     tileGridPanelPtr.ResetGridTile();  //this sets the variable in tileGridPanel object, need to check for the 5 button clicks
       }
    } //end of actionPerformed
   
 } //end of class