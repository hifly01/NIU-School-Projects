/*****************************************************************
CSCI 470		Assignment 3

Programmer: Alyssa Smith

Due Date: October 4, 2020

Assignment: "Prisoner's Dilemma."

Notes: Practices writing multiple Java classes, using several Java
       library classes to do I/O and simple collection opertions,
       using Scanner, ArrayList, and HashMap
*****************************************************************/
import java.util.Scanner;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Date;
import java.util.*;

public class PDGameApp {

 public static void main(String[] args) {

   GameStat gsptr = new GameStat();
   Scanner input = new Scanner(System.in);  //Retrieves the input from user
   HashMap<String, GameStat> hashmap1 = new HashMap<>();  //Stores the GameStat objects from each PDGame

   String currentTime = null;  //Sets current time to null

   boolean playSession = true;	//Sets session being played to true

   int userInput = 0;	//Sets users input to zero

   String file = "input.txt";	//Input file containing 1's and 2's
   PDGame currentGamePtr1 = new PDGame(file);  //PDGame object that controls the play of each game

   currentTime = new Date().toString(); //current time

   while(playSession == true)
    {
      System.out.println("\n**Starting Session of Prisoner's Dilemma***\n");
      System.out.println("\n--HERE ARE STRATEGIES AVAILABLE FOR THE COMPUTER\n");

      ArrayList<String> strategy = currentGamePtr1.getStrategies();  //Arraylist containing strategies

      for(int i = 0; i < 3; i++)
       {
         //Get the strategies in PDGame
         System.out.println("\n" + strategy.get(i));
       }

      //Try/catch to make sure users enters correct values 1-3
      try
       {
         System.out.println("\n\nSelect a strategy from above for the Computer to use: ");
         userInput = input.nextInt();

         //If user enters 1, 2, or 3 break out of loop
         if(userInput < 1 || userInput > 3)
          {
           throw new InputMismatchException();
           /* System.out.println("\nINTEGER ENTERED IS OUT OF RANGE 1 TO 3");
            input.nextLine();*/  //clear line and start over
          }

         //else throw an exception
         else
          {
            playSession = false;  //we have a valid int in range 1-3
          }
       }

      //catch exception
      catch(InputMismatchException e)
       {
         System.out.println("\nCAUGHT EXCEPTION -INTEGER ENTERED IS OUT OF RANGE 1 TO 3");
         input.nextLine();  //clear out line and start over
       }

   //set the strategies to the userInput
   currentGamePtr1.setStrategy(userInput);

   int counter = 0;	//five round counter
   int userInput2 = 0;  //user input for 1 or 2
   String userInput3 = null;
   boolean playSession2 = true;  //session of game is set to true

   while(counter < 5)
    {
      while(playSession2 == true)
       {
         //try/catch to make sure user enter 1 or 2
         try
          {
            System.out.println("\n\nBEGIN A ROUND - Here are your 2 choices");
            System.out.println("\n1. Remain Silent.");
            System.out.println("\n2. Betray and testify against.\n");

            System.out.println("\n----What is your decision this round? ");
            userInput2 = input.nextInt(); //Scn user input

            //if user enters 1 or 2 break out of loop
            if(userInput2 < 1 || userInput2 > 2)
             {
               throw new InputMismatchException();
               /*System.out.println("\nINTEGER ENTERED IS OUT OF RANGE FROM 1 TO 2");
               input.nextLine();*/  //clear out line and start over
             }

            //else throw an exception
            else
             {
               playSession2 = false;
             }
           }

         //catch exception
         catch(InputMismatchException e)
          {
            //User did not enter proper data above
            System.out.println("\nCAUGHT EXCEPTION -YOU HAVE NOT ENTERED AN INTEGER-PLEASE TRY AGAIN");
            input.nextLine();
          }
      }

      String round = currentGamePtr1.playRound(userInput2); //Play round, get back string
      System.out.println(round);  //display the round result
      counter+=1;  //increase counter
      playSession2 = true; //set play session back to true
   }

      System.out.println("\nEND OF ROUNDS, GAME OVER");
      System.out.println(currentGamePtr1.getScores());  //get scores for user and computer

      GameStat stats;
      stats = currentGamePtr1.getStats();
      hashmap1.put(currentTime, stats);

      Set<String> key = hashmap1.keySet();  //get keyset of HashMap in Set

      for(String searchKey : key)  //use for:each loop to get winner
       {
         GameStat winner = hashmap1.get(searchKey);
         System.out.println("\nThe winner for this game is: " + winner.getWinner());  //get winner of round
       }

      //asks if uer would like to play again
      System.out.println("\n----Do you want to play again? Y/N");
      userInput3 = input.next();  //read in letter

      if(userInput3.equalsIgnoreCase("y"))  //if yes
       {
         playSession = true;  //continue session
       }

      else if(userInput3.equalsIgnoreCase("n"))  //if no
       {
         playSession = false;  //exit session
       }

      else  //if not valid y or n
       {
         System.out.println("\nYOUR ANSWER IS NOT VALID--PLEASE ENTER Y OR N");
         input.nextLine();
       }
//   }

   System.out.println("\nSummary of games and session times: \n");

   Set<String> keySet = hashmap1.keySet();  //get keyset of HashMap in Set

   for(String Key : keySet)  //use for:each to get key and display values
    {
      //result of time, winner, and strategy used from the computer
      GameStat result = hashmap1.get(Key);
      System.out.println(Key + "\nWinner is -- " + result.getWinner() + " The computer used " + result.getCompStrategy() + "\n");
    }
   }
  }
} //end of class
