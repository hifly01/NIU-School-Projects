package smithpack;

/*****************************************************************
CSCI 470                Assignment 6

Programmer: Alyssa Smith

Due Date: December 4, 2020

Assignment: Thread/Ball Application 

Notes: Animation that runs in a background thread to the GUI application 
       in Assignment 5.
*****************************************************************/
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

public class AnimationPanel extends JPanel implements Runnable
 {
   List<Ball> ballList = new ArrayList<>(); //An arrayList of Ball objects
   Dimension ballPanelDimensionPtr = null; //A reference to a Dimension object that is initially set to null 
   Thread threadObjPtr = null; 			//A reference to a Thread object that is initially set to null
   Dimension d = null; 				//Dimension instance
	
   public AnimationPanel() 
    {
  	  d = new Dimension(350,350);		//dimension size
	  this.setPreferredSize(d);		//set the dimensions preferred size
	  this.setBackground(Color.WHITE);	//set background to white
	}
	
   public void start() 
	{
	  if(threadObjPtr == null) 			//If the Thread reference is null 
	   {
		 threadObjPtr = new Thread(this,"Instance");	//create a new Thread object 
		 threadObjPtr.start();			//call start() method to make it runnable
	   }
	}
	
   public void stop() 
	{
	  threadObjPtr = null;		//set the Thread reference to null
	}
	
   @Override
   public Dimension getSize()	//get the size of the dimension
	{
	  ballPanelDimensionPtr = new Dimension(99,99);		//set the dimension
	  return ballPanelDimensionPtr;
	}
	
	
   protected void paintComponent(Graphics g) 
	{
      super.paintComponent(g);
      
	  if(ballPanelDimensionPtr == null) 	//If the Dimension object reference is null
	   {
		 //create a set of Ball objects
		 ballPanelDimensionPtr = this.getSize();	//get the size of the ball dimension
		 
		 //add them to the ArrayList, then get the dimensions of the panel
		 ballList.add(new Ball(Color.GREEN, 3,(ballPanelDimensionPtr.width * 2 / 3), (ballPanelDimensionPtr.height - 28), -4, 20));
		 ballList.add(new Ball(Color.BLUE, 20,(ballPanelDimensionPtr.width * 2 / 3), (ballPanelDimensionPtr.height - 54), -2, -4));
		 ballList.add(new Ball(Color.RED, 30,(ballPanelDimensionPtr.width * 2 / 3),(ballPanelDimensionPtr.height - 20), 3, 3));
		 ballList.add(new Ball(Color.PINK, 10,(ballPanelDimensionPtr.width), (ballPanelDimensionPtr.height), -4, 12));
		 ballList.add(new Ball(Color.ORANGE, 15,(ballPanelDimensionPtr.width * 2 / 3), (ballPanelDimensionPtr.height - 18), 4, -12));
		 ballList.add(new Ball(Color.YELLOW, 5,(ballPanelDimensionPtr.width),(ballPanelDimensionPtr.height), 4, -20));
	   }
	
	  for(Ball b : ballList) 	
	   {
		 b.move(d);		//Call the move() method for each Ball object, passing the dimensions of the panel to the method
		 b.draw(g);			//Call the draw() method for each Ball object,  passing the Graphics context to the method 
	   }
	}

   @Override
   public void run() 
    {
	  System.out.println(threadObjPtr);
	
	  while(threadObjPtr != null) 		//loop that continues while the current thread is not null
	   {
		 this.repaint();		//call repaint()
				
		 try 
		  {
			threadObjPtr.sleep(100);	//put the thread to sleep for a short amount of time 
		  } 
		 
		 catch(InterruptedException e) 
		  {		
			e.printStackTrace();		//if exception is caught print stack trace
		  }
	    }
	 }	
} //end of class
