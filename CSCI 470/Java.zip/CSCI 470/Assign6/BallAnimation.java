package smithpack;

/*****************************************************************
CSCI 470                Assignment 6

Programmer: Alyssa Smith

Due Date: December 4, 2020

Assignment: Thread/Ball Application 

Notes: Animation that runs in a background thread to the GUI application 
       in Assignment 5.
*****************************************************************/
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class BallAnimation extends JPanel implements ActionListener
 {
   JButton start; //Start button
   JButton stop;  //Stop button
   JPanel panel = new JPanel();	//new JPanel
   AnimationPanel animationPanel = new AnimationPanel(); //AnimationPanel instance
  
   BallAnimation()
	{
	  panel.setBackground(Color.CYAN);	//set background color to panel
	  start = new JButton("Start");		//set a "Start" button
	  panel.add(start);			//add "Start" button to panel
	  start.addActionListener(this);	//add to ActionListener
	  stop = new JButton("Stop");		//set a "Stop" button
	  panel.add(stop);			//add "Stop" button to panel
	  stop.addActionListener(this);		//add to ActionListener
	  this.setLayout(new BorderLayout());	//set the border layout
	  this.add(panel,BorderLayout.SOUTH);		//add panel to the South border
	  this.add(animationPanel,BorderLayout.EAST);	//add animation panel to East border
	 }
	
	@Override
	public void actionPerformed(ActionEvent e) 
	 {	
	   if(e.getSource() == start) //When "Start" was clicked
		{
	  	  stop.setEnabled(true);	//enable the "Stop" button
		  start.setEnabled(false);	//disable the "Start" buttion
		  animationPanel.start();	//call start() method to start animation
	    }
	   
	   else if(e.getSource() == stop) //When "Stop" was clicked
		{
		  start.setEnabled(true);	//enable the "Start" button 
		  stop.setEnabled(false);	//disable the "Stop" button
		  animationPanel.stop();	//call the stop() method to stop animation
		}		
	 }
 }	//end of class