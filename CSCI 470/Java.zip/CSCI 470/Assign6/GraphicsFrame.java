package smithpack;

/*****************************************************************
CSCI 470                Assignment 6

Programmer: Alyssa Smith

Due Date: December 4, 2020

Assignment: Thread/Ball Application 

Notes: Animation that runs in a background thread to the GUI application 
       in Assignment 5.
*****************************************************************/
import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JFrame;

public class GraphicsFrame extends JFrame
 {	
   public GraphicsFrame() 	//constructor
    {
	  super("Assignment 6 - Thread/Ball Application");
	  MainPanel mainPanelPtr = new MainPanel();//create mainpanel that overwrites the frame
	  this.add(mainPanelPtr, BorderLayout.CENTER);//main panel covers entire frame
	  BallAnimation b = new BallAnimation();	//call ball animation
	  this.add(b,BorderLayout.EAST);	//set the border layout to east
	  getRootPane().setBorder(BorderFactory.createMatteBorder(4, 4, 4, 4, Color.LIGHT_GRAY));	//set the border 
	}
		
   public static void main(String[] args) 
    {
	   createAndShowGUI();	//call createAndShowGUI
    }

   private static void createAndShowGUI() 
    {
	   //Frame initialization
	   GraphicsFrame frame = new GraphicsFrame();	//create the master frame
	  frame.setSize(700,450);	//set the size of the frame
			
	  frame.setVisible(true);
    }
 }	//end of class
