package smithpack;

/*****************************************************************
CSCI 470                Assignment 6

Programmer: Alyssa Smith

Due Date: December 4, 2020

Assignment: Thread/Ball Application 

Notes: Animation that runs in a background thread to the GUI application 
       in Assignment 5.
*****************************************************************/
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

public class Ball 
 {
   Color color; //Color, radius, coordinates, and movement.
   int radius;
   int x, y;
   int dx, dy;
   
   Ball(Color col, int rad, int x, int y, int dx, int dy) 
    { //Constructor statement.
      this.color = col;
      this.radius = rad;
      this.x = x;
      this.y = y;
      this.dx = dx;
      this.dy = dy;
    }

   public void move(Dimension d) 
    { //Move function.
	  if(x <= radius || x >= (d.width - (2*radius))) //Checks to see if ball has hit the edge of the panel.
       {
	     dx = -dx; //If so, switch direction.
       }
   
      if(y <= radius || y >= (d.height - (2*radius))) //Same for y direction.
       {  
	     dy = -dy;
       }
   
      x += dx; //If not, continue moving the ball in the direction and modify the coordinates to reflect the move.
      y += dy;
    }

   public void draw(Graphics g) //Draws the ball in its new location, chaning x and y each time.
    {
	  g.setColor(Color.WHITE);	//set white to the background
      g.fillOval(x - dx, y - dy, 2 * radius, 2 * radius);     //clears the old ball
      g.setColor(color); 	//Sets the color to whatever the balls color was
      g.fillOval(x, y, 2 * radius, 2 * radius); //Draws the ball in the new location
    }
 }	//end of class